package handler

import (
	"fmt"
	"rx-st-system/internal/dto"
	"rx-st-system/internal/service"
	"rx-st-system/pkg/errors"
	"strconv"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
)

// StOrderHandler handles ST order endpoints
type StOrderHandler struct {
	stOrderService   *service.StOrderService
	inventoryService *service.InventoryService
	validator        *validator.Validate
}

// NewStOrderHandler creates a new StOrderHandler
func NewStOrderHandler(stOrderService *service.StOrderService, inventoryService *service.InventoryService) *StOrderHandler {
	return &StOrderHandler{
		stOrderService:   stOrderService,
		inventoryService: inventoryService,
		validator:        validator.New(),
	}
}

// Create creates a new ST order
// @Summary Create ST Order
// @Description Create a new stock lens order with pair items (warranty) or single items (bulk)
// @Tags st-orders
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.CreateStOrderRequest true "ST order details"
// @Success 201 {object} dto.StOrderResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 404 {object} dto.ErrorResponse "Product not found"
// @Router /api/v1/st-orders [post]
func (h *StOrderHandler) Create(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.CreateStOrderRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	// Validate request
	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	// Validate that at least one type of item is provided
	if len(req.PairItems) == 0 && len(req.SingleItems) == 0 {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "At least one pair item or single item is required",
			Code:    errors.ErrCodeValidation,
		})
	}

	// Additional validations
	if err := h.validateStOrderRequest(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   err.Error(),
			Code:    errors.ErrCodeValidation,
		})
	}

	// Create order
	response, err := h.stOrderService.Create(c.Context(), req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.Status(fiber.StatusCreated).JSON(response)
}

// Get gets ST order by ID
// @Summary Get ST Order
// @Description Get ST order details by ID including pair items, single items, and warranty cards
// @Tags st-orders
// @Produce json
// @Security BearerAuth
// @Param id path int true "Order ID"
// @Success 200 {object} dto.StOrderResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/st-orders/{id} [get]
func (h *StOrderHandler) Get(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid order ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	response, err := h.stOrderService.GetByID(c.Context(), id)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// Update updates an ST order
// @Summary Update ST Order
// @Description Update ST order (only in draft state)
// @Tags st-orders
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param id path int true "Order ID"
// @Param request body dto.UpdateStOrderRequest true "Update details"
// @Success 200 {object} dto.StOrderResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/st-orders/{id} [put]
func (h *StOrderHandler) Update(c *fiber.Ctx) error {
	//userID := c.Locals("user_id").(int64)

	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid order ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	var req dto.UpdateStOrderRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.stOrderService.Update(c.Context(), id, req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// Delete deletes an ST order
// @Summary Delete ST Order
// @Description Delete ST order (only in draft state)
// @Tags st-orders
// @Produce json
// @Security BearerAuth
// @Param id path int true "Order ID"
// @Success 200 {object} dto.SuccessResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/st-orders/{id} [delete]
func (h *StOrderHandler) Delete(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid order ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.stOrderService.Delete(c.Context(), id); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "ST order deleted successfully",
	})
}

// List lists ST orders with filters
// @Summary List ST Orders
// @Description List ST orders with filtering and pagination
// @Tags st-orders
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.ListStOrdersRequest true "List parameters"
// @Success 200 {object} dto.ListResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/st-orders/list [post]
func (h *StOrderHandler) List(c *fiber.Ctx) error {
	var req dto.ListStOrdersRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	// Set defaults
	if req.Page == 0 {
		req.Page = 1
	}
	if req.PageSize == 0 {
		req.PageSize = 20
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.stOrderService.List(c.Context(), req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// ChangeState changes order state
// @Summary Change ST Order State
// @Description Change ST order state (with permission check and inventory validation)
// @Tags st-orders
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.ChangeStOrderStateRequest true "State change details"
// @Success 200 {object} dto.SuccessResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 403 {object} dto.ErrorResponse
// @Router /api/v1/st-orders/change-state [post]
func (h *StOrderHandler) ChangeState(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.ChangeStOrderStateRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}
	if err := h.stOrderService.ChangeState(c.Context(), req.OrderID, req.ToStateCode, userID, req.Notes); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "State changed successfully",
	})
}

// CheckInventory checks inventory availability for order items
// @Summary Check Inventory Availability
// @Description Check if all products in the order are available in warehouse
// @Tags st-orders
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.CheckInventoryRequest true "Inventory check request"
// @Success 200 {object} dto.CheckInventoryResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/st-orders/check-inventory [post]
func (h *StOrderHandler) CheckInventory(c *fiber.Ctx) error {
	var req dto.CheckInventoryRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	// Get bulk balances
	bulkReq := dto.BulkInventoryBalanceRequest{
		WarehouseID: req.WarehouseID,
		ProductIDs:  req.ProductIDs,
	}

	balancesResp, err := h.inventoryService.GetBulkBalances(c.Context(), bulkReq)
	if err != nil {
		return handleServiceError(c, err)
	}

	// Check availability
	availability := make(map[int64]bool)
	allAvailable := true

	for _, productID := range req.ProductIDs {
		available := balancesResp.Balances[productID] > 0
		availability[productID] = available
		if !available {
			allAvailable = false
		}
	}

	response := dto.CheckInventoryResponse{
		AllAvailable: allAvailable,
		Availability: availability,
		Quantities:   balancesResp.Balances,
	}

	return c.JSON(response)
}

// CreateWarrantyClaim creates a warranty claim
// @Summary Create Warranty Claim
// @Description Create a warranty claim for a warranty card
// @Tags st-orders
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.CreateWarrantyClaimRequest true "Warranty claim details"
// @Success 201 {object} dto.WarrantyClaimResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/st-orders/warranty-claim [post]
func (h *StOrderHandler) CreateWarrantyClaim(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.CreateWarrantyClaimRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.stOrderService.CreateWarrantyClaim(c.Context(), req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.Status(fiber.StatusCreated).JSON(response)
}

// GetWarrantyCard gets warranty card details
// @Summary Get Warranty Card
// @Description Get warranty card details by card number
// @Tags st-orders
// @Produce json
// @Security BearerAuth
// @Param cardNumber path string true "Warranty Card Number"
// @Success 200 {object} dto.WarrantyCardResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/st-orders/warranty-card/{cardNumber} [get]
func (h *StOrderHandler) GetWarrantyCard(c *fiber.Ctx) error {
	cardNumber := c.Params("cardNumber")
	if cardNumber == "" {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Card number is required",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	response, err := h.stOrderService.GetWarrantyCardByNumber(c.Context(), cardNumber)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// ListWarrantyClaims lists warranty claims
// @Summary List Warranty Claims
// @Description List warranty claims with filtering
// @Tags st-orders
// @Produce json
// @Security BearerAuth
// @Param warranty_card_id query int false "Warranty Card ID"
// @Param status query string false "Claim Status"
// @Param page query int false "Page number" default(1)
// @Param page_size query int false "Page size" default(20)
// @Success 200 {object} dto.ListResponse
// @Router /api/v1/st-orders/warranty-claims [get]
func (h *StOrderHandler) ListWarrantyClaims(c *fiber.Ctx) error {
	warrantyCardID, _ := strconv.ParseInt(c.Query("warranty_card_id", "0"), 10, 64)
	status := c.Query("status", "")
	page, _ := strconv.Atoi(c.Query("page", "1"))
	pageSize, _ := strconv.Atoi(c.Query("page_size", "20"))

	if page < 1 {
		page = 1
	}
	if pageSize < 1 || pageSize > 100 {
		pageSize = 20
	}

	response, err := h.stOrderService.ListWarrantyClaims(c.Context(), warrantyCardID, status, page, pageSize)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// GetSummary gets ST orders summary statistics
// @Summary Get ST Orders Summary
// @Description Get summary statistics for ST orders
// @Tags st-orders
// @Produce json
// @Security BearerAuth
// @Success 200 {object} dto.StOrderSummaryResponse
// @Router /api/v1/st-orders/summary [get]
func (h *StOrderHandler) GetSummary(c *fiber.Ctx) error {
	response, err := h.stOrderService.GetSummary(c.Context())
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// validateStOrderRequest validates ST order request
func (h *StOrderHandler) validateStOrderRequest(req *dto.CreateStOrderRequest) error {
	// Validate pair items
	for i, pairItem := range req.PairItems {
		// Validate SPH range for stock lenses (typical range: -10.00 to +8.00)
		if pairItem.RightSPH < -10.0 || pairItem.RightSPH > 8.0 {
			return errors.NewValidationError(
				fmt.Sprintf("Pair item %d: Right SPH must be between -10.00 and +8.00 for stock lenses", i+1),
				nil,
			)
		}
		if pairItem.LeftSPH < -10.0 || pairItem.LeftSPH > 8.0 {
			return errors.NewValidationError(
				fmt.Sprintf("Pair item %d: Left SPH must be between -10.00 and +8.00 for stock lenses", i+1),
				nil,
			)
		}

		// Validate CYL range if provided (typical range for stock: -2.00 to 0)
		if pairItem.RightCYL != nil && (*pairItem.RightCYL < -2.0 || *pairItem.RightCYL > 0) {
			return errors.NewValidationError(
				fmt.Sprintf("Pair item %d: Right CYL must be between -2.00 and 0.00 for stock lenses", i+1),
				nil,
			)
		}
		if pairItem.LeftCYL != nil && (*pairItem.LeftCYL < -2.0 || *pairItem.LeftCYL > 0) {
			return errors.NewValidationError(
				fmt.Sprintf("Pair item %d: Left CYL must be between -2.00 and 0.00 for stock lenses", i+1),
				nil,
			)
		}

		// Validate patient information for warranty
		if pairItem.PatientName == "" {
			return errors.NewValidationError(
				fmt.Sprintf("Pair item %d: Patient name is required for warranty", i+1),
				nil,
			)
		}
		if pairItem.PatientMobile == "" {
			return errors.NewValidationError(
				fmt.Sprintf("Pair item %d: Patient mobile is required for warranty", i+1),
				nil,
			)
		}

		// Validate mobile number format (Iranian format)
		if !h.isValidIranianMobile(pairItem.PatientMobile) {
			return errors.NewValidationError(
				fmt.Sprintf("Pair item %d: Invalid Iranian mobile number format (must start with 09 and be 11 digits)", i+1),
				nil,
			)
		}
	}

	// Validate single items
	for i, singleItem := range req.SingleItems {
		if singleItem.Quantity <= 0 {
			return errors.NewValidationError(
				fmt.Sprintf("Single item %d: Quantity must be greater than 0", i+1),
				nil,
			)
		}
		if singleItem.Quantity > 1000 {
			return errors.NewValidationError(
				fmt.Sprintf("Single item %d: Quantity seems too high (max 1000 per item)", i+1),
				nil,
			)
		}
	}

	// Validate cutting service
	if req.UseCuttingService && req.CuttingServiceID == nil {
		return errors.NewValidationError("Cutting service ID is required when use_cutting_service is true", nil)
	}

	return nil
}

// isValidIranianMobile validates Iranian mobile number format
func (h *StOrderHandler) isValidIranianMobile(mobile string) bool {
	// Iranian mobile numbers: 09XXXXXXXXX (11 digits starting with 09)
	if len(mobile) != 11 {
		return false
	}
	if mobile[0] != '0' || mobile[1] != '9' {
		return false
	}
	// Check if all characters are digits
	for _, c := range mobile {
		if c < '0' || c > '9' {
			return false
		}
	}
	return true
}
