package handler

import (
	"strconv"

	"rx-st-system/internal/dto"
	"rx-st-system/internal/service"
	"rx-st-system/pkg/errors"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
)

// InventoryHandler handles inventory endpoints
type InventoryHandler struct {
	inventoryService *service.InventoryService
	validator        *validator.Validate
}

// NewInventoryHandler creates a new InventoryHandler
func NewInventoryHandler(inventoryService *service.InventoryService) *InventoryHandler {
	return &InventoryHandler{
		inventoryService: inventoryService,
		validator:        validator.New(),
	}
}

// GetBalance gets inventory balance
func (h *InventoryHandler) GetBalance(c *fiber.Ctx) error {
	warehouseID, _ := strconv.ParseInt(c.Query("warehouse_id"), 10, 64)
	productID, _ := strconv.ParseInt(c.Query("product_id"), 10, 64)
	unitID, _ := strconv.ParseInt(c.Query("unit_id", "0"), 10, 64)

	if warehouseID == 0 || productID == 0 {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "warehouse_id and product_id are required",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	var response *dto.InventoryBalanceResponse
	var err error

	if unitID > 0 {
		response, err = h.inventoryService.GetBalance(c.Context(), warehouseID, productID, unitID)
	} else {
		response, err = h.inventoryService.GetBalanceByProduct(c.Context(), warehouseID, productID)
	}

	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// ListBalances lists inventory balances
func (h *InventoryHandler) ListBalances(c *fiber.Ctx) error {
	var req dto.ListInventoryBalancesRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if req.Page == 0 {
		req.Page = 1
	}
	if req.PageSize == 0 {
		req.PageSize = 50
	}

	response, err := h.inventoryService.ListBalances(c.Context(), req.WarehouseID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// GetBulkBalances gets multiple balances at once
func (h *InventoryHandler) GetBulkBalances(c *fiber.Ctx) error {
	var req dto.BulkInventoryBalanceRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.inventoryService.GetBulkBalances(c.Context(), req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// ReserveInventory reserves inventory
func (h *InventoryHandler) ReserveInventory(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.ReserveInventoryRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	if err := h.inventoryService.ReserveInventory(c.Context(), req.ProductID, req.WarehouseID, 1, req.Quantity, userID); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Inventory reserved successfully",
	})
}

// ReleaseInventory releases reserved inventory
func (h *InventoryHandler) ReleaseInventory(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.ReleaseInventoryRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}
	if err := h.inventoryService.ReleaseInventory(c.Context(), req.ProductID, req.WarehouseID, 1, req.Quantity, userID); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Inventory released successfully",
	})
}

// AdjustInventory adjusts inventory
func (h *InventoryHandler) AdjustInventory(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.AdjustInventoryRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	if err := h.inventoryService.AdjustInventory(c.Context(), req, userID); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Inventory adjusted successfully",
	})
}

// ListTransactions lists inventory transactions
func (h *InventoryHandler) ListTransactions(c *fiber.Ctx) error {
	var req dto.ListInventoryTransactionsRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if req.Page == 0 {
		req.Page = 1
	}
	if req.PageSize == 0 {
		req.PageSize = 50
	}

	response, err := h.inventoryService.ListTransactions(c.Context(), req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// GetSummary gets inventory summary
func (h *InventoryHandler) GetSummary(c *fiber.Ctx) error {
	warehouseID, err := strconv.ParseInt(c.Params("warehouseId"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid warehouse ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	response, err := h.inventoryService.GetSummary(c.Context(), warehouseID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// InvalidateCache invalidates inventory cache
func (h *InventoryHandler) InvalidateCache(c *fiber.Ctx) error {
	warehouseID, _ := strconv.ParseInt(c.Query("warehouse_id", "0"), 10, 64)
	productID, _ := strconv.ParseInt(c.Query("product_id", "0"), 10, 64)

	if err := h.inventoryService.InvalidateCache(c.Context(), warehouseID, productID); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Cache invalidated successfully",
	})
}
