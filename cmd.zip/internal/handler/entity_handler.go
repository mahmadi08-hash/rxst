package handler

import (
	"strconv"

	"rx-st-system/internal/dto"
	"rx-st-system/internal/service"
	"rx-st-system/pkg/errors"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
)

// EntityHandler handles entity endpoints
type EntityHandler struct {
	entityService *service.EntityService
	validator     *validator.Validate
}

// NewEntityHandler creates a new EntityHandler
func NewEntityHandler(entityService *service.EntityService) *EntityHandler {
	return &EntityHandler{
		entityService: entityService,
		validator:     validator.New(),
	}
}

// Create creates a new entity
// @Summary Create Entity
// @Description Create a new person or company
// @Tags entities
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.CreateEntityRequest true "Entity details"
// @Success 201 {object} dto.EntityResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 409 {object} dto.ErrorResponse
// @Router /api/v1/entities [post]
func (h *EntityHandler) Create(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.CreateEntityRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.entityService.Create(c.Context(), req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.Status(fiber.StatusCreated).JSON(response)
}

// Get gets entity by ID
// @Summary Get Entity
// @Description Get entity details by ID
// @Tags entities
// @Produce json
// @Security BearerAuth
// @Param id path int true "Entity ID"
// @Success 200 {object} dto.EntityResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/entities/{id} [get]
func (h *EntityHandler) Get(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid entity ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	response, err := h.entityService.GetByID(c.Context(), id)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// Update updates an entity
// @Summary Update Entity
// @Description Update entity details
// @Tags entities
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param id path int true "Entity ID"
// @Param request body dto.UpdateEntityRequest true "Update details"
// @Success 200 {object} dto.EntityResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/entities/{id} [put]
func (h *EntityHandler) Update(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid entity ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	var req dto.UpdateEntityRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.entityService.Update(c.Context(), id, req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// Delete deletes an entity
// @Summary Delete Entity
// @Description Delete an entity
// @Tags entities
// @Produce json
// @Security BearerAuth
// @Param id path int true "Entity ID"
// @Success 200 {object} dto.SuccessResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/entities/{id} [delete]
func (h *EntityHandler) Delete(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid entity ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.entityService.Delete(c.Context(), id); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Entity deleted successfully",
	})
}

// List lists entities with pagination
// @Summary List Entities
// @Description List entities with filtering and pagination
// @Tags entities
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.ListEntitiesRequest true "List parameters"
// @Success 200 {object} dto.ListResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/entities/list [post]
func (h *EntityHandler) List(c *fiber.Ctx) error {
	var req dto.ListEntitiesRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	// Set defaults
	if req.Page == 0 {
		req.Page = 1
	}
	if req.PageSize == 0 {
		req.PageSize = 20
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.entityService.List(c.Context(), req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// AssignRole assigns a role to entity
// @Summary Assign Role
// @Description Assign a role to an entity
// @Tags entities
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.AssignRoleRequest true "Role assignment"
// @Success 200 {object} dto.SuccessResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/entities/assign-role [post]
func (h *EntityHandler) AssignRole(c *fiber.Ctx) error {
	var req dto.AssignRoleRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
		})
	}

	if err := h.entityService.AssignRole(c.Context(), req.EntityID, req.RoleID); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Role assigned successfully",
	})
}

// RemoveRole removes a role from entity
// @Summary Remove Role
// @Description Remove a role from an entity
// @Tags entities
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.AssignRoleRequest true "Role removal"
// @Success 200 {object} dto.SuccessResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/entities/remove-role [post]
func (h *EntityHandler) RemoveRole(c *fiber.Ctx) error {
	var req dto.AssignRoleRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
		})
	}

	if err := h.entityService.RemoveRole(c.Context(), req.EntityID, req.RoleID); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Role removed successfully",
	})
}

// AddPhone adds a phone to entity
// @Summary Add Phone
// @Description Add a phone number to an entity
// @Tags entities
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param id path int true "Entity ID"
// @Param request body dto.CreateEntityPhoneRequest true "Phone details"
// @Success 201 {object} dto.EntityPhoneResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/entities/{id}/phones [post]
func (h *EntityHandler) AddPhone(c *fiber.Ctx) error {
	entityID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid entity ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	var req dto.CreateEntityPhoneRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
		})
	}

	response, err := h.entityService.AddPhone(c.Context(), entityID, req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.Status(fiber.StatusCreated).JSON(response)
}

// DeletePhone deletes a phone from entity
// @Summary Delete Phone
// @Description Delete a phone number from an entity
// @Tags entities
// @Produce json
// @Security BearerAuth
// @Param id path int true "Entity ID"
// @Param phoneId path int true "Phone ID"
// @Success 200 {object} dto.SuccessResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/entities/{id}/phones/{phoneId} [delete]
func (h *EntityHandler) DeletePhone(c *fiber.Ctx) error {
	phoneID, err := strconv.ParseInt(c.Params("phoneId"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid phone ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.entityService.DeletePhone(c.Context(), phoneID); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Phone deleted successfully",
	})
}

// AddAddress adds an address to entity
// @Summary Add Address
// @Description Add an address to an entity
// @Tags entities
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param id path int true "Entity ID"
// @Param request body dto.CreateEntityAddressRequest true "Address details"
// @Success 201 {object} dto.EntityAddressResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/entities/{id}/addresses [post]
func (h *EntityHandler) AddAddress(c *fiber.Ctx) error {
	entityID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid entity ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	var req dto.CreateEntityAddressRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
		})
	}

	response, err := h.entityService.AddAddress(c.Context(), entityID, req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.Status(fiber.StatusCreated).JSON(response)
}

// DeleteAddress deletes an address from entity
// @Summary Delete Address
// @Description Delete an address from an entity
// @Tags entities
// @Produce json
// @Security BearerAuth
// @Param id path int true "Entity ID"
// @Param addressId path int true "Address ID"
// @Success 200 {object} dto.SuccessResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/entities/{id}/addresses/{addressId} [delete]
func (h *EntityHandler) DeleteAddress(c *fiber.Ctx) error {
	addressID, err := strconv.ParseInt(c.Params("addressId"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid address ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.entityService.DeleteAddress(c.Context(), addressID); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Address deleted successfully",
	})
}

// GetByRole gets entities by role
// @Summary Get Entities by Role
// @Description Get entities that have a specific role
// @Tags entities
// @Produce json
// @Security BearerAuth
// @Param roleCode query string true "Role code"
// @Param page query int false "Page number" default(1)
// @Param pageSize query int false "Page size" default(20)
// @Success 200 {object} dto.ListResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/entities/by-role [get]
func (h *EntityHandler) GetByRole(c *fiber.Ctx) error {
	roleCode := c.Query("roleCode")
	if roleCode == "" {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Role code is required",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	page, _ := strconv.Atoi(c.Query("page", "1"))
	pageSize, _ := strconv.Atoi(c.Query("pageSize", "20"))

	if page < 1 {
		page = 1
	}
	if pageSize < 1 || pageSize > 100 {
		pageSize = 20
	}

	response, err := h.entityService.GetEntitiesWithRole(c.Context(), roleCode, page, pageSize)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}
