package handler

import (
	"strconv"

	"rx-st-system/internal/dto"
	"rx-st-system/internal/service"
	"rx-st-system/pkg/errors"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
)

// ProductHandler handles product endpoints
type ProductHandler struct {
	productService *service.ProductService
	validator      *validator.Validate
}

// NewProductHandler creates a new ProductHandler
func NewProductHandler(productService *service.ProductService) *ProductHandler {
	return &ProductHandler{
		productService: productService,
		validator:      validator.New(),
	}
}

// Create creates a new product
func (h *ProductHandler) Create(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.CreateProductRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.productService.Create(c.Context(), req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.Status(fiber.StatusCreated).JSON(response)
}

// Get gets product by ID
func (h *ProductHandler) Get(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid product ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	response, err := h.productService.GetByID(c.Context(), id)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// Update updates a product
func (h *ProductHandler) Update(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid product ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	var req dto.UpdateProductRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	response, err := h.productService.Update(c.Context(), id, req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// Delete deletes a product
func (h *ProductHandler) Delete(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid product ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.productService.Delete(c.Context(), id); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Product deleted successfully",
	})
}

// List lists products with pagination
func (h *ProductHandler) List(c *fiber.Ctx) error {
	var req dto.ListProductsRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if req.Page == 0 {
		req.Page = 1
	}
	if req.PageSize == 0 {
		req.PageSize = 20
	}

	response, err := h.productService.List(c.Context(), req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// FindRxProduct finds RX product by specifications
func (h *ProductHandler) FindRxProduct(c *fiber.Ctx) error {
	var req dto.FindRxProductRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
		})
	}

	response, err := h.productService.FindRxProduct(c.Context(), req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// FindStProduct finds ST product by specifications
func (h *ProductHandler) FindStProduct(c *fiber.Ctx) error {
	var req dto.FindStProductRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
		})
	}

	response, err := h.productService.FindStProduct(c.Context(), req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// FindSemiFinishedProduct finds semi-finished product
func (h *ProductHandler) FindSemiFinishedProduct(c *fiber.Ctx) error {
	var req dto.FindSemiFinishedProductRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
		})
	}

	response, err := h.productService.FindSemiFinishedProduct(c.Context(), req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}
