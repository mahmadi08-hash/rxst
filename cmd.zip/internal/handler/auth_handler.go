package handler

import (
	"rx-st-system/internal/dto"
	"rx-st-system/internal/service"
	"rx-st-system/pkg/errors"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
)

// AuthHandler handles authentication endpoints
type AuthHandler struct {
	authService *service.AuthService
	validator   *validator.Validate
}

// NewAuthHandler creates a new AuthHandler
func NewAuthHandler(authService *service.AuthService) *AuthHandler {
	return &AuthHandler{
		authService: authService,
		validator:   validator.New(),
	}
}

// Login handles user login
// @Summary Login
// @Description Authenticate user and return tokens
// @Tags auth
// @Accept json
// @Produce json
// @Param request body dto.LoginRequest true "Login credentials"
// @Success 200 {object} dto.LoginResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 401 {object} dto.ErrorResponse
// @Router /api/v1/auth/login [post]
func (h *AuthHandler) Login(c *fiber.Ctx) error {
	var req dto.LoginRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	ipAddress := c.IP()
	userAgent := c.Get("User-Agent")

	response, err := h.authService.Login(c.Context(), req, ipAddress, userAgent)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// Register handles user registration
// @Summary Register
// @Description Register a new user account
// @Tags auth
// @Accept json
// @Produce json
// @Param request body dto.RegisterRequest true "Registration details"
// @Success 201 {object} dto.RegisterResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 409 {object} dto.ErrorResponse
// @Router /api/v1/auth/register [post]
func (h *AuthHandler) Register(c *fiber.Ctx) error {
	var req dto.RegisterRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.authService.Register(c.Context(), req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.Status(fiber.StatusCreated).JSON(response)
}

// Logout handles user logout
// @Summary Logout
// @Description Invalidate user session
// @Tags auth
// @Accept json
// @Produce json
// @Security BearerAuth
// @Success 200 {object} dto.SuccessResponse
// @Failure 401 {object} dto.ErrorResponse
// @Router /api/v1/auth/logout [post]
func (h *AuthHandler) Logout(c *fiber.Ctx) error {
	refreshToken := c.Get("X-Refresh-Token")
	if refreshToken == "" {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Refresh token required",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.authService.Logout(c.Context(), refreshToken); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Logged out successfully",
	})
}

// RefreshToken handles token refresh
// @Summary Refresh Token
// @Description Get a new access token using refresh token
// @Tags auth
// @Accept json
// @Produce json
// @Param request body dto.RefreshTokenRequest true "Refresh token"
// @Success 200 {object} dto.LoginResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 401 {object} dto.ErrorResponse
// @Router /api/v1/auth/refresh [post]
func (h *AuthHandler) RefreshToken(c *fiber.Ctx) error {
	var req dto.RefreshTokenRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
		})
	}

	response, err := h.authService.RefreshToken(c.Context(), req.RefreshToken)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// ChangePassword handles password change
// @Summary Change Password
// @Description Change user password
// @Tags auth
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.ChangePasswordRequest true "Password change details"
// @Success 200 {object} dto.SuccessResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 401 {object} dto.ErrorResponse
// @Router /api/v1/auth/change-password [post]
func (h *AuthHandler) ChangePassword(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.ChangePasswordRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
		})
	}

	if err := h.authService.ChangePassword(c.Context(), userID, req); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Password changed successfully",
	})
}

// ApproveUser handles user approval
// @Summary Approve User
// @Description Approve or reject a user registration
// @Tags auth
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.ApproveUserRequest true "Approval details"
// @Success 200 {object} dto.SuccessResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 403 {object} dto.ErrorResponse
// @Router /api/v1/auth/approve-user [post]
func (h *AuthHandler) ApproveUser(c *fiber.Ctx) error {
	adminID := c.Locals("user_id").(int64)
	isAdmin := c.Locals("is_admin").(bool)

	if !isAdmin {
		return c.Status(fiber.StatusForbidden).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Only administrators can approve users",
			Code:    errors.ErrCodeForbidden,
		})
	}

	var req dto.ApproveUserRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
		})
	}

	if err := h.authService.ApproveUser(c.Context(), adminID, req.UserID, req.Approved); err != nil {
		return handleServiceError(c, err)
	}

	message := "User approved successfully"
	if !req.Approved {
		message = "User rejected"
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: message,
	})
}

// GetProfile returns current user profile
// @Summary Get Profile
// @Description Get current user profile information
// @Tags auth
// @Produce json
// @Security BearerAuth
// @Success 200 {object} dto.UserInfo
// @Failure 401 {object} dto.ErrorResponse
// @Router /api/v1/auth/profile [get]
func (h *AuthHandler) GetProfile(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)
	username := c.Locals("username").(string)
	isAdmin := c.Locals("is_admin").(bool)

	// You can fetch more details from database if needed
	return c.JSON(dto.UserInfo{
		ID:            userID,
		Username:      username,
		IsSystemAdmin: isAdmin,
	})
}

// formatValidationErrors formats validation errors
func formatValidationErrors(err error) map[string]interface{} {
	errors := make(map[string]interface{})
	if validationErrs, ok := err.(validator.ValidationErrors); ok {
		for _, e := range validationErrs {
			errors[e.Field()] = formatValidationTag(e)
		}
	}
	return errors
}

// formatValidationTag formats validation tag
func formatValidationTag(e validator.FieldError) string {
	switch e.Tag() {
	case "required":
		return "This field is required"
	case "email":
		return "Invalid email format"
	case "min":
		return "Value is too short"
	case "max":
		return "Value is too long"
	default:
		return "Invalid value"
	}
}

// handleServiceError handles service errors
func handleServiceError(c *fiber.Ctx, err error) error {
	traceID := c.Locals("requestid").(string)

	if appErr, ok := err.(*errors.AppError); ok {
		appErr.TraceID = traceID

		status := fiber.StatusInternalServerError
		switch appErr.Code {
		case errors.ErrCodeValidation, errors.ErrCodeBadRequest:
			status = fiber.StatusBadRequest
		case errors.ErrCodeUnauthorized, errors.ErrCodeInvalidCredentials, errors.ErrCodeInvalidToken:
			status = fiber.StatusUnauthorized
		case errors.ErrCodeForbidden:
			status = fiber.StatusForbidden
		case errors.ErrCodeNotFound:
			status = fiber.StatusNotFound
		case errors.ErrCodeConflict:
			status = fiber.StatusConflict
		}

		return c.Status(status).JSON(dto.ErrorResponse{
			Success:   false,
			Error:     appErr.Message,
			Code:      appErr.Code,
			Details:   appErr.Details,
			TraceID:   appErr.TraceID,
			Timestamp: appErr.Timestamp.Format("2006-01-02T15:04:05Z07:00"),
		})
	}

	return c.Status(fiber.StatusInternalServerError).JSON(dto.ErrorResponse{
		Success: false,
		Error:   "Internal server error",
		Code:    errors.ErrCodeInternal,
		TraceID: traceID,
	})
}
