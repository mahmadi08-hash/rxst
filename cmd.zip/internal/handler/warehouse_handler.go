package handler

import (
	"strconv"

	"rx-st-system/internal/dto"
	"rx-st-system/internal/service"
	"rx-st-system/pkg/errors"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
)

// WarehouseHandler handles warehouse endpoints
type WarehouseHandler struct {
	warehouseService *service.WarehouseService
	validator        *validator.Validate
}

// NewWarehouseHandler creates a new WarehouseHandler
func NewWarehouseHandler(warehouseService *service.WarehouseService) *WarehouseHandler {
	return &WarehouseHandler{
		warehouseService: warehouseService,
		validator:        validator.New(),
	}
}

// CreateWarehouse creates a new warehouse
func (h *WarehouseHandler) CreateWarehouse(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.CreateWarehouseRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.warehouseService.CreateWarehouse(c.Context(), req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.Status(fiber.StatusCreated).JSON(response)
}

// GetWarehouse gets warehouse by ID
func (h *WarehouseHandler) GetWarehouse(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid warehouse ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	response, err := h.warehouseService.GetWarehouse(c.Context(), id)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// ListWarehouses lists all warehouses
func (h *WarehouseHandler) ListWarehouses(c *fiber.Ctx) error {
	response, err := h.warehouseService.ListWarehouses(c.Context())
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// UpdateWarehouse updates a warehouse
func (h *WarehouseHandler) UpdateWarehouse(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid warehouse ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	var req dto.UpdateWarehouseRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.warehouseService.UpdateWarehouse(c.Context(), id, req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// CreateDocumentTemplate creates a document template
func (h *WarehouseHandler) CreateDocumentTemplate(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.CreateWarehouseDocumentTemplateRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.warehouseService.CreateDocumentTemplate(c.Context(), req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.Status(fiber.StatusCreated).JSON(response)
}

// ListDocumentTemplates lists all document templates
func (h *WarehouseHandler) ListDocumentTemplates(c *fiber.Ctx) error {
	response, err := h.warehouseService.ListDocumentTemplates(c.Context())
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// CreateDocument creates a warehouse document
func (h *WarehouseHandler) CreateDocument(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.CreateWarehouseDocumentRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.warehouseService.CreateDocument(c.Context(), req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.Status(fiber.StatusCreated).JSON(response)
}

// GetDocument gets document by ID
func (h *WarehouseHandler) GetDocument(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid document ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	response, err := h.warehouseService.GetDocument(c.Context(), id)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// ListDocuments lists warehouse documents
func (h *WarehouseHandler) ListDocuments(c *fiber.Ctx) error {
	var req dto.ListWarehouseDocumentsRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if req.Page == 0 {
		req.Page = 1
	}
	if req.PageSize == 0 {
		req.PageSize = 20
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.warehouseService.ListDocuments(c.Context(), req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// PostDocument posts a document
func (h *WarehouseHandler) PostDocument(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.PostWarehouseDocumentRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
		})
	}

	if err := h.warehouseService.PostDocument(c.Context(), req.DocumentID, userID); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Document posted successfully",
	})
}

// GetNextDocumentNumber gets next document number
func (h *WarehouseHandler) GetNextDocumentNumber(c *fiber.Ctx) error {
	fiscalYearID, err := strconv.ParseInt(c.Query("fiscal_year_id"), 10, 64)
	if err != nil || fiscalYearID == 0 {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "fiscal_year_id is required",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	response, err := h.warehouseService.GetNextDocumentNumber(c.Context(), fiscalYearID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}
