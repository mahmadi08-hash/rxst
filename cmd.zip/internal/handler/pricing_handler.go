package handler

import (
	"strconv"

	"rx-st-system/internal/dto"
	"rx-st-system/internal/service"
	"rx-st-system/pkg/errors"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
)

// PricingHandler handles pricing endpoints
type PricingHandler struct {
	pricingService *service.PricingService
	validator      *validator.Validate
}

// NewPricingHandler creates a new PricingHandler
func NewPricingHandler(pricingService *service.PricingService) *PricingHandler {
	return &PricingHandler{
		pricingService: pricingService,
		validator:      validator.New(),
	}
}

// CalculatePrice calculates price for an order
// @Summary Calculate Price
// @Description Calculate price based on order details
// @Tags pricing
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.CalculatePriceRequest true "Price calculation request"
// @Success 200 {object} dto.CalculatePriceResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/pricing/calculate [post]
func (h *PricingHandler) CalculatePrice(c *fiber.Ctx) error {
	var req dto.CalculatePriceRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.pricingService.CalculatePrice(c.Context(), req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// CreatePriceRule creates a new price rule
// @Summary Create Price Rule
// @Description Create a new pricing rule
// @Tags pricing
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.CreatePriceRuleRequest true "Price rule details"
// @Success 201 {object} dto.PriceRuleResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/pricing/rules [post]
func (h *PricingHandler) CreatePriceRule(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.CreatePriceRuleRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.pricingService.CreatePriceRule(c.Context(), req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.Status(fiber.StatusCreated).JSON(response)
}

// GetPriceRule gets a price rule by ID
// @Summary Get Price Rule
// @Description Get price rule details
// @Tags pricing
// @Produce json
// @Security BearerAuth
// @Param id path int true "Rule ID"
// @Success 200 {object} dto.PriceRuleResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/pricing/rules/{id} [get]
func (h *PricingHandler) GetPriceRule(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid rule ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	response, err := h.pricingService.GetPriceRule(c.Context(), id)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// ListPriceRules lists price rules
// @Summary List Price Rules
// @Description List all price rules with pagination
// @Tags pricing
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.ListPriceRulesRequest true "List parameters"
// @Success 200 {object} dto.ListResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/pricing/rules/list [post]
func (h *PricingHandler) ListPriceRules(c *fiber.Ctx) error {
	var req dto.ListPriceRulesRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	// Set defaults
	if req.Page == 0 {
		req.Page = 1
	}
	if req.PageSize == 0 {
		req.PageSize = 20
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.pricingService.ListPriceRules(c.Context(), req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// UpdatePriceRule updates a price rule
// @Summary Update Price Rule
// @Description Update price rule details
// @Tags pricing
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param id path int true "Rule ID"
// @Param request body dto.UpdatePriceRuleRequest true "Update details"
// @Success 200 {object} dto.PriceRuleResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/pricing/rules/{id} [put]
func (h *PricingHandler) UpdatePriceRule(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid rule ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	var req dto.UpdatePriceRuleRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.pricingService.UpdatePriceRule(c.Context(), id, req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// DeletePriceRule deletes a price rule
// @Summary Delete Price Rule
// @Description Delete a price rule
// @Tags pricing
// @Produce json
// @Security BearerAuth
// @Param id path int true "Rule ID"
// @Success 200 {object} dto.SuccessResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/pricing/rules/{id} [delete]
func (h *PricingHandler) DeletePriceRule(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid rule ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.pricingService.DeletePriceRule(c.Context(), id); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Price rule deleted successfully",
	})
}

// UpdateProductPrice updates product price
// @Summary Update Product Price
// @Description Update base price for a product
// @Tags pricing
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.UpdateProductPriceRequest true "Price update"
// @Success 200 {object} dto.ProductPriceResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/pricing/products/price [put]
func (h *PricingHandler) UpdateProductPrice(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.UpdateProductPriceRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.pricingService.UpdateProductPrice(c.Context(), req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// BulkUpdatePrice updates multiple product prices
// @Summary Bulk Update Prices
// @Description Update prices for multiple products
// @Tags pricing
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.BulkUpdatePriceRequest true "Bulk update"
// @Success 200 {object} dto.SuccessResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/pricing/products/bulk-update [post]
func (h *PricingHandler) BulkUpdatePrice(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.BulkUpdatePriceRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	if err := h.pricingService.BulkUpdatePrice(c.Context(), req, userID); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "Prices updated successfully",
	})
}
