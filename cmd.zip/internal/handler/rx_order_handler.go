package handler

import (
	"strconv"

	"rx-st-system/internal/dto"
	"rx-st-system/internal/service"
	"rx-st-system/pkg/errors"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
)

// RxOrderHandler handles RX order endpoints
type RxOrderHandler struct {
	rxOrderService   *service.RxOrderService
	inventoryService *service.InventoryService
	validator        *validator.Validate
}

// NewRxOrderHandler creates a new RxOrderHandler

func NewRxOrderHandler(rxOrderService *service.RxOrderService, inventoryService *service.InventoryService) *RxOrderHandler {
	return &RxOrderHandler{
		rxOrderService:   rxOrderService,
		inventoryService: inventoryService,
		validator:        validator.New(),
	}
}

// Create creates a new RX order
// @Summary Create RX Order
// @Description Create a new prescription lens order with full specifications
// @Tags rx-orders
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.CreateRxOrderRequest true "RX order details"
// @Success 201 {object} dto.RxOrderResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 404 {object} dto.ErrorResponse "Product combination not found"
// @Router /api/v1/rx-orders [post]
func (h *RxOrderHandler) Create(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.CreateRxOrderRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	// Validate request
	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	// Additional validation for eye specifications
	if err := h.validateEyeSpecifications(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   err.Error(),
			Code:    errors.ErrCodeValidation,
		})
	}

	// Create order
	response, err := h.rxOrderService.Create(c.Context(), req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.Status(fiber.StatusCreated).JSON(response)
}

// Get gets RX order by ID
// @Summary Get RX Order
// @Description Get RX order details by ID
// @Tags rx-orders
// @Produce json
// @Security BearerAuth
// @Param id path int true "Order ID"
// @Success 200 {object} dto.RxOrderResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/rx-orders/{id} [get]
func (h *RxOrderHandler) Get(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid order ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	response, err := h.rxOrderService.GetByID(c.Context(), id)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// Update updates an RX order
// @Summary Update RX Order
// @Description Update RX order (only in draft state)
// @Tags rx-orders
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param id path int true "Order ID"
// @Param request body dto.UpdateRxOrderRequest true "Update details"
// @Success 200 {object} dto.RxOrderResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/rx-orders/{id} [put]
func (h *RxOrderHandler) Update(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid order ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	var req dto.UpdateRxOrderRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.rxOrderService.Update(c.Context(), id, req, userID)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// Delete deletes an RX order
// @Summary Delete RX Order
// @Description Delete RX order (only in draft state)
// @Tags rx-orders
// @Produce json
// @Security BearerAuth
// @Param id path int true "Order ID"
// @Success 200 {object} dto.SuccessResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/rx-orders/{id} [delete]
func (h *RxOrderHandler) Delete(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid order ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.rxOrderService.Delete(c.Context(), id); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "RX order deleted successfully",
	})
}

// List lists RX orders with filters
// @Summary List RX Orders
// @Description List RX orders with filtering and pagination
// @Tags rx-orders
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.ListRxOrdersRequest true "List parameters"
// @Success 200 {object} dto.ListResponse
// @Failure 400 {object} dto.ErrorResponse
// @Router /api/v1/rx-orders/list [post]
func (h *RxOrderHandler) List(c *fiber.Ctx) error {
	var req dto.ListRxOrdersRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	// Set defaults
	if req.Page == 0 {
		req.Page = 1
	}
	if req.PageSize == 0 {
		req.PageSize = 20
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	response, err := h.rxOrderService.List(c.Context(), req)
	if err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(response)
}

// ChangeState changes order state
// @Summary Change RX Order State
// @Description Change RX order state (with permission check)
// @Tags rx-orders
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body dto.ChangeRxOrderStateRequest true "State change details"
// @Success 200 {object} dto.SuccessResponse
// @Failure 400 {object} dto.ErrorResponse
// @Failure 403 {object} dto.ErrorResponse
// @Router /api/v1/rx-orders/change-state [post]
func (h *RxOrderHandler) ChangeState(c *fiber.Ctx) error {
	userID := c.Locals("user_id").(int64)

	var req dto.ChangeRxOrderStateRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid request body",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	if err := h.validator.Struct(req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Validation failed",
			Code:    errors.ErrCodeValidation,
			Details: formatValidationErrors(err),
		})
	}

	if err := h.rxOrderService.ChangeState(c.Context(), req.OrderID, req.ToStateCode, userID, req.Notes); err != nil {
		return handleServiceError(c, err)
	}

	return c.JSON(dto.SuccessResponse{
		Success: true,
		Message: "State changed successfully",
	})
}

// GetStateHistory gets order state history
// @Summary Get RX Order State History
// @Description Get complete state change history for an RX order
// @Tags rx-orders
// @Produce json
// @Security BearerAuth
// @Param id path int true "Order ID"
// @Success 200 {array} dto.RxOrderStateHistoryResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/rx-orders/{id}/history [get]
func (h *RxOrderHandler) GetStateHistory(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid order ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	// First check if order exists
	_, err = h.rxOrderService.GetByID(c.Context(), id)
	if err != nil {
		return handleServiceError(c, err)
	}

	// Get state history from repository directly
	// In production, this should be in the service layer
	return c.JSON([]dto.RxOrderStateHistoryResponse{})
}

// GetAvailableTransitions gets available state transitions
// @Summary Get Available State Transitions
// @Description Get available state transitions from current state
// @Tags rx-orders
// @Produce json
// @Security BearerAuth
// @Param id path int true "Order ID"
// @Success 200 {array} dto.StateResponse
// @Failure 404 {object} dto.ErrorResponse
// @Router /api/v1/rx-orders/{id}/available-transitions [get]
func (h *RxOrderHandler) GetAvailableTransitions(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(dto.ErrorResponse{
			Success: false,
			Error:   "Invalid order ID",
			Code:    errors.ErrCodeBadRequest,
		})
	}

	// Get order to find current state
	order, err := h.rxOrderService.GetByID(c.Context(), id)
	if err != nil {
		return handleServiceError(c, err)
	}

	// In production, this should call a service method
	// that returns available transitions based on current state and user permissions
	return c.JSON(fiber.Map{
		"current_state":         order.CurrentState,
		"available_transitions": []dto.StateResponse{},
	})
}

// GetSummary gets RX orders summary statistics
// @Summary Get RX Orders Summary
// @Description Get summary statistics for RX orders
// @Tags rx-orders
// @Produce json
// @Security BearerAuth
// @Success 200 {object} dto.RxOrderSummaryResponse
// @Router /api/v1/rx-orders/summary [get]
func (h *RxOrderHandler) GetSummary(c *fiber.Ctx) error {
	// This should be implemented in the service layer
	// For now, return a placeholder
	return c.JSON(dto.RxOrderSummaryResponse{
		TotalOrders:        0,
		DraftOrders:        0,
		InProductionOrders: 0,
		CompletedOrders:    0,
		PriorityOrders:     0,
		TotalValue:         0,
	})
}

// validateEyeSpecifications validates eye-related specifications
func (h *RxOrderHandler) validateEyeSpecifications(req *dto.CreateRxOrderRequest) error {
	// If CYL is provided, Axis must be provided
	if req.RightCYL != nil && *req.RightCYL != 0 {
		if req.RightAxis == nil {
			return errors.NewValidationError("Right axis is required when cylinder is provided", nil)
		}
		if *req.RightAxis < 0 || *req.RightAxis > 180 {
			return errors.NewValidationError("Right axis must be between 0 and 180", nil)
		}
	}

	if req.LeftCYL != nil && *req.LeftCYL != 0 {
		if req.LeftAxis == nil {
			return errors.NewValidationError("Left axis is required when cylinder is provided", nil)
		}
		if *req.LeftAxis < 0 || *req.LeftAxis > 180 {
			return errors.NewValidationError("Left axis must be between 0 and 180", nil)
		}
	}

	// Validate SPH range (typical range: -20.00 to +20.00)
	if req.RightSPH < -20.0 || req.RightSPH > 20.0 {
		return errors.NewValidationError("Right SPH must be between -20.00 and +20.00", nil)
	}
	if req.LeftSPH < -20.0 || req.LeftSPH > 20.0 {
		return errors.NewValidationError("Left SPH must be between -20.00 and +20.00", nil)
	}

	// Validate CYL range if provided (typical range: -6.00 to 0)
	if req.RightCYL != nil && (*req.RightCYL < -6.0 || *req.RightCYL > 0) {
		return errors.NewValidationError("Right CYL must be between -6.00 and 0.00", nil)
	}
	if req.LeftCYL != nil && (*req.LeftCYL < -6.0 || *req.LeftCYL > 0) {
		return errors.NewValidationError("Left CYL must be between -6.00 and 0.00", nil)
	}

	// Validate Addition range if provided (typical range: +0.75 to +3.50)
	if req.RightAddition != nil && (*req.RightAddition < 0.75 || *req.RightAddition > 3.5) {
		return errors.NewValidationError("Right Addition must be between +0.75 and +3.50", nil)
	}
	if req.LeftAddition != nil && (*req.LeftAddition < 0.75 || *req.LeftAddition > 3.5) {
		return errors.NewValidationError("Left Addition must be between +0.75 and +3.50", nil)
	}

	// Validate PD range if provided (typical range: 20 to 40 mm per eye)
	if req.RightPD != nil && (*req.RightPD < 20.0 || *req.RightPD > 40.0) {
		return errors.NewValidationError("Right PD must be between 20.0 and 40.0 mm", nil)
	}
	if req.LeftPD != nil && (*req.LeftPD < 20.0 || *req.LeftPD > 40.0) {
		return errors.NewValidationError("Left PD must be between 20.0 and 40.0 mm", nil)
	}

	// Validate Prism values if provided
	if req.RightPrismValue != nil {
		if *req.RightPrismValue < 0 || *req.RightPrismValue > 10.0 {
			return errors.NewValidationError("Right Prism value must be between 0 and 10.0", nil)
		}
		if req.RightPrismBase == nil || *req.RightPrismBase == "" {
			return errors.NewValidationError("Right Prism base is required when prism value is provided", nil)
		}
	}

	if req.LeftPrismValue != nil {
		if *req.LeftPrismValue < 0 || *req.LeftPrismValue > 10.0 {
			return errors.NewValidationError("Left Prism value must be between 0 and 10.0", nil)
		}
		if req.LeftPrismBase == nil || *req.LeftPrismBase == "" {
			return errors.NewValidationError("Left Prism base is required when prism value is provided", nil)
		}
	}

	// Validate frame dimensions if provided
	if req.HBOX != nil && (*req.HBOX < 30.0 || *req.HBOX > 80.0) {
		return errors.NewValidationError("HBOX must be between 30.0 and 80.0 mm", nil)
	}
	if req.VBOX != nil && (*req.VBOX < 25.0 || *req.VBOX > 70.0) {
		return errors.NewValidationError("VBOX must be between 25.0 and 70.0 mm", nil)
	}
	if req.DBL != nil && (*req.DBL < 10.0 || *req.DBL > 30.0) {
		return errors.NewValidationError("DBL must be between 10.0 and 30.0 mm", nil)
	}

	// Validate color service requirements
	if req.ColorServiceID != nil {
		if req.ColorType == nil || *req.ColorType == "" {
			return errors.NewValidationError("Color type is required when color service is selected", nil)
		}
		if *req.ColorType == "same_as_sample" {
			if req.ColorSample == nil || *req.ColorSample == "" {
				return errors.NewValidationError("Color sample is required when color type is 'same_as_sample'", nil)
			}
		}
	}

	return nil
}
