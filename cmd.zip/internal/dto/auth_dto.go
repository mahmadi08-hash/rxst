package dto

import "time"

// LoginRequest represents login request
type LoginRequest struct {
	Username string `json:"username" validate:"required"`
	Password string `json:"password" validate:"required"`
}

// LoginResponse represents login response
type LoginResponse struct {
	AccessToken  string    `json:"access_token"`
	RefreshToken string    `json:"refresh_token,omitempty"`
	TokenType    string    `json:"token_type"`
	ExpiresIn    int64     `json:"expires_in"`
	User         *UserInfo `json:"user"`
}

// RegisterRequest represents registration request
type RegisterRequest struct {
	EntityID     int64  `json:"entity_id" validate:"required"`
	Username     string `json:"username" validate:"required,min=3,max=50"`
	Password     string `json:"password" validate:"required,min=8"`
	MobileNumber string `json:"mobile_number" validate:"required"`
	Email        string `json:"email,omitempty" validate:"omitempty,email"`
}

// RegisterResponse represents registration response
type RegisterResponse struct {
	Message string `json:"message"`
	UserID  int64  `json:"user_id"`
}

// RefreshTokenRequest represents refresh token request
type RefreshTokenRequest struct {
	RefreshToken string `json:"refresh_token" validate:"required"`
}

// ChangePasswordRequest represents change password request
type ChangePasswordRequest struct {
	OldPassword string `json:"old_password" validate:"required"`
	NewPassword string `json:"new_password" validate:"required,min=8"`
}

// UserInfo represents user information
type UserInfo struct {
	ID            int64      `json:"id"`
	Username      string     `json:"username"`
	EntityID      int64      `json:"entity_id"`
	MobileNumber  string     `json:"mobile_number"`
	Email         *string    `json:"email,omitempty"`
	IsSystemAdmin bool       `json:"is_system_admin"`
	IsActive      bool       `json:"is_active"`
	IsApproved    bool       `json:"is_approved"`
	LastLogin     *time.Time `json:"last_login,omitempty"`
}

// ApproveUserRequest represents approve user request
type ApproveUserRequest struct {
	UserID   int64 `json:"user_id" validate:"required"`
	Approved bool  `json:"approved"`
}

// ListUsersRequest represents list users request
type ListUsersRequest struct {
	Search     string `json:"search,omitempty"`
	IsActive   *bool  `json:"is_active,omitempty"`
	IsApproved *bool  `json:"is_approved,omitempty"`
	Page       int    `json:"page" validate:"min=1"`
	PageSize   int    `json:"page_size" validate:"min=1,max=100"`
}

// UserResponse represents user response
type UserResponse struct {
	ID            int64      `json:"id"`
	Username      string     `json:"username"`
	EntityID      int64      `json:"entity_id"`
	EntityName    string     `json:"entity_name,omitempty"`
	MobileNumber  string     `json:"mobile_number"`
	Email         *string    `json:"email,omitempty"`
	IsSystemAdmin bool       `json:"is_system_admin"`
	IsActive      bool       `json:"is_active"`
	IsApproved    bool       `json:"is_approved"`
	LastLogin     *time.Time `json:"last_login,omitempty"`
	CreatedAt     time.Time  `json:"created_at"`
}
