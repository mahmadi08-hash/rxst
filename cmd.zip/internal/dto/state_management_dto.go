package dto

import "time"

// StateManagementStateResponse represents a state
type StateManagementStateResponse struct {
	ID           int64     `json:"id"`
	StateCode    string    `json:"state_code"`
	StateName    string    `json:"state_name"`
	StateType    string    `json:"state_type"` // initial, intermediate, final
	Description  *string   `json:"description,omitempty"`
	Color        *string   `json:"color,omitempty"` // For UI
	Icon         *string   `json:"icon,omitempty"`
	DisplayOrder int32     `json:"display_order"`
	IsActive     bool      `json:"is_active"`
	CreatedAt    time.Time `json:"created_at"`
}

// CreateStateRequest represents create state request
type CreateStateRequest struct {
	StateCode    string  `json:"state_code" validate:"required,max=50"`
	StateName    string  `json:"state_name" validate:"required,max=100"`
	StateType    string  `json:"state_type" validate:"required,oneof=initial intermediate final"`
	Description  *string `json:"description,omitempty"`
	Color        *string `json:"color,omitempty"`
	Icon         *string `json:"icon,omitempty"`
	DisplayOrder int32   `json:"display_order" validate:"required"`
	IsActive     bool    `json:"is_active"`
}

// UpdateStateRequest represents update state request
type UpdateStateRequest struct {
	StateName    *string `json:"state_name,omitempty"`
	Description  *string `json:"description,omitempty"`
	Color        *string `json:"color,omitempty"`
	Icon         *string `json:"icon,omitempty"`
	DisplayOrder *int32  `json:"display_order,omitempty"`
	IsActive     *bool   `json:"is_active,omitempty"`
}

// StateTransitionDetailResponse represents a state transition with details
type StateTransitionDetailResponse struct {
	ID                  int64                         `json:"id"`
	FromState           *StateManagementStateResponse `json:"from_state"`
	ToState             *StateManagementStateResponse `json:"to_state"`
	TransitionName      string                        `json:"transition_name"`
	Description         *string                       `json:"description,omitempty"`
	RequiresApproval    bool                          `json:"requires_approval"`
	RequiresComment     bool                          `json:"requires_comment"`
	AutoTransition      bool                          `json:"auto_transition"`
	TransitionCondition *string                       `json:"transition_condition,omitempty"`
	DisplayOrder        int32                         `json:"display_order"`
	IsActive            bool                          `json:"is_active"`
	CreatedAt           time.Time                     `json:"created_at"`
}

// CreateStateTransitionRequest represents create transition request
type CreateStateTransitionRequest struct {
	FromStateID         int64   `json:"from_state_id" validate:"required"`
	ToStateID           int64   `json:"to_state_id" validate:"required"`
	TransitionName      string  `json:"transition_name" validate:"required,max=100"`
	Description         *string `json:"description,omitempty"`
	RequiresApproval    bool    `json:"requires_approval"`
	RequiresComment     bool    `json:"requires_comment"`
	AutoTransition      bool    `json:"auto_transition"`
	TransitionCondition *string `json:"transition_condition,omitempty"`
	DisplayOrder        int32   `json:"display_order" validate:"required"`
	IsActive            bool    `json:"is_active"`
}

// UpdateStateTransitionRequest represents update transition request
type UpdateStateTransitionRequest struct {
	TransitionName      *string `json:"transition_name,omitempty"`
	Description         *string `json:"description,omitempty"`
	RequiresApproval    *bool   `json:"requires_approval,omitempty"`
	RequiresComment     *bool   `json:"requires_comment,omitempty"`
	AutoTransition      *bool   `json:"auto_transition,omitempty"`
	TransitionCondition *string `json:"transition_condition,omitempty"`
	DisplayOrder        *int32  `json:"display_order,omitempty"`
	IsActive            *bool   `json:"is_active,omitempty"`
}

// StateTransitionPermissionResponse represents transition permission
type StateTransitionPermissionResponse struct {
	ID             int64     `json:"id"`
	TransitionID   int64     `json:"transition_id"`
	PermissionType string    `json:"permission_type"` // user, group, role
	UserID         *int64    `json:"user_id,omitempty"`
	GroupID        *int64    `json:"group_id,omitempty"`
	RoleID         *int64    `json:"role_id,omitempty"`
	CreatedAt      time.Time `json:"created_at"`
}

// CreateStateTransitionPermissionRequest represents create permission request
type CreateStateTransitionPermissionRequest struct {
	TransitionID   int64  `json:"transition_id" validate:"required"`
	PermissionType string `json:"permission_type" validate:"required,oneof=user group role"`
	UserID         *int64 `json:"user_id,omitempty"`
	GroupID        *int64 `json:"group_id,omitempty"`
	RoleID         *int64 `json:"role_id,omitempty"`
}

// GetAvailableTransitionsRequest represents get available transitions request
type GetAvailableTransitionsRequest struct {
	EntityType string `json:"entity_type" validate:"required,oneof=rx_order st_order"`
	EntityID   int64  `json:"entity_id" validate:"required"`
	UserID     int64  `json:"user_id" validate:"required"`
}

// GetAvailableTransitionsResponse represents available transitions
type GetAvailableTransitionsResponse struct {
	EntityType           string                          `json:"entity_type"`
	EntityID             int64                           `json:"entity_id"`
	CurrentState         *StateManagementStateResponse   `json:"current_state"`
	AvailableTransitions []StateTransitionDetailResponse `json:"available_transitions"`
}

// ExecuteTransitionRequest represents execute transition request
type ExecuteTransitionRequest struct {
	EntityType  string  `json:"entity_type" validate:"required,oneof=rx_order st_order"`
	EntityID    int64   `json:"entity_id" validate:"required"`
	ToStateCode string  `json:"to_state_code" validate:"required"`
	Comment     *string `json:"comment,omitempty"`
}

// ExecuteTransitionResponse represents transition execution result
type ExecuteTransitionResponse struct {
	Success    bool                          `json:"success"`
	Message    string                        `json:"message"`
	OldState   *StateManagementStateResponse `json:"old_state"`
	NewState   *StateManagementStateResponse `json:"new_state"`
	ExecutedAt time.Time                     `json:"executed_at"`
}

// ValidateTransitionRequest represents validate transition request
type ValidateTransitionRequest struct {
	EntityType  string `json:"entity_type" validate:"required,oneof=rx_order st_order"`
	EntityID    int64  `json:"entity_id" validate:"required"`
	ToStateCode string `json:"to_state_code" validate:"required"`
	UserID      int64  `json:"user_id" validate:"required"`
}

// ValidateTransitionResponse represents validation result
type ValidateTransitionResponse struct {
	IsValid          bool     `json:"is_valid"`
	CanTransition    bool     `json:"can_transition"`
	HasPermission    bool     `json:"has_permission"`
	RequiresApproval bool     `json:"requires_approval"`
	RequiresComment  bool     `json:"requires_comment"`
	ValidationErrors []string `json:"validation_errors,omitempty"`
	Message          string   `json:"message"`
}

// StateHistoryDetailResponse represents state change history
type StateHistoryDetailResponse struct {
	ID            int64                         `json:"id"`
	EntityType    string                        `json:"entity_type"`
	EntityID      int64                         `json:"entity_id"`
	FromState     *StateManagementStateResponse `json:"from_state,omitempty"`
	ToState       *StateManagementStateResponse `json:"to_state"`
	ChangedBy     *int64                        `json:"changed_by,omitempty"`
	ChangedByName *string                       `json:"changed_by_name,omitempty"`
	Comment       *string                       `json:"comment,omitempty"`
	Duration      *int64                        `json:"duration,omitempty"` // seconds in previous state
	ChangeDate    time.Time                     `json:"change_date"`
}

// GetStateHistoryRequest represents get state history request
type GetStateHistoryRequest struct {
	EntityType string `json:"entity_type" validate:"required,oneof=rx_order st_order"`
	EntityID   int64  `json:"entity_id" validate:"required"`
}

// StateStatisticsRequest represents state statistics request
type StateStatisticsRequest struct {
	EntityType string  `json:"entity_type" validate:"required,oneof=rx_order st_order"`
	FromDate   *string `json:"from_date,omitempty"`
	ToDate     *string `json:"to_date,omitempty"`
}

// StateStatisticsResponse represents state statistics
type StateStatisticsResponse struct {
	EntityType        string                 `json:"entity_type"`
	TotalEntities     int64                  `json:"total_entities"`
	StateDistribution []StateDistribution    `json:"state_distribution"`
	TransitionStats   []TransitionStatistics `json:"transition_stats"`
	AverageDuration   map[string]float64     `json:"average_duration"` // state_code -> avg seconds
}

// StateDistribution represents distribution of entities in states
type StateDistribution struct {
	State      *StateManagementStateResponse `json:"state"`
	Count      int64                         `json:"count"`
	Percentage float64                       `json:"percentage"`
}

// TransitionStatistics represents transition usage statistics
type TransitionStatistics struct {
	TransitionID    int64   `json:"transition_id"`
	TransitionName  string  `json:"transition_name"`
	UsageCount      int64   `json:"usage_count"`
	AverageDuration float64 `json:"average_duration"` // seconds
}

// BulkTransitionRequest represents bulk transition request
type BulkTransitionRequest struct {
	EntityType  string  `json:"entity_type" validate:"required,oneof=rx_order st_order"`
	EntityIDs   []int64 `json:"entity_ids" validate:"required,min=1,max=100"`
	ToStateCode string  `json:"to_state_code" validate:"required"`
	Comment     *string `json:"comment,omitempty"`
}

// BulkTransitionResponse represents bulk transition result
type BulkTransitionResponse struct {
	SuccessCount int                    `json:"success_count"`
	FailedCount  int                    `json:"failed_count"`
	TotalCount   int                    `json:"total_count"`
	Results      []BulkTransitionResult `json:"results"`
}

// BulkTransitionResult represents individual transition result
type BulkTransitionResult struct {
	EntityID int64   `json:"entity_id"`
	Success  bool    `json:"success"`
	Message  string  `json:"message,omitempty"`
	Error    *string `json:"error,omitempty"`
}

// StateMachineConfigResponse represents state machine configuration
type StateMachineConfigResponse struct {
	EntityType   string                          `json:"entity_type"`
	States       []StateManagementStateResponse  `json:"states"`
	Transitions  []StateTransitionDetailResponse `json:"transitions"`
	InitialState *StateManagementStateResponse   `json:"initial_state"`
	FinalStates  []StateManagementStateResponse  `json:"final_states"`
}
type ChangeStateRequest struct {
	OrderID      int64   `json:"order_id"`
	NewStateCode string  `json:"new_state_code"`
	Notes        *string `json:"notes,omitempty"`
}
