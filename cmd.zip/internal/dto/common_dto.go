package dto

// PaginationRequest represents pagination parameters
type PaginationRequest struct {
	Page     int `json:"page" validate:"min=1"`
	PageSize int `json:"page_size" validate:"min=1,max=100"`
}

// PaginationResponse represents pagination metadata
type PaginationResponse struct {
	Page       int   `json:"page"`
	PageSize   int   `json:"page_size"`
	Total      int64 `json:"total"`
	TotalPages int   `json:"total_pages"`
}

// ListResponse represents a paginated list response
type ListResponse struct {
	Data       interface{}         `json:"data"`
	Pagination *PaginationResponse `json:"pagination"`
}

// SuccessResponse represents a success response
type SuccessResponse struct {
	Success bool        `json:"success"`
	Message string      `json:"message,omitempty"`
	Data    interface{} `json:"data,omitempty"`
}

// ErrorResponse represents an error response
type ErrorResponse struct {
	Success   bool                   `json:"success"`
	Error     string                 `json:"error"`
	Code      string                 `json:"code,omitempty"`
	Details   map[string]interface{} `json:"details,omitempty"`
	TraceID   string                 `json:"trace_id,omitempty"`
	Timestamp string                 `json:"timestamp"`
}

// Filter represents a filter condition
type Filter struct {
	Field    string      `json:"field" validate:"required"`
	Operator string      `json:"operator" validate:"required,oneof=eq neq gt gte lt lte like ilike in nin between is_null is_not_null"`
	Value    interface{} `json:"value"`
	DataType string      `json:"data_type,omitempty" validate:"omitempty,oneof=string number boolean date array"`
}

// SortField represents a sort field
type SortField struct {
	Field     string `json:"field" validate:"required"`
	Direction string `json:"direction" validate:"required,oneof=asc desc"`
}

// FilterRequest represents a dynamic filter request
type FilterRequest struct {
	Filters    []Filter           `json:"filters,omitempty"`
	Sort       []SortField        `json:"sort,omitempty"`
	Pagination PaginationRequest  `json:"pagination"`
}

// CalculateTotalPages calculates total pages
func CalculateTotalPages(total int64, pageSize int) int {
	if total == 0 || pageSize == 0 {
		return 0
	}
	return int((total + int64(pageSize) - 1) / int64(pageSize))
}

// NewPaginationResponse creates a new pagination response
func NewPaginationResponse(page, pageSize int, total int64) *PaginationResponse {
	return &PaginationResponse{
		Page:       page,
		PageSize:   pageSize,
		Total:      total,
		TotalPages: CalculateTotalPages(total, pageSize),
	}
}

// NewListResponse creates a new list response
func NewListResponse(data interface{}, pagination *PaginationResponse) *ListResponse {
	return &ListResponse{
		Data:       data,
		Pagination: pagination,
	}
}

// NewSuccessResponse creates a new success response
func NewSuccessResponse(message string, data interface{}) *SuccessResponse {
	return &SuccessResponse{
		Success: true,
		Message: message,
		Data:    data,
	}
}
