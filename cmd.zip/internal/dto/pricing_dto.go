package dto

import "time"

// PriceRuleResponse represents a pricing rule
type PriceRuleResponse struct {
	ID          int64     `json:"id"`
	RuleCode    string    `json:"rule_code"`
	RuleName    string    `json:"rule_name"`
	Description *string   `json:"description,omitempty"`
	RuleType    string    `json:"rule_type"` // base_price, service_price, discount, markup
	Priority    int32     `json:"priority"`
	IsActive    bool      `json:"is_active"`
	ValidFrom   time.Time `json:"valid_from"`
	ValidTo     *time.Time `json:"valid_to,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// CreatePriceRuleRequest represents create price rule request
type CreatePriceRuleRequest struct {
	RuleCode    string  `json:"rule_code" validate:"required,max=50"`
	RuleName    string  `json:"rule_name" validate:"required,max=200"`
	Description *string `json:"description,omitempty"`
	RuleType    string  `json:"rule_type" validate:"required,oneof=base_price service_price discount markup"`
	Priority    int32   `json:"priority" validate:"min=0,max=100"`
	IsActive    bool    `json:"is_active"`
	ValidFrom   string  `json:"valid_from" validate:"required"`
	ValidTo     *string `json:"valid_to,omitempty"`
}

// UpdatePriceRuleRequest represents update price rule request
type UpdatePriceRuleRequest struct {
	RuleName    *string `json:"rule_name,omitempty"`
	Description *string `json:"description,omitempty"`
	Priority    *int32  `json:"priority,omitempty"`
	IsActive    *bool   `json:"is_active,omitempty"`
	ValidFrom   *string `json:"valid_from,omitempty"`
	ValidTo     *string `json:"valid_to,omitempty"`
}

// CalculatePriceRequest represents calculate price request
type CalculatePriceRequest struct {
	OrderType   string `json:"order_type" validate:"required,oneof=rx st"`
	CustomerID  int64  `json:"customer_id" validate:"required"`
	
	// RX Order specific
	LensBrandID    *int64 `json:"lens_brand_id,omitempty"`
	LensTypeID     *int64 `json:"lens_type_id,omitempty"`
	LensIndexID    *int64 `json:"lens_index_id,omitempty"`
	LensMaterialID *int64 `json:"lens_material_id,omitempty"`
	LensColorID    *int64 `json:"lens_color_id,omitempty"`
	LensDesignID   *int64 `json:"lens_design_id,omitempty"`
	
	// Services
	CoatingServiceID *int64   `json:"coating_service_id,omitempty"`
	ColorServiceID   *int64   `json:"color_service_id,omitempty"`
	ExtraServiceIDs  []int64  `json:"extra_service_ids,omitempty"`
	IsPriority       bool     `json:"is_priority"`
	
	// ST Order specific
	ProductIDs []int64 `json:"product_ids,omitempty"`
	Quantities []float64 `json:"quantities,omitempty"`
	
	// Common
	CalculationDate *string `json:"calculation_date,omitempty"`
}

// CalculatePriceResponse represents calculate price response
type CalculatePriceResponse struct {
	BasePrice       float64                    `json:"base_price"`
	ServicePrice    float64                    `json:"service_price"`
	SubTotal        float64                    `json:"sub_total"`
	DiscountAmount  float64                    `json:"discount_amount"`
	TaxAmount       float64                    `json:"tax_amount"`
	TotalPrice      float64                    `json:"total_price"`
	AppliedRules    []AppliedPriceRuleResponse `json:"applied_rules"`
	Breakdown       PriceBreakdownResponse     `json:"breakdown"`
	CalculatedAt    time.Time                  `json:"calculated_at"`
}

// AppliedPriceRuleResponse represents an applied rule in calculation
type AppliedPriceRuleResponse struct {
	RuleID      int64   `json:"rule_id"`
	RuleCode    string  `json:"rule_code"`
	RuleName    string  `json:"rule_name"`
	RuleType    string  `json:"rule_type"`
	Amount      float64 `json:"amount"`
	Description string  `json:"description"`
}

// PriceBreakdownResponse represents detailed price breakdown
type PriceBreakdownResponse struct {
	ProductPrice     float64            `json:"product_price"`
	CoatingPrice     float64            `json:"coating_price"`
	ColorPrice       float64            `json:"color_price"`
	ExtraServices    []ServicePriceItem `json:"extra_services"`
	PriorityFee      float64            `json:"priority_fee"`
	Discounts        []DiscountItem     `json:"discounts"`
	Taxes            []TaxItem          `json:"taxes"`
}

// ServicePriceItem represents a service price item
type ServicePriceItem struct {
	ServiceID   int64   `json:"service_id"`
	ServiceName string  `json:"service_name"`
	Price       float64 `json:"price"`
}

// DiscountItem represents a discount item
type DiscountItem struct {
	DiscountType string  `json:"discount_type"` // percentage, fixed_amount, rule_based
	Description  string  `json:"description"`
	Amount       float64 `json:"amount"`
}

// TaxItem represents a tax item
type TaxItem struct {
	TaxType     string  `json:"tax_type"` // vat, sales_tax, etc.
	Description string  `json:"description"`
	Rate        float64 `json:"rate"` // percentage
	Amount      float64 `json:"amount"`
}

// ListPriceRulesRequest represents list price rules request
type ListPriceRulesRequest struct {
	RuleType   *string `json:"rule_type,omitempty"`
	IsActive   *bool   `json:"is_active,omitempty"`
	ValidDate  *string `json:"valid_date,omitempty"`
	Page       int     `json:"page" validate:"min=1"`
	PageSize   int     `json:"page_size" validate:"min=1,max=100"`
}

// PriceHistoryResponse represents price history
type PriceHistoryResponse struct {
	ID              int64     `json:"id"`
	EntityType      string    `json:"entity_type"` // product, service
	EntityID        int64     `json:"entity_id"`
	OldPrice        float64   `json:"old_price"`
	NewPrice        float64   `json:"new_price"`
	ChangeReason    *string   `json:"change_reason,omitempty"`
	ChangedBy       *int64    `json:"changed_by,omitempty"`
	ChangedAt       time.Time `json:"changed_at"`
}

// ProductPriceResponse represents product price
type ProductPriceResponse struct {
	ProductID     int64     `json:"product_id"`
	ProductCode   string    `json:"product_code"`
	ProductName   string    `json:"product_name"`
	BasePrice     float64   `json:"base_price"`
	SalePrice     *float64  `json:"sale_price,omitempty"`
	MinPrice      *float64  `json:"min_price,omitempty"`
	MaxPrice      *float64  `json:"max_price,omitempty"`
	Currency      string    `json:"currency"`
	EffectiveDate time.Time `json:"effective_date"`
}

// UpdateProductPriceRequest represents update product price request
type UpdateProductPriceRequest struct {
	ProductID    int64   `json:"product_id" validate:"required"`
	BasePrice    float64 `json:"base_price" validate:"required,gt=0"`
	SalePrice    *float64 `json:"sale_price,omitempty" validate:"omitempty,gt=0"`
	ChangeReason string  `json:"change_reason" validate:"required"`
}

// BulkUpdatePriceRequest represents bulk price update
type BulkUpdatePriceRequest struct {
	ProductIDs      []int64 `json:"product_ids" validate:"required,min=1"`
	UpdateType      string  `json:"update_type" validate:"required,oneof=percentage fixed_amount set_price"`
	Value           float64 `json:"value" validate:"required"`
	ChangeReason    string  `json:"change_reason" validate:"required"`
	ApplyToSalePrice bool   `json:"apply_to_sale_price"`
}

// PriceSimulationRequest represents price simulation request
type PriceSimulationRequest struct {
	OrderType      string           `json:"order_type" validate:"required,oneof=rx st"`
	CustomerID     int64            `json:"customer_id" validate:"required"`
	Items          []SimulationItem `json:"items" validate:"required,min=1"`
	ApplyDiscounts bool             `json:"apply_discounts"`
	CalculationDate *string         `json:"calculation_date,omitempty"`
}

// SimulationItem represents an item for simulation
type SimulationItem struct {
	ProductID       int64   `json:"product_id" validate:"required"`
	Quantity        float64 `json:"quantity" validate:"required,gt=0"`
	ServiceIDs      []int64 `json:"service_ids,omitempty"`
}

// PriceSimulationResponse represents simulation result
type PriceSimulationResponse struct {
	TotalPrice      float64                    `json:"total_price"`
	ItemsBreakdown  []SimulationItemBreakdown  `json:"items_breakdown"`
	TotalDiscount   float64                    `json:"total_discount"`
	AppliedRules    []AppliedPriceRuleResponse `json:"applied_rules"`
}

// SimulationItemBreakdown represents item breakdown in simulation
type SimulationItemBreakdown struct {
	ProductID      int64   `json:"product_id"`
	ProductName    string  `json:"product_name"`
	Quantity       float64 `json:"quantity"`
	UnitPrice      float64 `json:"unit_price"`
	ServicePrice   float64 `json:"service_price"`
	SubTotal       float64 `json:"sub_total"`
	Discount       float64 `json:"discount"`
	NetAmount      float64 `json:"net_amount"`
}
