package dto

import "time"

// InventoryBalanceResponse represents inventory balance
type InventoryBalanceResponse struct {
	ID                int64     `json:"id"`
	WarehouseID       int64     `json:"warehouse_id"`
	WarehouseName     string    `json:"warehouse_name"`
	ProductID         int64     `json:"product_id"`
	ProductCode       string    `json:"product_code"`
	ProductName       string    `json:"product_name"`
	UnitID            int64     `json:"unit_id"`
	UnitName          string    `json:"unit_name"`
	QuantityOnHand    float64   `json:"quantity_on_hand"`
	QuantityReserved  float64   `json:"quantity_reserved"`
	QuantityAvailable float64   `json:"quantity_available"`
	LastUpdated       time.Time `json:"last_updated"`
}

// GetInventoryBalanceRequest represents get balance request
type GetInventoryBalanceRequest struct {
	WarehouseID int64 `json:"warehouse_id" validate:"required"`
	ProductID   int64 `json:"product_id" validate:"required"`
	UnitID      int64 `json:"unit_id,omitempty"`
}

// ListInventoryBalancesRequest represents list balances request
type ListInventoryBalancesRequest struct {
	WarehouseID int64  `json:"warehouse_id" validate:"required"`
	Search      string `json:"search,omitempty"`
	Page        int    `json:"page" validate:"min=1"`
	PageSize    int    `json:"page_size" validate:"min=1,max=100"`
}

// InventoryTransactionResponse represents inventory transaction
type InventoryTransactionResponse struct {
	ID              int64     `json:"id"`
	TransactionDate time.Time `json:"transaction_date"`
	WarehouseID     int64     `json:"warehouse_id"`
	WarehouseName   string    `json:"warehouse_name"`
	ProductID       int64     `json:"product_id"`
	ProductCode     string    `json:"product_code"`
	ProductName     string    `json:"product_name"`
	UnitID          int64     `json:"unit_id"`
	QuantityChange  float64   `json:"quantity_change"`
	TransactionType string    `json:"transaction_type"`
	ReferenceType   *string   `json:"reference_type,omitempty"`
	ReferenceID     *int64    `json:"reference_id,omitempty"`
	BalanceAfter    *float64  `json:"balance_after,omitempty"`
	Description     *string   `json:"description,omitempty"`
}

// ListInventoryTransactionsRequest represents list transactions request
type ListInventoryTransactionsRequest struct {
	WarehouseID int64      `json:"warehouse_id" validate:"required"`
	ProductID   int64      `json:"product_id,omitempty"`
	FromDate    *time.Time `json:"from_date,omitempty"`
	ToDate      *time.Time `json:"to_date,omitempty"`
	Page        int        `json:"page" validate:"min=1"`
	PageSize    int        `json:"page_size" validate:"min=1,max=100"`
}

// ReserveInventoryRequest represents reserve inventory request
type ReserveInventoryRequest struct {
	WarehouseID int64   `json:"warehouse_id" validate:"required"`
	ProductID   int64   `json:"product_id" validate:"required"`
	Quantity    float64 `json:"quantity" validate:"required,gt=0"`
	ReferenceType string `json:"reference_type" validate:"required"`
	ReferenceID   int64  `json:"reference_id" validate:"required"`
}

// ReleaseInventoryRequest represents release inventory request
type ReleaseInventoryRequest struct {
	WarehouseID int64   `json:"warehouse_id" validate:"required"`
	ProductID   int64   `json:"product_id" validate:"required"`
	Quantity    float64 `json:"quantity" validate:"required,gt=0"`
	ReferenceType string `json:"reference_type" validate:"required"`
	ReferenceID   int64  `json:"reference_id" validate:"required"`
}

// AdjustInventoryRequest represents adjust inventory request
type AdjustInventoryRequest struct {
	WarehouseID     int64   `json:"warehouse_id" validate:"required"`
	ProductID       int64   `json:"product_id" validate:"required"`
	UnitID          int64   `json:"unit_id" validate:"required"`
	QuantityChange  float64 `json:"quantity_change" validate:"required"`
	TransactionType string  `json:"transaction_type" validate:"required"`
	Description     string  `json:"description,omitempty"`
}

// BulkInventoryBalanceRequest represents bulk balance request
type BulkInventoryBalanceRequest struct {
	WarehouseID int64   `json:"warehouse_id" validate:"required"`
	ProductIDs  []int64 `json:"product_ids" validate:"required,min=1,max=100"`
}

// BulkInventoryBalanceResponse represents bulk balance response
type BulkInventoryBalanceResponse struct {
	Balances map[int64]float64 `json:"balances"` // product_id -> available quantity
}

// InventorySummaryResponse represents inventory summary
type InventorySummaryResponse struct {
	WarehouseID       int64   `json:"warehouse_id"`
	WarehouseName     string  `json:"warehouse_name"`
	TotalProducts     int64   `json:"total_products"`
	TotalQuantity     float64 `json:"total_quantity"`
	TotalValue        float64 `json:"total_value,omitempty"`
	LowStockProducts  int64   `json:"low_stock_products,omitempty"`
	OutOfStockProducts int64  `json:"out_of_stock_products"`
}
