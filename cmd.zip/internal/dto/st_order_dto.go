package dto

import "time"

// CreateStOrderRequest represents create ST order request
type CreateStOrderRequest struct {
	CustomerID int64 `json:"customer_id" validate:"required"`
	
	// Pair items (optional)
	PairItems []CreateStPairItemRequest `json:"pair_items,omitempty"`
	
	// Single items (optional)
	SingleItems []CreateStSingleItemRequest `json:"single_items,omitempty"`
	
	// Cutting service (optional)
	UseCuttingService bool    `json:"use_cutting_service"`
	CuttingServiceID  *int64  `json:"cutting_service_id,omitempty"`
	
	Notes        *string `json:"notes,omitempty"`
	ExpectedDate *string `json:"expected_date,omitempty"`
}

// CreateStPairItemRequest represents pair item (for warranty)
type CreateStPairItemRequest struct {
	// Common attributes for both eyes
	LensBrandID   int64 `json:"lens_brand_id" validate:"required"`
	LensIndexID   int64 `json:"lens_index_id" validate:"required"`
	LensMaterialID int64 `json:"lens_material_id" validate:"required"`
	LensColorID   *int64 `json:"lens_color_id,omitempty"`
	LensCoatingID int64 `json:"lens_coating_id" validate:"required"`
	
	// Right eye specifications
	RightSPH float64  `json:"right_sph" validate:"required"`
	RightCYL *float64 `json:"right_cyl,omitempty"`
	
	// Left eye specifications
	LeftSPH  float64  `json:"left_sph" validate:"required"`
	LeftCYL  *float64 `json:"left_cyl,omitempty"`
	
	// Warranty card info
	PatientName     string  `json:"patient_name" validate:"required"`
	PatientMobile   string  `json:"patient_mobile" validate:"required"`
	ReceiptNumber   *string `json:"receipt_number,omitempty"`
}

// CreateStSingleItemRequest represents single item (bulk)
type CreateStSingleItemRequest struct {
	ProductID int64   `json:"product_id" validate:"required"`
	Quantity  float64 `json:"quantity" validate:"required,gt=0"`
}

// UpdateStOrderRequest represents update ST order request
type UpdateStOrderRequest struct {
	UseCuttingService *bool   `json:"use_cutting_service,omitempty"`
	CuttingServiceID  *int64  `json:"cutting_service_id,omitempty"`
	Notes             *string `json:"notes,omitempty"`
}

// StOrderResponse represents ST order response
type StOrderResponse struct {
	ID          int64            `json:"id"`
	OrderNumber string           `json:"order_number"`
	Customer    *EntityResponse  `json:"customer,omitempty"`
	
	// Items
	PairItems   []StPairItemResponse   `json:"pair_items,omitempty"`
	SingleItems []StSingleItemResponse `json:"single_items,omitempty"`
	
	// Cutting service
	UseCuttingService bool             `json:"use_cutting_service"`
	CuttingService    *ProductResponse `json:"cutting_service,omitempty"`
	
	// Pricing
	ItemsPrice    float64 `json:"items_price"`
	ServicePrice  float64 `json:"service_price"`
	TotalPrice    float64 `json:"total_price"`
	
	// Status
	CurrentState *StateResponse               `json:"current_state,omitempty"`
	StateHistory []StOrderStateHistoryResponse `json:"state_history,omitempty"`
	
	Notes        *string    `json:"notes,omitempty"`
	ExpectedDate *time.Time `json:"expected_date,omitempty"`
	CreatedBy    *int64     `json:"created_by,omitempty"`
	CreatedAt    time.Time  `json:"created_at"`
	UpdatedAt    time.Time  `json:"updated_at"`
}

// StPairItemResponse represents pair item response
type StPairItemResponse struct {
	ID int64 `json:"id"`
	
	// Common products
	RightProduct *ProductResponse `json:"right_product,omitempty"`
	LeftProduct  *ProductResponse `json:"left_product,omitempty"`
	
	// Lens attributes
	LensBrand    *LookupResponse `json:"lens_brand,omitempty"`
	LensIndex    *LookupResponse `json:"lens_index,omitempty"`
	LensMaterial *LookupResponse `json:"lens_material,omitempty"`
	LensColor    *LookupResponse `json:"lens_color,omitempty"`
	LensCoating  *LookupResponse `json:"lens_coating,omitempty"`
	
	// Right eye
	RightSPH float64  `json:"right_sph"`
	RightCYL *float64 `json:"right_cyl,omitempty"`
	
	// Left eye
	LeftSPH  float64  `json:"left_sph"`
	LeftCYL  *float64 `json:"left_cyl,omitempty"`
	
	// Warranty
	WarrantyCard *WarrantyCardResponse `json:"warranty_card,omitempty"`
	
	// Pricing
	UnitPrice  float64 `json:"unit_price"`
	TotalPrice float64 `json:"total_price"`
}

// StSingleItemResponse represents single item response
type StSingleItemResponse struct {
	ID         int64            `json:"id"`
	Product    *ProductResponse `json:"product,omitempty"`
	Quantity   float64          `json:"quantity"`
	UnitPrice  float64          `json:"unit_price"`
	TotalPrice float64          `json:"total_price"`
}

// WarrantyCardResponse represents warranty card
type WarrantyCardResponse struct {
	ID              int64     `json:"id"`
	CardNumber      string    `json:"card_number"`
	PatientName     string    `json:"patient_name"`
	PatientMobile   string    `json:"patient_mobile"`
	ReceiptNumber   *string   `json:"receipt_number,omitempty"`
	IssueDate       time.Time `json:"issue_date"`
	ExpiryDate      time.Time `json:"expiry_date"`
	IsActive        bool      `json:"is_active"`
}

// StOrderStateHistoryResponse represents state history
type StOrderStateHistoryResponse struct {
	ID            int64          `json:"id"`
	FromState     *StateResponse `json:"from_state,omitempty"`
	ToState       *StateResponse `json:"to_state,omitempty"`
	ChangedBy     *int64         `json:"changed_by,omitempty"`
	ChangedByName *string        `json:"changed_by_name,omitempty"`
	ChangeDate    time.Time      `json:"change_date"`
	Notes         *string        `json:"notes,omitempty"`
}

// ChangeStOrderStateRequest represents change state request
type ChangeStOrderStateRequest struct {
	OrderID     int64   `json:"order_id" validate:"required"`
	ToStateCode string  `json:"to_state_code" validate:"required"`
	Notes       *string `json:"notes,omitempty"`
}

// ListStOrdersRequest represents list ST orders request
type ListStOrdersRequest struct {
	Search     string  `json:"search,omitempty"`
	CustomerID *int64  `json:"customer_id,omitempty"`
	StateCode  *string `json:"state_code,omitempty"`
	FromDate   *string `json:"from_date,omitempty"`
	ToDate     *string `json:"to_date,omitempty"`
	Page       int     `json:"page" validate:"min=1"`
	PageSize   int     `json:"page_size" validate:"min=1,max=100"`
}

// StOrderSummaryResponse represents order summary
type StOrderSummaryResponse struct {
	TotalOrders       int64   `json:"total_orders"`
	DraftOrders       int64   `json:"draft_orders"`
	PendingSupplyOrders int64 `json:"pending_supply_orders"`
	ReadyToShipOrders int64   `json:"ready_to_ship_orders"`
	TotalValue        float64 `json:"total_value"`
	TotalQuantity     float64 `json:"total_quantity"`
}

// CheckInventoryRequest represents check inventory request
type CheckInventoryRequest struct {
	WarehouseID int64   `json:"warehouse_id" validate:"required"`
	ProductIDs  []int64 `json:"product_ids" validate:"required,min=1"`
}

// CheckInventoryResponse represents inventory check response
type CheckInventoryResponse struct {
	AllAvailable bool              `json:"all_available"`
	Availability map[int64]bool    `json:"availability"` // product_id -> available
	Quantities   map[int64]float64 `json:"quantities"`   // product_id -> available quantity
}

// CreateWarrantyClaimRequest represents warranty claim request
type CreateWarrantyClaimRequest struct {
	WarrantyCardID int64   `json:"warranty_card_id" validate:"required"`
	ClaimType      string  `json:"claim_type" validate:"required,oneof=replacement repair refund"`
	Description    string  `json:"description" validate:"required"`
	ClaimDate      string  `json:"claim_date" validate:"required"`
}

// WarrantyClaimResponse represents warranty claim response
type WarrantyClaimResponse struct {
	ID             int64                 `json:"id"`
	WarrantyCard   *WarrantyCardResponse `json:"warranty_card,omitempty"`
	ClaimType      string                `json:"claim_type"`
	Description    string                `json:"description"`
	ClaimDate      time.Time             `json:"claim_date"`
	Status         string                `json:"status"`
	Resolution     *string               `json:"resolution,omitempty"`
	ResolvedAt     *time.Time            `json:"resolved_at,omitempty"`
	ResolvedBy     *int64                `json:"resolved_by,omitempty"`
	CreatedBy      *int64                `json:"created_by,omitempty"`
	CreatedAt      time.Time             `json:"created_at"`
}
