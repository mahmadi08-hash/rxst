package dto

import "time"

// WarehouseResponse represents warehouse
type WarehouseResponse struct {
	ID                  int64     `json:"id"`
	Code                string    `json:"code"`
	Name                string    `json:"name"`
	FinancialSystemCode *string   `json:"financial_system_code,omitempty"`
	Address             *string   `json:"address,omitempty"`
	IsActive            bool      `json:"is_active"`
	CreatedBy           *int64    `json:"created_by,omitempty"`
	CreatedAt           time.Time `json:"created_at"`
	UpdatedBy           *int64    `json:"updated_by,omitempty"`
	UpdatedAt           time.Time `json:"updated_at"`
}

// CreateWarehouseRequest represents create warehouse request
type CreateWarehouseRequest struct {
	Code                string  `json:"code" validate:"required,max=50"`
	Name                string  `json:"name" validate:"required,max=200"`
	FinancialSystemCode *string `json:"financial_system_code,omitempty"`
	Address             *string `json:"address,omitempty"`
	IsActive            bool    `json:"is_active"`
}

// UpdateWarehouseRequest represents update warehouse request
type UpdateWarehouseRequest struct {
	Name                *string `json:"name,omitempty"`
	FinancialSystemCode *string `json:"financial_system_code,omitempty"`
	Address             *string `json:"address,omitempty"`
	IsActive            *bool   `json:"is_active,omitempty"`
}

// WarehouseDocumentTemplateResponse represents document template
type WarehouseDocumentTemplateResponse struct {
	ID               int64     `json:"id"`
	Code             string    `json:"code"`
	Name             string    `json:"name"`
	Direction        string    `json:"direction"` // in, out
	DocumentType     string    `json:"document_type"` // opening, purchase, consumption, return, adjustment, transfer, other
	AffectsInventory bool      `json:"affects_inventory"`
	RequiresApproval bool      `json:"requires_approval"`
	IsActive         bool      `json:"is_active"`
	CreatedAt        time.Time `json:"created_at"`
}

// CreateWarehouseDocumentTemplateRequest represents create template request
type CreateWarehouseDocumentTemplateRequest struct {
	Code             string `json:"code" validate:"required,max=50"`
	Name             string `json:"name" validate:"required,max=200"`
	Direction        string `json:"direction" validate:"required,oneof=in out"`
	DocumentType     string `json:"document_type" validate:"required,oneof=opening purchase consumption return adjustment transfer other"`
	AffectsInventory bool   `json:"affects_inventory"`
	RequiresApproval bool   `json:"requires_approval"`
	IsActive         bool   `json:"is_active"`
}

// WarehouseDocumentResponse represents warehouse document
type WarehouseDocumentResponse struct {
	ID              int64                           `json:"id"`
	DocumentNumber  string                          `json:"document_number"`
	FiscalYearID    int64                           `json:"fiscal_year_id"`
	Template        *WarehouseDocumentTemplateResponse `json:"template"`
	Warehouse       *WarehouseResponse              `json:"warehouse"`
	DocumentDate    time.Time                       `json:"document_date"`
	DocumentTime    time.Time                       `json:"document_time"`
	SupplierID      *int64                          `json:"supplier_id,omitempty"`
	SupplierName    *string                         `json:"supplier_name,omitempty"`
	CustomerID      *int64                          `json:"customer_id,omitempty"`
	CustomerName    *string                         `json:"customer_name,omitempty"`
	ReferenceNumber *string                         `json:"reference_number,omitempty"`
	Description     *string                         `json:"description,omitempty"`
	Status          string                          `json:"status"` // draft, approved, posted, cancelled
	PostedAt        *time.Time                      `json:"posted_at,omitempty"`
	TotalAmount     float64                         `json:"total_amount"`
	Items           []WarehouseDocumentItemResponse `json:"items,omitempty"`
	CreatedAt       time.Time                       `json:"created_at"`
	UpdatedAt       time.Time                       `json:"updated_at"`
}

// WarehouseDocumentItemResponse represents document item
type WarehouseDocumentItemResponse struct {
	ID             int64   `json:"id"`
	LineNumber     int     `json:"line_number"`
	ProductID      int64   `json:"product_id"`
	ProductCode    string  `json:"product_code"`
	ProductName    string  `json:"product_name"`
	UnitID         int64   `json:"unit_id"`
	UnitName       string  `json:"unit_name"`
	Quantity       float64 `json:"quantity"`
	UnitPrice      float64 `json:"unit_price"`
	TotalPrice     float64 `json:"total_price"`
	DiscountPercent float64 `json:"discount_percent"`
	DiscountAmount float64 `json:"discount_amount"`
	NetAmount      float64 `json:"net_amount"`
	Description    *string `json:"description,omitempty"`
}

// CreateWarehouseDocumentRequest represents create document request
type CreateWarehouseDocumentRequest struct {
	TemplateID      int64                            `json:"template_id" validate:"required"`
	WarehouseID     int64                            `json:"warehouse_id" validate:"required"`
	FiscalYearID    int64                            `json:"fiscal_year_id" validate:"required"`
	DocumentDate    time.Time                        `json:"document_date" validate:"required"`
	SupplierID      *int64                           `json:"supplier_id,omitempty"`
	CustomerID      *int64                           `json:"customer_id,omitempty"`
	ReferenceNumber *string                          `json:"reference_number,omitempty"`
	Description     *string                          `json:"description,omitempty"`
	Items           []CreateWarehouseDocumentItemRequest `json:"items" validate:"required,min=1"`
}

// CreateWarehouseDocumentItemRequest represents create item request
type CreateWarehouseDocumentItemRequest struct {
	ProductID       int64   `json:"product_id" validate:"required"`
	UnitID          int64   `json:"unit_id" validate:"required"`
	Quantity        float64 `json:"quantity" validate:"required,gt=0"`
	UnitPrice       float64 `json:"unit_price" validate:"gte=0"`
	DiscountPercent float64 `json:"discount_percent" validate:"gte=0,lte=100"`
	DiscountAmount  float64 `json:"discount_amount" validate:"gte=0"`
	Description     *string `json:"description,omitempty"`
}

// UpdateWarehouseDocumentRequest represents update document request
type UpdateWarehouseDocumentRequest struct {
	DocumentDate    *time.Time                       `json:"document_date,omitempty"`
	SupplierID      *int64                           `json:"supplier_id,omitempty"`
	CustomerID      *int64                           `json:"customer_id,omitempty"`
	ReferenceNumber *string                          `json:"reference_number,omitempty"`
	Description     *string                          `json:"description,omitempty"`
	Items           []CreateWarehouseDocumentItemRequest `json:"items,omitempty"`
}

// ListWarehouseDocumentsRequest represents list documents request
type ListWarehouseDocumentsRequest struct {
	WarehouseID int64      `json:"warehouse_id" validate:"required"`
	Status      string     `json:"status,omitempty"`
	FromDate    *time.Time `json:"from_date,omitempty"`
	ToDate      *time.Time `json:"to_date,omitempty"`
	Page        int        `json:"page" validate:"min=1"`
	PageSize    int        `json:"page_size" validate:"min=1,max=100"`
}

// PostWarehouseDocumentRequest represents post document request
type PostWarehouseDocumentRequest struct {
	DocumentID int64 `json:"document_id" validate:"required"`
}

// CancelWarehouseDocumentRequest represents cancel document request
type CancelWarehouseDocumentRequest struct {
	DocumentID int64  `json:"document_id" validate:"required"`
	Reason     string `json:"reason" validate:"required"`
}

// GetNextDocumentNumberResponse represents next document number response
type GetNextDocumentNumberResponse struct {
	NextNumber string `json:"next_number"`
}
