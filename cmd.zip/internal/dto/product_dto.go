package dto

import "time"

// CreateProductRequest represents create product request
type CreateProductRequest struct {
	Code                string  `json:"code" validate:"required,max=50"`
	SecondaryCode       *string `json:"secondary_code,omitempty"`
	FinancialSystemCode *string `json:"financial_system_code,omitempty"`
	Name                string  `json:"name" validate:"required,max=500"`
	ProductType         string  `json:"product_type" validate:"required,oneof=rx_lens st_lens semi_finished accessory service other"`

	// Lens specific fields
	LensBrandID    *int64   `json:"lens_brand_id,omitempty"`
	LensTypeID     *int64   `json:"lens_type_id,omitempty"`
	LensIndexID    *int64   `json:"lens_index_id,omitempty"`
	LensMaterialID *int64   `json:"lens_material_id,omitempty"`
	LensColorID    *int64   `json:"lens_color_id,omitempty"`
	LensDesignID   *int64   `json:"lens_design_id,omitempty"`
	LensCoatingID  *int64   `json:"lens_coating_id,omitempty"`
	LensSPH        *float64 `json:"lens_sph,omitempty"`
	LensCYL        *float64 `json:"lens_cyl,omitempty"`

	// Semi-finished fields
	LensBase  *float64 `json:"lens_base,omitempty"`
	Direction *string  `json:"direction,omitempty" validate:"omitempty,oneof=left right"`

	// Service specific
	ServiceType *string `json:"service_type,omitempty" validate:"omitempty,oneof=cutting color production extra logistics coating priority other"`

	BaseUnitID *int64 `json:"base_unit_id,omitempty"`
	IsActive   bool   `json:"is_active"`
}

// UpdateProductRequest represents update product request
type UpdateProductRequest struct {
	SecondaryCode       *string `json:"secondary_code,omitempty"`
	FinancialSystemCode *string `json:"financial_system_code,omitempty"`
	Name                *string `json:"name,omitempty"`
	IsActive            *bool   `json:"is_active,omitempty"`
}

// ProductResponse represents product response
type ProductResponse struct {
	ID                  int64   `json:"id"`
	Code                string  `json:"code"`
	SecondaryCode       *string `json:"secondary_code,omitempty"`
	FinancialSystemCode *string `json:"financial_system_code,omitempty"`
	Name                string  `json:"name"`
	ProductType         string  `json:"product_type"`

	// Lens specific fields
	LensBrand    *LookupResponse `json:"lens_brand,omitempty"`
	LensType     *LookupResponse `json:"lens_type,omitempty"`
	LensIndex    *LookupResponse `json:"lens_index,omitempty"`
	LensMaterial *LookupResponse `json:"lens_material,omitempty"`
	LensColor    *LookupResponse `json:"lens_color,omitempty"`
	LensDesign   *LookupResponse `json:"lens_design,omitempty"`
	LensCoating  *LookupResponse `json:"lens_coating,omitempty"`
	LensSPH      *float64        `json:"lens_sph,omitempty"`
	LensCYL      *float64        `json:"lens_cyl,omitempty"`

	// Semi-finished fields
	LensBase  *float64 `json:"lens_base,omitempty"`
	Direction *string  `json:"direction,omitempty"`

	// Service specific
	ServiceType *string `json:"service_type,omitempty"`

	BaseUnit  *LookupResponse `json:"base_unit,omitempty"`
	IsActive  bool            `json:"is_active"`
	CreatedAt time.Time       `json:"created_at"`
	UpdatedAt time.Time       `json:"updated_at"`
}

// LookupResponse represents lookup entity response
type LookupResponse struct {
	ID   int64  `json:"id"`
	Code string `json:"code"`
	Name string `json:"name"`
}

type ListWarrantyClaimsRequest struct {
	WarrantyCardNumber *string `json:"warranty_card_number,omitempty"`
	RxOrderID          *int64  `json:"rx_order_id,omitempty"`
	Status             *string `json:"status,omitempty"`
	Page               int     `json:"page"`
	PageSize           int     `json:"page_size"`
}

// ListProductsRequest represents list products request
type ListProductsRequest struct {
	Search      string `json:"search,omitempty"`
	ProductType string `json:"product_type,omitempty"`
	LensBrandID int64  `json:"lens_brand_id,omitempty"`
	Page        int    `json:"page" validate:"min=1"`
	PageSize    int    `json:"page_size" validate:"min=1,max=100"`
}

// FindRxProductRequest represents find RX product request
type FindRxProductRequest struct {
	LensBrandID    int64  `json:"lens_brand_id" validate:"required"`
	LensTypeID     int64  `json:"lens_type_id" validate:"required"`
	LensIndexID    int64  `json:"lens_index_id" validate:"required"`
	LensMaterialID int64  `json:"lens_material_id" validate:"required"`
	LensColorID    *int64 `json:"lens_color_id,omitempty"`
	LensDesignID   int64  `json:"lens_design_id" validate:"required"`
}

// FindStProductRequest represents find ST product request
type FindStProductRequest struct {
	LensBrandID   int64   `json:"lens_brand_id" validate:"required"`
	LensIndexID   int64   `json:"lens_index_id" validate:"required"`
	LensCoatingID *int64  `json:"lens_coating_id,omitempty"`
	LensSPH       float64 `json:"lens_sph" validate:"required"`
	LensCYL       float64 `json:"lens_cyl" validate:"required"`
}

// FindSemiFinishedProductRequest represents find semi-finished product request
type FindSemiFinishedProductRequest struct {
	LensBrandID    int64   `json:"lens_brand_id" validate:"required"`
	LensIndexID    int64   `json:"lens_index_id" validate:"required"`
	LensMaterialID int64   `json:"lens_material_id" validate:"required"`
	LensColorID    *int64  `json:"lens_color_id,omitempty"`
	LensBase       float64 `json:"lens_base" validate:"required"`
	Direction      string  `json:"direction" validate:"required,oneof=left right"`
}

// CreateLensBrandRequest represents create lens brand request
type CreateLensBrandRequest struct {
	Code        string  `json:"code" validate:"required,max=50"`
	Name        string  `json:"name" validate:"required,max=200"`
	Description *string `json:"description,omitempty"`
	IsActive    bool    `json:"is_active"`
}

// LensBrandResponse represents lens brand response
type LensBrandResponse struct {
	ID          int64     `json:"id"`
	Code        string    `json:"code"`
	Name        string    `json:"name"`
	Description *string   `json:"description,omitempty"`
	IsActive    bool      `json:"is_active"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// Similar DTOs for other lens attributes
type CreateLensTypeRequest struct {
	Code        string  `json:"code" validate:"required,max=50"`
	Name        string  `json:"name" validate:"required,max=200"`
	Description *string `json:"description,omitempty"`
	IsActive    bool    `json:"is_active"`
}

type CreateLensIndexRequest struct {
	Code        string   `json:"code" validate:"required,max=50"`
	Name        string   `json:"name" validate:"required,max=200"`
	IndexValue  *float64 `json:"index_value,omitempty"`
	Description *string  `json:"description,omitempty"`
	IsActive    bool     `json:"is_active"`
}

type CreateLensMaterialRequest struct {
	Code        string  `json:"code" validate:"required,max=50"`
	Name        string  `json:"name" validate:"required,max=200"`
	Description *string `json:"description,omitempty"`
	IsActive    bool    `json:"is_active"`
}

type CreateLensColorRequest struct {
	Code        string  `json:"code" validate:"required,max=50"`
	Name        string  `json:"name" validate:"required,max=200"`
	ColorHex    *string `json:"color_hex,omitempty"`
	Description *string `json:"description,omitempty"`
	IsActive    bool    `json:"is_active"`
}

type CreateLensDesignRequest struct {
	Code        string  `json:"code" validate:"required,max=50"`
	Name        string  `json:"name" validate:"required,max=200"`
	Description *string `json:"description,omitempty"`
	IsActive    bool    `json:"is_active"`
}

type CreateLensCoatingRequest struct {
	Code        string  `json:"code" validate:"required,max=50"`
	Name        string  `json:"name" validate:"required,max=200"`
	Description *string `json:"description,omitempty"`
	IsActive    bool    `json:"is_active"`
}

type CreateUnitOfMeasureRequest struct {
	Code                string  `json:"code" validate:"required,max=50"`
	Name                string  `json:"name" validate:"required,max=100"`
	FinancialSystemCode *string `json:"financial_system_code,omitempty"`
	IsActive            bool    `json:"is_active"`
}
