package dto

import "time"

// CreateEntityRequest represents create entity request
type CreateEntityRequest struct {
	EntityType         string  `json:"entity_type" validate:"required,oneof=person company"`
	Code               string  `json:"code" validate:"required,max=50"`
	SecondaryCode      *string `json:"secondary_code,omitempty"`
	FirstName          *string `json:"first_name,omitempty"`
	LastName           *string `json:"last_name,omitempty"`
	CompanyName        *string `json:"company_name,omitempty"`
	NationalID         *string `json:"national_id,omitempty"`
	RegistrationNumber *string `json:"registration_number,omitempty"`
	Email              *string `json:"email,omitempty" validate:"omitempty,email"`
	IsActive           bool    `json:"is_active"`
	Roles              []int64 `json:"roles,omitempty"`
	Phones             []CreateEntityPhoneRequest   `json:"phones,omitempty"`
	Addresses          []CreateEntityAddressRequest `json:"addresses,omitempty"`
}

// UpdateEntityRequest represents update entity request
type UpdateEntityRequest struct {
	SecondaryCode      *string `json:"secondary_code,omitempty"`
	FirstName          *string `json:"first_name,omitempty"`
	LastName           *string `json:"last_name,omitempty"`
	CompanyName        *string `json:"company_name,omitempty"`
	NationalID         *string `json:"national_id,omitempty"`
	RegistrationNumber *string `json:"registration_number,omitempty"`
	Email              *string `json:"email,omitempty" validate:"omitempty,email"`
	IsActive           *bool   `json:"is_active,omitempty"`
}

// EntityResponse represents entity response
type EntityResponse struct {
	ID                 int64                  `json:"id"`
	EntityType         string                 `json:"entity_type"`
	Code               string                 `json:"code"`
	SecondaryCode      *string                `json:"secondary_code,omitempty"`
	FirstName          *string                `json:"first_name,omitempty"`
	LastName           *string                `json:"last_name,omitempty"`
	CompanyName        *string                `json:"company_name,omitempty"`
	NationalID         *string                `json:"national_id,omitempty"`
	RegistrationNumber *string                `json:"registration_number,omitempty"`
	Email              *string                `json:"email,omitempty"`
	IsActive           bool                   `json:"is_active"`
	Roles              []EntityRoleResponse   `json:"roles,omitempty"`
	Phones             []EntityPhoneResponse  `json:"phones,omitempty"`
	Addresses          []EntityAddressResponse `json:"addresses,omitempty"`
	CreatedAt          time.Time              `json:"created_at"`
	UpdatedAt          time.Time              `json:"updated_at"`
}

// EntityRoleResponse represents entity role
type EntityRoleResponse struct {
	ID          int64   `json:"id"`
	RoleName    string  `json:"role_name"`
	RoleCode    string  `json:"role_code"`
	Description *string `json:"description,omitempty"`
}

// CreateEntityPhoneRequest represents phone creation
type CreateEntityPhoneRequest struct {
	PhoneNumber string  `json:"phone_number" validate:"required"`
	PhoneType   *string `json:"phone_type,omitempty" validate:"omitempty,oneof=mobile landline fax other"`
	IsPrimary   bool    `json:"is_primary"`
}

// EntityPhoneResponse represents phone response
type EntityPhoneResponse struct {
	ID          int64     `json:"id"`
	PhoneNumber string    `json:"phone_number"`
	PhoneType   *string   `json:"phone_type,omitempty"`
	IsPrimary   bool      `json:"is_primary"`
	CreatedAt   time.Time `json:"created_at"`
}

// CreateEntityAddressRequest represents address creation
type CreateEntityAddressRequest struct {
	AddressType *string `json:"address_type,omitempty" validate:"omitempty,oneof=home work billing shipping other"`
	Country     *string `json:"country,omitempty"`
	Province    *string `json:"province,omitempty"`
	City        *string `json:"city,omitempty"`
	PostalCode  *string `json:"postal_code,omitempty"`
	AddressLine string  `json:"address_line" validate:"required"`
	IsPrimary   bool    `json:"is_primary"`
}

// EntityAddressResponse represents address response
type EntityAddressResponse struct {
	ID          int64     `json:"id"`
	AddressType *string   `json:"address_type,omitempty"`
	Country     *string   `json:"country,omitempty"`
	Province    *string   `json:"province,omitempty"`
	City        *string   `json:"city,omitempty"`
	PostalCode  *string   `json:"postal_code,omitempty"`
	AddressLine string    `json:"address_line"`
	IsPrimary   bool      `json:"is_primary"`
	CreatedAt   time.Time `json:"created_at"`
}

// ListEntitiesRequest represents list entities request
type ListEntitiesRequest struct {
	Search     string `json:"search,omitempty"`
	EntityType string `json:"entity_type,omitempty" validate:"omitempty,oneof=person company"`
	IsActive   *bool  `json:"is_active,omitempty"`
	Page       int    `json:"page" validate:"min=1"`
	PageSize   int    `json:"page_size" validate:"min=1,max=100"`
}

// AssignRoleRequest represents role assignment
type AssignRoleRequest struct {
	EntityID int64 `json:"entity_id" validate:"required"`
	RoleID   int64 `json:"role_id" validate:"required"`
}

// GetEntityWithDetailsResponse represents entity with full details
type GetEntityWithDetailsResponse struct {
	Entity    EntityResponse          `json:"entity"`
	Roles     []EntityRoleResponse    `json:"roles"`
	Phones    []EntityPhoneResponse   `json:"phones"`
	Addresses []EntityAddressResponse `json:"addresses"`
}
