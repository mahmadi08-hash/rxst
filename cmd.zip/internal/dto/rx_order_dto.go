package dto

import "time"

// CreateRxOrderRequest represents create RX order request
type CreateRxOrderRequest struct {
	CustomerID int64 `json:"customer_id" validate:"required"`
	
	// Product selection
	LensBrandID    int64  `json:"lens_brand_id" validate:"required"`
	LensTypeID     int64  `json:"lens_type_id" validate:"required"`
	LensIndexID    int64  `json:"lens_index_id" validate:"required"`
	LensMaterialID int64  `json:"lens_material_id" validate:"required"`
	LensColorID    *int64 `json:"lens_color_id,omitempty"`
	LensDesignID   int64  `json:"lens_design_id" validate:"required"`
	
	// Eye specifications - Right
	RightSPH        float64  `json:"right_sph" validate:"required"`
	RightCYL        *float64 `json:"right_cyl,omitempty"`
	RightAxis       *int32   `json:"right_axis,omitempty"`
	RightAddition   *float64 `json:"right_addition,omitempty"`
	RightPD         *float64 `json:"right_pd,omitempty"`
	RightDecentration *float64 `json:"right_decentration,omitempty"`
	RightPrismValue *float64 `json:"right_prism_value,omitempty"`
	RightPrismBase  *string  `json:"right_prism_base,omitempty"`
	
	// Eye specifications - Left
	LeftSPH         float64  `json:"left_sph" validate:"required"`
	LeftCYL         *float64 `json:"left_cyl,omitempty"`
	LeftAxis        *int32   `json:"left_axis,omitempty"`
	LeftAddition    *float64 `json:"left_addition,omitempty"`
	LeftPD          *float64 `json:"left_pd,omitempty"`
	LeftDecentration *float64 `json:"left_decentration,omitempty"`
	LeftPrismValue  *float64 `json:"left_prism_value,omitempty"`
	LeftPrismBase   *string  `json:"left_prism_base,omitempty"`
	
	// Frame dimensions
	FrameType      string   `json:"frame_type" validate:"required,oneof=full_metal rimless nylor full_plastic"`
	HBOX           *float64 `json:"hbox,omitempty"`
	VBOX           *float64 `json:"vbox,omitempty"`
	DBL            *float64 `json:"dbl,omitempty"`
	ED             *float64 `json:"ed,omitempty"`
	Panto          *float64 `json:"panto,omitempty"`
	FFA            *float64 `json:"ffa,omitempty"`
	BVD            *float64 `json:"bvd,omitempty"`
	FrameShapeFile *string  `json:"frame_shape_file,omitempty"`
	
	// Services
	CoatingServiceID int64    `json:"coating_service_id" validate:"required"` // Mandatory
	ColorServiceID   *int64   `json:"color_service_id,omitempty"`
	ColorType        *string  `json:"color_type,omitempty" validate:"omitempty,oneof=full gradual same_as_sample"`
	ColorSample      *string  `json:"color_sample,omitempty"`
	ExtraServiceIDs  []int64  `json:"extra_service_ids,omitempty"`
	IsPriority       bool     `json:"is_priority"`
	
	// Optional info
	Notes           *string `json:"notes,omitempty"`
	ExpectedDate    *string `json:"expected_date,omitempty"`
}

// UpdateRxOrderRequest represents update RX order request
type UpdateRxOrderRequest struct {
	// Eye specifications can be updated in draft state
	RightSPH        *float64 `json:"right_sph,omitempty"`
	RightCYL        *float64 `json:"right_cyl,omitempty"`
	LeftSPH         *float64 `json:"left_sph,omitempty"`
	LeftCYL         *float64 `json:"left_cyl,omitempty"`
	
	// Frame dimensions
	HBOX            *float64 `json:"hbox,omitempty"`
	VBOX            *float64 `json:"vbox,omitempty"`
	
	// Services
	ColorServiceID  *int64   `json:"color_service_id,omitempty"`
	ExtraServiceIDs []int64  `json:"extra_service_ids,omitempty"`
	IsPriority      *bool    `json:"is_priority,omitempty"`
	
	Notes           *string  `json:"notes,omitempty"`
}

// RxOrderResponse represents RX order response
type RxOrderResponse struct {
	ID             int64     `json:"id"`
	OrderNumber    string    `json:"order_number"`
	Customer       *EntityResponse `json:"customer,omitempty"`
	
	// Product info
	FinalProduct     *ProductResponse `json:"final_product,omitempty"`
	SemiFinishedProduct *ProductResponse `json:"semi_finished_product,omitempty"`
	
	// Lens attributes
	LensBrand      *LookupResponse `json:"lens_brand,omitempty"`
	LensType       *LookupResponse `json:"lens_type,omitempty"`
	LensIndex      *LookupResponse `json:"lens_index,omitempty"`
	LensMaterial   *LookupResponse `json:"lens_material,omitempty"`
	LensColor      *LookupResponse `json:"lens_color,omitempty"`
	LensDesign     *LookupResponse `json:"lens_design,omitempty"`
	
	// Eye specifications - Right
	RightSPH          float64  `json:"right_sph"`
	RightCYL          *float64 `json:"right_cyl,omitempty"`
	RightAxis         *int32   `json:"right_axis,omitempty"`
	RightAddition     *float64 `json:"right_addition,omitempty"`
	RightPD           *float64 `json:"right_pd,omitempty"`
	RightDecentration *float64 `json:"right_decentration,omitempty"`
	RightPrismValue   *float64 `json:"right_prism_value,omitempty"`
	RightPrismBase    *string  `json:"right_prism_base,omitempty"`
	
	// Eye specifications - Left
	LeftSPH           float64  `json:"left_sph"`
	LeftCYL           *float64 `json:"left_cyl,omitempty"`
	LeftAxis          *int32   `json:"left_axis,omitempty"`
	LeftAddition      *float64 `json:"left_addition,omitempty"`
	LeftPD            *float64 `json:"left_pd,omitempty"`
	LeftDecentration  *float64 `json:"left_decentration,omitempty"`
	LeftPrismValue    *float64 `json:"left_prism_value,omitempty"`
	LeftPrismBase     *string  `json:"left_prism_base,omitempty"`
	
	// Frame dimensions
	FrameType      string   `json:"frame_type"`
	HBOX           *float64 `json:"hbox,omitempty"`
	VBOX           *float64 `json:"vbox,omitempty"`
	DBL            *float64 `json:"dbl,omitempty"`
	ED             *float64 `json:"ed,omitempty"`
	Panto          *float64 `json:"panto,omitempty"`
	FFA            *float64 `json:"ffa,omitempty"`
	BVD            *float64 `json:"bvd,omitempty"`
	FrameShapeFile *string  `json:"frame_shape_file,omitempty"`
	
	// Services
	CoatingService *ProductResponse   `json:"coating_service,omitempty"`
	ColorService   *ProductResponse   `json:"color_service,omitempty"`
	ColorType      *string            `json:"color_type,omitempty"`
	ColorSample    *string            `json:"color_sample,omitempty"`
	ExtraServices  []ProductResponse  `json:"extra_services,omitempty"`
	IsPriority     bool               `json:"is_priority"`
	
	// Pricing
	BasePrice      float64 `json:"base_price"`
	ServicePrice   float64 `json:"service_price"`
	TotalPrice     float64 `json:"total_price"`
	
	// Status
	CurrentState   *StateResponse `json:"current_state,omitempty"`
	StateHistory   []RxOrderStateHistoryResponse `json:"state_history,omitempty"`
	
	Notes          *string    `json:"notes,omitempty"`
	ExpectedDate   *time.Time `json:"expected_date,omitempty"`
	CreatedBy      *int64     `json:"created_by,omitempty"`
	CreatedAt      time.Time  `json:"created_at"`
	UpdatedAt      time.Time  `json:"updated_at"`
}

// RxOrderStateHistoryResponse represents state change history
type RxOrderStateHistoryResponse struct {
	ID            int64      `json:"id"`
	FromState     *StateResponse `json:"from_state,omitempty"`
	ToState       *StateResponse `json:"to_state,omitempty"`
	ChangedBy     *int64     `json:"changed_by,omitempty"`
	ChangedByName *string    `json:"changed_by_name,omitempty"`
	ChangeDate    time.Time  `json:"change_date"`
	Notes         *string    `json:"notes,omitempty"`
}

// StateResponse represents a state
type StateResponse struct {
	ID          int64   `json:"id"`
	StateCode   string  `json:"state_code"`
	StateName   string  `json:"state_name"`
	Description *string `json:"description,omitempty"`
}

// ChangeRxOrderStateRequest represents change state request
type ChangeRxOrderStateRequest struct {
	OrderID     int64   `json:"order_id" validate:"required"`
	ToStateCode string  `json:"to_state_code" validate:"required"`
	Notes       *string `json:"notes,omitempty"`
}

// ListRxOrdersRequest represents list RX orders request
type ListRxOrdersRequest struct {
	Search       string  `json:"search,omitempty"`
	CustomerID   *int64  `json:"customer_id,omitempty"`
	StateCode    *string `json:"state_code,omitempty"`
	FromDate     *string `json:"from_date,omitempty"`
	ToDate       *string `json:"to_date,omitempty"`
	IsPriority   *bool   `json:"is_priority,omitempty"`
	Page         int     `json:"page" validate:"min=1"`
	PageSize     int     `json:"page_size" validate:"min=1,max=100"`
}

// RxOrderSummaryResponse represents order summary
type RxOrderSummaryResponse struct {
	TotalOrders      int64   `json:"total_orders"`
	DraftOrders      int64   `json:"draft_orders"`
	InProductionOrders int64 `json:"in_production_orders"`
	CompletedOrders  int64   `json:"completed_orders"`
	PriorityOrders   int64   `json:"priority_orders"`
	TotalValue       float64 `json:"total_value"`
}
