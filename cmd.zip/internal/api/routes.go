package api

import (
	"rx-st-system/internal/cache"
	"rx-st-system/internal/config"
	"rx-st-system/internal/dto"
	"rx-st-system/internal/handler"
	"rx-st-system/internal/middleware"
	"rx-st-system/internal/repository"
	"rx-st-system/internal/service"
	"rx-st-system/pkg/errors"
	"rx-st-system/pkg/logger"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"
)

// SetupRoutes sets up all API routes
func SetupRoutes(app *fiber.App, db *pgxpool.Pool, redisClient *redis.Client, cfg *config.Config) {
	// Create repository
	repo := repository.New(db)

	// Create services
	authService := service.NewAuthService(
		repo,
		cfg.JWT.Secret,
		cfg.JWT.AccessTokenExpiry,
		cfg.JWT.RefreshTokenExpiry,
	)
	entityService := service.NewEntityService(repo, db)
	productService := service.NewProductService(repo, db)

	// Create inventory cache
	inventoryCache := cache.NewInventoryCache(redisClient, cfg.Cache.LocalCacheTTL, cfg.Cache.InventoryTTL)

	// Create warehouse and inventory services
	warehouseService := service.NewWarehouseService(repo, db, inventoryCache)
	inventoryService := service.NewInventoryService(repo, db, inventoryCache)
	warehouseService.SetInventoryService(inventoryService)

	// Create RX and ST order services
	rxOrderService := service.NewRxOrderService(repo, db, productService, inventoryService)
	stOrderService := service.NewStOrderService(repo, db, productService, inventoryService)

	// Create handlers
	authHandler := handler.NewAuthHandler(authService)
	entityHandler := handler.NewEntityHandler(entityService)
	productHandler := handler.NewProductHandler(productService)
	warehouseHandler := handler.NewWarehouseHandler(warehouseService)
	inventoryHandler := handler.NewInventoryHandler(inventoryService)
	rxOrderHandler := handler.NewRxOrderHandler(rxOrderService, inventoryService)
	stOrderHandler := handler.NewStOrderHandler(stOrderService, inventoryService)

	// API v1 group
	api := app.Group("/api/v1")

	// Health check
	api.Get("/health", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{
			"status":  "healthy",
			"service": cfg.App.Name,
			"version": cfg.App.Version,
		})
	})

	// Public routes
	setupPublicRoutes(api, authHandler)

	// Protected routes
	setupProtectedRoutes(api, authHandler, entityHandler, productHandler, warehouseHandler, inventoryHandler, rxOrderHandler, stOrderHandler, cfg.JWT.Secret)
}

// setupPublicRoutes sets up public routes (no authentication required)
func setupPublicRoutes(api fiber.Router, authHandler *handler.AuthHandler) {
	auth := api.Group("/auth")
	{
		auth.Post("/login", authHandler.Login)
		auth.Post("/register", authHandler.Register)
		auth.Post("/refresh", authHandler.RefreshToken)
	}
}

// setupProtectedRoutes sets up protected routes (authentication required)
func setupProtectedRoutes(
	api fiber.Router,
	authHandler *handler.AuthHandler,
	entityHandler *handler.EntityHandler,
	productHandler *handler.ProductHandler,
	warehouseHandler *handler.WarehouseHandler,
	inventoryHandler *handler.InventoryHandler,
	rxOrderHandler *handler.RxOrderHandler,
	stOrderHandler *handler.StOrderHandler,
	jwtSecret string,
) {
	// Apply authentication middleware
	protected := api.Group("", middleware.AuthMiddleware(jwtSecret))

	// Auth routes
	auth := protected.Group("/auth")
	{
		auth.Get("/profile", authHandler.GetProfile)
		auth.Post("/logout", authHandler.Logout)
		auth.Post("/change-password", authHandler.ChangePassword)
	}

	// Admin routes
	admin := protected.Group("/admin", middleware.AdminMiddleware())
	{
		admin.Post("/approve-user", authHandler.ApproveUser)
	}

	// Entity routes
	entities := protected.Group("/entities")
	{
		entities.Post("/list", entityHandler.List)
		entities.Get("/:id", entityHandler.Get)
		entities.Post("/", entityHandler.Create)
		entities.Put("/:id", entityHandler.Update)
		entities.Delete("/:id", entityHandler.Delete)
		entities.Post("/assign-role", entityHandler.AssignRole)
		entities.Post("/remove-role", entityHandler.RemoveRole)
		entities.Post("/:id/phones", entityHandler.AddPhone)
		entities.Delete("/:id/phones/:phoneId", entityHandler.DeletePhone)
		entities.Post("/:id/addresses", entityHandler.AddAddress)
		entities.Delete("/:id/addresses/:addressId", entityHandler.DeleteAddress)
		entities.Get("/by-role", entityHandler.GetByRole)
	}

	// Product routes
	products := protected.Group("/products")
	{
		products.Post("/list", productHandler.List)
		products.Get("/:id", productHandler.Get)
		products.Post("/", productHandler.Create)
		products.Put("/:id", productHandler.Update)
		products.Delete("/:id", productHandler.Delete)
		products.Post("/find-rx", productHandler.FindRxProduct)
		products.Post("/find-st", productHandler.FindStProduct)
		products.Post("/find-semi-finished", productHandler.FindSemiFinishedProduct)
	}

	// Warehouse routes
	warehouses := protected.Group("/warehouses")
	{
		warehouses.Post("/", warehouseHandler.CreateWarehouse)
		warehouses.Get("/:id", warehouseHandler.GetWarehouse)
		warehouses.Get("/", warehouseHandler.ListWarehouses)
		warehouses.Put("/:id", warehouseHandler.UpdateWarehouse)

		// Document templates
		warehouses.Post("/templates", warehouseHandler.CreateDocumentTemplate)
		warehouses.Get("/templates", warehouseHandler.ListDocumentTemplates)

		// Documents
		warehouses.Post("/documents", warehouseHandler.CreateDocument)
		warehouses.Get("/documents/:id", warehouseHandler.GetDocument)
		warehouses.Post("/documents/list", warehouseHandler.ListDocuments)
		warehouses.Post("/documents/post", warehouseHandler.PostDocument)
		warehouses.Get("/documents/next-number", warehouseHandler.GetNextDocumentNumber)
	}

	// Inventory routes
	inventory := protected.Group("/inventory")
	{
		inventory.Get("/balance", inventoryHandler.GetBalance)
		inventory.Post("/balances", inventoryHandler.ListBalances)
		inventory.Post("/bulk-balances", inventoryHandler.GetBulkBalances)
		inventory.Post("/reserve", inventoryHandler.ReserveInventory)
		inventory.Post("/release", inventoryHandler.ReleaseInventory)
		inventory.Post("/adjust", inventoryHandler.AdjustInventory)
		inventory.Post("/transactions", inventoryHandler.ListTransactions)
		inventory.Get("/summary/:warehouseId", inventoryHandler.GetSummary)
		inventory.Delete("/cache", inventoryHandler.InvalidateCache)
	}

	// RX Order routes (Prescription Lens Orders)
	rxOrders := protected.Group("/rx-orders")
	{
		// CRUD operations
		rxOrders.Post("/", rxOrderHandler.Create)
		rxOrders.Get("/:id", rxOrderHandler.Get)
		rxOrders.Put("/:id", rxOrderHandler.Update)
		rxOrders.Delete("/:id", rxOrderHandler.Delete)
		rxOrders.Post("/list", rxOrderHandler.List)

		// State management
		rxOrders.Post("/change-state", rxOrderHandler.ChangeState)
		rxOrders.Get("/:id/history", rxOrderHandler.GetStateHistory)
		rxOrders.Get("/:id/available-transitions", rxOrderHandler.GetAvailableTransitions)

		// Summary & statistics
		rxOrders.Get("/summary", rxOrderHandler.GetSummary)
	}

	// ST Order routes (Stock Lens Orders)
	stOrders := protected.Group("/st-orders")
	{
		// CRUD operations
		stOrders.Post("/", stOrderHandler.Create)
		stOrders.Get("/:id", stOrderHandler.Get)
		stOrders.Put("/:id", stOrderHandler.Update)
		stOrders.Delete("/:id", stOrderHandler.Delete)
		stOrders.Post("/list", stOrderHandler.List)

		// State management
		stOrders.Post("/change-state", stOrderHandler.ChangeState)

		// Inventory check
		stOrders.Post("/check-inventory", stOrderHandler.CheckInventory)

		// Warranty management
		stOrders.Post("/warranty-claim", stOrderHandler.CreateWarrantyClaim)
		stOrders.Get("/warranty-card/:cardNumber", stOrderHandler.GetWarrantyCard)
		stOrders.Get("/warranty-claims", stOrderHandler.ListWarrantyClaims)

		// Summary & statistics
		stOrders.Get("/summary", stOrderHandler.GetSummary)
	}
}

// ErrorHandler handles all errors
func ErrorHandler(c *fiber.Ctx, err error) error {
	traceID := c.Locals("requestid")

	// Log error
	logger.Error("Request error",
		zap.Error(err),
		zap.String("path", c.Path()),
		zap.String("method", c.Method()),
		zap.Any("trace_id", traceID),
	)

	// Handle AppError
	if appErr, ok := err.(*errors.AppError); ok {
		status := fiber.StatusInternalServerError
		switch appErr.Code {
		case errors.ErrCodeValidation, errors.ErrCodeBadRequest:
			status = fiber.StatusBadRequest
		case errors.ErrCodeUnauthorized, errors.ErrCodeInvalidCredentials:
			status = fiber.StatusUnauthorized
		case errors.ErrCodeForbidden:
			status = fiber.StatusForbidden
		case errors.ErrCodeNotFound:
			status = fiber.StatusNotFound
		case errors.ErrCodeConflict:
			status = fiber.StatusConflict
		}

		return c.Status(status).JSON(dto.ErrorResponse{
			Success:   false,
			Error:     appErr.Message,
			Code:      appErr.Code,
			Details:   appErr.Details,
			TraceID:   appErr.TraceID,
			Timestamp: appErr.Timestamp.Format("2006-01-02T15:04:05Z07:00"),
		})
	}

	// Handle Fiber errors
	if fiberErr, ok := err.(*fiber.Error); ok {
		return c.Status(fiberErr.Code).JSON(dto.ErrorResponse{
			Success:   false,
			Error:     fiberErr.Message,
			Code:      errors.ErrCodeInternal,
			TraceID:   traceID.(string),
			Timestamp: "now",
		})
	}

	// Default error
	return c.Status(fiber.StatusInternalServerError).JSON(dto.ErrorResponse{
		Success:   false,
		Error:     "Internal server error",
		Code:      errors.ErrCodeInternal,
		TraceID:   traceID.(string),
		Timestamp: "now",
	})
}
