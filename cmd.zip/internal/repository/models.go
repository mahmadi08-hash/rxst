package repository

import (
	"database/sql"
	"time"
)

// ============================================================================
// USER MODELS
// ============================================================================

type User struct {
	ID                  int64
	Username            string
	Email               sql.NullString
	PasswordHash        string
	EntityID            sql.NullInt64
	FirstName           sql.NullString
	LastName            sql.NullString
	MobileNumber        sql.NullString
	IsActive            bool
	IsApproved          bool
	IsAdmin             bool
	IsSystemAdmin       bool
	FailedLoginAttempts int32
	LockedUntil         sql.NullTime
	LastLogin           sql.NullTime
	CreatedAt           time.Time
	UpdatedAt           time.Time
}

type UserSession struct {
	ID           int64
	UserID       int64
	SessionToken string
	IpAddress    sql.NullString
	UserAgent    sql.NullString
	ExpiresAt    time.Time
	LastActivity sql.NullTime
	CreatedAt    time.Time
}

// ============================================================================
// ENTITY MODELS
// ============================================================================

type Entity struct {
	ID                 int64
	Code               string
	SecondaryCode      sql.NullString
	EntityType         string
	CompanyName        sql.NullString
	LegalName          sql.NullString
	FirstName          sql.NullString
	LastName           sql.NullString
	NationalID         sql.NullString
	RegistrationNumber sql.NullString
	Email              sql.NullString
	IsActive           bool
	CreatedBy          sql.NullInt64
	CreatedAt          time.Time
	UpdatedBy          sql.NullInt64
	UpdatedAt          time.Time
}

type EntityRole struct {
	ID          int64
	EntityID    int64
	RoleType    string
	RoleName    sql.NullString
	RoleCode    sql.NullString
	Description sql.NullString
	CreatedAt   time.Time
}

type EntityPhone struct {
	ID          int64
	EntityID    int64
	PhoneNumber string
	PhoneType   string
	IsPrimary   bool
	CreatedAt   time.Time
}

type EntityAddress struct {
	ID          int64
	EntityID    int64
	AddressType sql.NullString
	Address     string
	AddressLine sql.NullString
	City        sql.NullString
	Province    sql.NullString
	Country     sql.NullString
	PostalCode  sql.NullString
	IsPrimary   bool
	CreatedAt   time.Time
}

// ============================================================================
// PRODUCT MODELS
// ============================================================================

type Product struct {
	ID                  int64
	Code                string
	SecondaryCode       sql.NullString
	FinancialSystemCode sql.NullString
	Name                string
	ProductType         string
	LensBrandID         sql.NullInt64
	LensTypeID          sql.NullInt64
	LensIndexID         sql.NullInt64
	LensMaterialID      sql.NullInt64
	LensColorID         sql.NullInt64
	LensDesignID        sql.NullInt64
	LensCoatingID       sql.NullInt64
	LensSPH             sql.NullFloat64
	LensCYL             sql.NullFloat64
	LensBase            sql.NullFloat64
	Direction           sql.NullString
	ServiceType         sql.NullString
	BaseUnitID          sql.NullInt64
	IsActive            bool
	CreatedBy           sql.NullInt64
	CreatedAt           time.Time
	UpdatedBy           sql.NullInt64
	UpdatedAt           time.Time
}

type LensBrand struct {
	ID        int64
	Code      string
	Name      string
	IsActive  bool
	CreatedAt time.Time
	UpdatedAt time.Time
}

// ============================================================================
// ORDER MODELS
// ============================================================================

type RxOrder struct {
	ID                    int64
	OrderNumber           string
	CustomerID            int64
	FinalProductID        sql.NullInt64
	SemiFinishedProductID sql.NullInt64
	LensBrandID           sql.NullInt64
	LensTypeID            sql.NullInt64
	LensIndexID           sql.NullInt64
	LensMaterialID        sql.NullInt64
	LensColorID           sql.NullInt64
	LensDesignID          sql.NullInt64
	RightSph              sql.NullFloat64
	RightCyl              sql.NullFloat64
	RightAxis             sql.NullInt32
	RightAddition         sql.NullFloat64
	RightPd               sql.NullFloat64
	RightDecentration     sql.NullFloat64
	RightPrismValue       sql.NullFloat64
	RightPrismBase        sql.NullString
	LeftSph               sql.NullFloat64
	LeftCyl               sql.NullFloat64
	LeftAxis              sql.NullInt32
	LeftAddition          sql.NullFloat64
	LeftPd                sql.NullFloat64
	LeftDecentration      sql.NullFloat64
	LeftPrismValue        sql.NullFloat64
	LeftPrismBase         sql.NullString
	FrameType             sql.NullString
	Hbox                  sql.NullFloat64
	Vbox                  sql.NullFloat64
	Dbl                   sql.NullFloat64
	Ed                    sql.NullFloat64
	Panto                 sql.NullFloat64
	Ffa                   sql.NullFloat64
	Bvd                   sql.NullFloat64
	FrameShapeFile        sql.NullString
	CoatingServiceID      sql.NullInt64
	ColorServiceID        sql.NullInt64
	ColorType             sql.NullString
	ColorSample           sql.NullString
	IsPriority            bool
	BasePrice             sql.NullFloat64
	ServicePrice          sql.NullFloat64
	TotalPrice            sql.NullFloat64
	State                 string
	Priority              string
	CurrentStateID        sql.NullInt64
	Notes                 sql.NullString
	ExpectedDate          sql.NullTime
	CreatedBy             sql.NullInt64
	CreatedAt             time.Time
	UpdatedAt             time.Time
}

type StOrder struct {
	ID                int64
	OrderNumber       string
	CustomerID        int64
	State             string
	UseCuttingService bool
	CuttingServiceID  sql.NullInt64
	ItemsPrice        sql.NullFloat64
	ServicePrice      sql.NullFloat64
	TotalPrice        sql.NullFloat64
	CurrentStateID    sql.NullInt64
	Notes             sql.NullString
	ExpectedDate      sql.NullTime
	CreatedBy         sql.NullInt64
	CreatedAt         time.Time
	UpdatedAt         time.Time
}

// ============================================================================
// WAREHOUSE MODELS
// ============================================================================

type Warehouse struct {
	ID                  int64
	Code                string
	Name                string
	FinancialSystemCode sql.NullString
	Address             sql.NullString
	IsActive            bool
	CreatedBy           sql.NullInt64
	CreatedAt           time.Time
	UpdatedBy           sql.NullInt64
	UpdatedAt           time.Time
}

type WarehouseDocument struct {
	ID              int64
	WarehouseID     int64
	TemplateID      int64
	DocumentNumber  string
	DocumentDate    time.Time
	DocumentTime    sql.NullTime
	FiscalYearID    int64
	ReferenceNumber sql.NullString
	Description     sql.NullString
	TotalAmount     sql.NullFloat64
	Status          string
	CreatedBy       sql.NullInt64
	CreatedAt       time.Time
	PostedAt        sql.NullTime
}

type WarehouseDocumentTemplate struct {
	ID               int64
	Code             string
	Name             string
	Direction        string
	DocumentType     string
	AffectsInventory bool
	RequiresApproval bool
	IsActive         bool
	CreatedAt        time.Time
}

type WarehouseDocumentItem struct {
	ID              int64
	DocumentID      int64
	LineNumber      int32
	ProductID       int64
	UnitID          int64
	Quantity        float64
	UnitPrice       sql.NullFloat64
	TotalPrice      sql.NullFloat64
	DiscountPercent sql.NullFloat64
	DiscountAmount  sql.NullFloat64
	NetAmount       sql.NullFloat64
	Description     sql.NullString
}

// ============================================================================
// INVENTORY MODELS
// ============================================================================

type InventoryBalance struct {
	ID                int64
	ProductID         int64
	WarehouseID       int64
	UnitID            int64
	QuantityOnHand    float64
	QuantityReserved  float64
	QuantityAvailable float64
	LastUpdated       time.Time
}

type InventoryTransaction struct {
	ID              int64
	WarehouseID     int64
	ProductID       int64
	UnitID          int64
	Quantity        float64
	QuantityChange  float64
	BalanceAfter    float64
	TransactionType string
	TransactionDate time.Time
	ReferenceType   sql.NullString
	ReferenceID     sql.NullInt64
	Notes           sql.NullString
	Description     sql.NullString
	ProductCode     sql.NullString
	ProductName     sql.NullString
	CreatedAt       time.Time
	CreatedBy       int64
}

// ============================================================================
// STATE MODELS
// ============================================================================

type State struct {
	ID           int64
	StateCode    string
	StateName    string
	StateType    string
	Description  sql.NullString
	Color        sql.NullString
	Icon         sql.NullString
	DisplayOrder int32
	IsActive     bool
	OrderType    string
	CreatedAt    time.Time
}

type StateTransition struct {
	ID                  int64
	FromStateID         int64
	ToStateID           int64
	FromState           string
	ToState             string
	OrderType           string
	TransitionName      sql.NullString
	Description         sql.NullString
	RequiresAuth        bool
	RequiresApproval    bool
	RequiresComment     bool
	AutoTransition      bool
	TransitionCondition sql.NullString
	DisplayOrder        int32
	IsActive            bool
	CreatedAt           time.Time
}

type ListStateTransitionsWithDetailsRow struct {
	ID                  int64
	FromStateID         int64
	ToStateID           int64
	FromState           string
	ToState             string
	OrderType           string
	FromDescription     sql.NullString
	ToDescription       sql.NullString
	TransitionName      sql.NullString
	Description         sql.NullString
	RequiresAuth        bool
	RequiresApproval    bool
	RequiresComment     bool
	AutoTransition      bool
	TransitionCondition sql.NullString
	DisplayOrder        int32
	IsActive            bool
	CreatedAt           time.Time
}

// ============================================================================
// PRICE MODELS
// ============================================================================

type PriceRule struct {
	ID          int64
	RuleCode    string
	RuleName    string
	RuleType    string
	Name        string
	Description sql.NullString
	Priority    int32
	ValidFrom   sql.NullTime
	ValidTo     sql.NullTime
	IsActive    bool
	CreatedAt   time.Time
	UpdatedAt   time.Time
}

// ============================================================================
// PARAMS STRUCTURES
// ============================================================================

// Auth Params
type CreateUserParams struct {
	Username      string
	Email         sql.NullString
	PasswordHash  string
	EntityID      sql.NullInt64
	FirstName     sql.NullString
	LastName      sql.NullString
	MobileNumber  sql.NullString
	IsActive      bool
	IsApproved    bool
	IsSystemAdmin bool
}

type UpdateUserParams struct {
	ID           int64
	Email        sql.NullString
	FirstName    sql.NullString
	LastName     sql.NullString
	MobileNumber sql.NullString
	IsActive     bool
	IsApproved   bool
	UpdatedBy    sql.NullInt64
	ApprovedBy   sql.NullInt64
	ApprovedAt   sql.NullTime
}

type UpdateUserPasswordParams struct {
	ID              int64
	NewPasswordHash string
}

type UpdateUserFailedLoginAttemptsParams struct {
	ID                  int64
	FailedLoginAttempts int32
	LockedUntil         sql.NullTime
}

type UpdateUserLastLoginParams struct {
	ID        int64
	LastLogin sql.NullTime
}

type CreateUserSessionParams struct {
	UserID       int64
	SessionToken string
	IpAddress    sql.NullString
	UserAgent    sql.NullString
	ExpiresAt    time.Time
}

type CheckUserPermissionParams struct {
	UserID         int64
	PermissionCode string
}

// Entity Params
type CreateEntityParams struct {
	Code               string
	SecondaryCode      sql.NullString
	EntityType         string
	CompanyName        sql.NullString
	LegalName          sql.NullString
	FirstName          sql.NullString
	LastName           sql.NullString
	NationalID         sql.NullString
	RegistrationNumber sql.NullString
	Email              sql.NullString
	IsActive           bool
	CreatedBy          sql.NullInt64
}

type UpdateEntityParams struct {
	ID                 int64
	SecondaryCode      sql.NullString
	CompanyName        sql.NullString
	LegalName          sql.NullString
	FirstName          sql.NullString
	LastName           sql.NullString
	NationalID         sql.NullString
	RegistrationNumber sql.NullString
	Email              sql.NullString
	IsActive           bool
	UpdatedBy          sql.NullInt64
}

type ListEntitiesParams struct {
	Search     sql.NullString
	EntityType sql.NullString
	IsActive   sql.NullBool
	Limit      int32
	Offset     int32
}

type CountEntitiesParams struct {
	Search     sql.NullString
	EntityType sql.NullString
	IsActive   sql.NullBool
}

type AssignEntityRoleParams struct {
	EntityID int64
	RoleType string
	RoleID   int64
}

type RemoveEntityRoleParams struct {
	EntityID int64
	RoleType string
	RoleID   int64
}

type CreateEntityPhoneParams struct {
	EntityID    int64
	PhoneNumber string
	PhoneType   string
	IsPrimary   bool
}

type CreateEntityAddressParams struct {
	EntityID    int64
	AddressType sql.NullString
	Address     string
	City        sql.NullString
	Province    sql.NullString
	PostalCode  sql.NullString
	IsPrimary   bool
}

type GetEntitiesWithRoleParams struct {
	RoleType string
	RoleCode string
	Limit    int32
	Offset   int32
}

// Product Params
type CreateProductParams struct {
	Code                string
	SecondaryCode       sql.NullString
	FinancialSystemCode sql.NullString
	Name                string
	ProductType         string
	LensBrandID         sql.NullInt64
	LensTypeID          sql.NullInt64
	LensIndexID         sql.NullInt64
	LensMaterialID      sql.NullInt64
	LensColorID         sql.NullInt64
	LensDesignID        sql.NullInt64
	LensCoatingID       sql.NullInt64
	LensSPH             sql.NullFloat64
	LensCYL             sql.NullFloat64
	LensBase            sql.NullFloat64
	Direction           sql.NullString
	ServiceType         sql.NullString
	BaseUnitID          sql.NullInt64
	IsActive            bool
	CreatedBy           sql.NullInt64
}

type UpdateProductParams struct {
	ID                  int64
	SecondaryCode       sql.NullString
	FinancialSystemCode sql.NullString
	Name                sql.NullString
	IsActive            sql.NullBool
	UpdatedBy           sql.NullInt64
}

type ListProductsParams struct {
	ProductType sql.NullString
	LensBrandID sql.NullInt64
	Search      sql.NullString
	Limit       int32
	Offset      int32
}

type CountProductsParams struct {
	ProductType sql.NullString
}

type FindRxProductParams struct {
	LensBrandID    sql.NullInt64
	LensTypeID     sql.NullInt64
	LensIndexID    sql.NullInt64
	LensMaterialID sql.NullInt64
	LensColorID    sql.NullInt64
	LensDesignID   sql.NullInt64
	LeftSPH        float64
	LeftCYL        float64
	LeftAxis       sql.NullInt32
	LeftAdd        sql.NullFloat64
	LeftBase       sql.NullString
	LeftDirection  sql.NullString
	RightSPH       float64
	RightCYL       float64
	RightAxis      sql.NullInt32
	RightAdd       sql.NullFloat64
	RightBase      sql.NullString
	RightDirection sql.NullString
}

type FindStProductParams struct {
	LensBrandID   sql.NullInt64
	LensIndexID   sql.NullInt64
	LensCoatingID sql.NullInt64
	LeftSPH       float64
	LeftCYL       sql.NullFloat64
	RightSPH      float64
	RightCYL      sql.NullFloat64
}

type FindSemiFinishedProductParams struct {
	Base      float64
	Direction string
}

// RX Order Params
type CreateRxOrderParams struct {
	OrderNumber           string
	CustomerID            int64
	FinalProductID        sql.NullInt64
	SemiFinishedProductID sql.NullInt64
	LensBrandID           sql.NullInt64
	LensTypeID            sql.NullInt64
	LensIndexID           sql.NullInt64
	LensMaterialID        sql.NullInt64
	LensColorID           sql.NullInt64
	LensDesignID          sql.NullInt64
	RightSph              sql.NullFloat64
	RightCyl              sql.NullFloat64
	RightAxis             sql.NullInt32
	RightAddition         sql.NullFloat64
	RightPd               sql.NullFloat64
	RightDecentration     sql.NullFloat64
	RightPrismValue       sql.NullFloat64
	RightPrismBase        sql.NullString
	LeftSph               sql.NullFloat64
	LeftCyl               sql.NullFloat64
	LeftAxis              sql.NullInt32
	LeftAddition          sql.NullFloat64
	LeftPd                sql.NullFloat64
	LeftDecentration      sql.NullFloat64
	LeftPrismValue        sql.NullFloat64
	LeftPrismBase         sql.NullString
	FrameType             sql.NullString
	Hbox                  sql.NullFloat64
	Vbox                  sql.NullFloat64
	Dbl                   sql.NullFloat64
	Ed                    sql.NullFloat64
	Panto                 sql.NullFloat64
	Ffa                   sql.NullFloat64
	Bvd                   sql.NullFloat64
	FrameShapeFile        sql.NullString
	CoatingServiceID      sql.NullInt64
	ColorServiceID        sql.NullInt64
	ColorType             sql.NullString
	ColorSample           sql.NullString
	IsPriority            bool
	BasePrice             sql.NullFloat64
	ServicePrice          sql.NullFloat64
	TotalPrice            sql.NullFloat64
	State                 string
	Priority              string
	CurrentStateID        sql.NullInt64
	Notes                 sql.NullString
	ExpectedDate          sql.NullTime
	CreatedBy             sql.NullInt64
}

type UpdateRxOrderParams struct {
	ID             int64
	RightSph       sql.NullFloat64
	RightCyl       sql.NullFloat64
	LeftSph        sql.NullFloat64
	LeftCyl        sql.NullFloat64
	HBOX           sql.NullFloat64
	VBOX           sql.NullFloat64
	ColorServiceID sql.NullInt64
	Priority       sql.NullString
	IsPriority     sql.NullBool
	Notes          sql.NullString
}

type ListRxOrdersParams struct {
	Search     sql.NullString
	CustomerID sql.NullInt64
	State      sql.NullString
	StateID    sql.NullInt64
	FromDate   sql.NullTime
	ToDate     sql.NullTime
	IsPriority sql.NullBool
	Limit      int32
	Offset     int32
}

type CountRxOrdersParams struct {
	Search     sql.NullString
	CustomerID sql.NullInt64
	StateID    sql.NullInt64
	FromDate   sql.NullTime
	ToDate     sql.NullTime
	IsPriority sql.NullBool
}

// ST Order Params
type CreateStOrderParams struct {
	OrderNumber       string
	CustomerID        int64
	State             string
	UseCuttingService bool
	CuttingServiceID  sql.NullInt64
	ItemsPrice        sql.NullFloat64
	ServicePrice      sql.NullFloat64
	TotalPrice        sql.NullFloat64
	CurrentStateID    sql.NullInt64
	Notes             sql.NullString
	ExpectedDate      sql.NullTime
	CreatedBy         sql.NullInt64
}

type UpdateStOrderParams struct {
	ID                int64
	UseCuttingService sql.NullBool
	CuttingServiceID  sql.NullInt64
	Notes             sql.NullString
}

type ListStOrdersParams struct {
	Search     sql.NullString
	CustomerID sql.NullInt64
	State      sql.NullString
	StateID    sql.NullInt64
	FromDate   sql.NullTime
	ToDate     sql.NullTime
	Limit      int32
	Offset     int32
}

type CountStOrdersParams struct {
	Search     sql.NullString
	CustomerID sql.NullInt64
	StateID    sql.NullInt64
	FromDate   sql.NullTime
	ToDate     sql.NullTime
}

// ============================================================================
// ORDER METHODS PARAMS
// ============================================================================

type GetStateByCodeParams struct {
	StateCode string
	OrderType string
}

type GetNextRxOrderNumberParams struct {
	Prefix string
}

type GetNextStOrderNumberParams struct {
	Prefix string
}

type GetStateTransitionParams struct {
	FromStateID int64
	ToStateID   int64
	OrderType   string
}

type CheckTransitionPermissionParams struct {
	TransitionID int64
	UserID       int64
}

type AddRxOrderExtraServiceParams struct {
	RxOrderID int64
	ServiceID int64
	Price     sql.NullFloat64
}

type CreateRxOrderStateHistoryParams struct {
	RxOrderID int64
	FromState sql.NullString
	ToState   string
	ChangedBy int64
	Notes     sql.NullString
}

type UpdateRxOrderStateParams struct {
	ID      int64
	StateID int64
}

type CreateStOrderPairItemParams struct {
	StOrderID  int64
	ProductID  int64
	RightSPH   float64
	RightCYL   sql.NullFloat64
	LeftSPH    float64
	LeftCYL    sql.NullFloat64
	Quantity   int32
	UnitPrice  sql.NullFloat64
	TotalPrice sql.NullFloat64
}

type CreateStOrderSingleItemParams struct {
	StOrderID  int64
	ProductID  int64
	SPH        float64
	CYL        sql.NullFloat64
	Quantity   int32
	UnitPrice  sql.NullFloat64
	TotalPrice sql.NullFloat64
}

type UpdateStOrderPricingParams struct {
	ID           int64
	ItemsPrice   sql.NullFloat64
	ServicePrice sql.NullFloat64
	TotalPrice   sql.NullFloat64
}

type CreateStOrderStateHistoryParams struct {
	StOrderID int64
	FromState sql.NullString
	ToState   string
	ChangedBy int64
	Notes     sql.NullString
}

type UpdateStOrderStateParams struct {
	ID      int64
	StateID int64
}

// ============================================================================
// INVENTORY PARAMS
// ============================================================================

type ListInventoryTransactionsParams struct {
	WarehouseID     sql.NullInt64
	ProductID       sql.NullInt64
	TransactionType sql.NullString
	FromDate        sql.NullTime
	ToDate          sql.NullTime
	Limit           int32
	Offset          int32
}

type CreateInventoryTransactionParams struct {
	WarehouseID     int64
	ProductID       int64
	UnitID          int64
	Quantity        float64
	QuantityChange  float64
	BalanceAfter    float64
	TransactionType string
	TransactionDate time.Time
	ReferenceType   sql.NullString
	ReferenceID     sql.NullInt64
	Notes           sql.NullString
	Description     sql.NullString
	ProductCode     sql.NullString
	ProductName     sql.NullString
	CreatedBy       int64
}

type ListWarrantyClaimsParams struct {
	WarrantyCardNumber sql.NullString
	RxOrderID          sql.NullInt64
	Status             sql.NullString
	Limit              int32
	Offset             int32
}
type WarrantyClaim struct {
	ID                 int64
	WarrantyCardNumber string
	RxOrderID          sql.NullInt64
	ClaimDate          time.Time
	ClaimType          string
	IssueDescription   string
	Resolution         sql.NullString
	ResolvedAt         sql.NullTime
	Status             string
	CreatedBy          int64
	CreatedAt          time.Time
}

// Continua nos próximos arquivos...
