package repository

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5"
)

// ============================================================================
// RX ORDER METHODS - COMPLETE WITH SQL
// ============================================================================

func (r *Repository) CreateRxOrder(ctx context.Context, params CreateRxOrderParams) (*RxOrder, error) {
	query := `
		INSERT INTO rx_orders (
			order_number, customer_id, final_product_id, semi_finished_product_id,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id,
			right_sph, right_cyl, right_axis, right_addition, right_pd,
			right_decentration, right_prism_value, right_prism_base,
			left_sph, left_cyl, left_axis, left_addition, left_pd,
			left_decentration, left_prism_value, left_prism_base,
			frame_type, hbox, vbox, dbl, ed, panto, ffa, bvd, frame_shape_file,
			coating_service_id, color_service_id, color_type, color_sample,
			is_priority, base_price, service_price, total_price,
			state, priority, current_state_id, notes, expected_date, created_by
		) VALUES (
			$1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
			$11, $12, $13, $14, $15, $16, $17, $18,
			$19, $20, $21, $22, $23, $24, $25, $26,
			$27, $28, $29, $30, $31, $32, $33, $34, $35,
			$36, $37, $38, $39, $40, $41, $42, $43,
			$44, $45, $46, $47, $48, $49
		)
		RETURNING 
			id, order_number, customer_id, final_product_id, semi_finished_product_id,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id,
			right_sph, right_cyl, right_axis, right_addition, right_pd,
			right_decentration, right_prism_value, right_prism_base,
			left_sph, left_cyl, left_axis, left_addition, left_pd,
			left_decentration, left_prism_value, left_prism_base,
			frame_type, hbox, vbox, dbl, ed, panto, ffa, bvd, frame_shape_file,
			coating_service_id, color_service_id, color_type, color_sample,
			is_priority, base_price, service_price, total_price,
			state, priority, current_state_id, notes, expected_date, created_by,
			created_at, updated_at
	`

	var order RxOrder
	err := r.db.QueryRow(ctx, query,
		params.OrderNumber, params.CustomerID, params.FinalProductID, params.SemiFinishedProductID,
		params.LensBrandID, params.LensTypeID, params.LensIndexID, params.LensMaterialID,
		params.LensColorID, params.LensDesignID,
		params.RightSph, params.RightCyl, params.RightAxis, params.RightAddition, params.RightPd,
		params.RightDecentration, params.RightPrismValue, params.RightPrismBase,
		params.LeftSph, params.LeftCyl, params.LeftAxis, params.LeftAddition, params.LeftPd,
		params.LeftDecentration, params.LeftPrismValue, params.LeftPrismBase,
		params.FrameType, params.Hbox, params.Vbox, params.Dbl, params.Ed, params.Panto, params.Ffa, params.Bvd, params.FrameShapeFile,
		params.CoatingServiceID, params.ColorServiceID, params.ColorType, params.ColorSample,
		params.IsPriority, params.BasePrice, params.ServicePrice, params.TotalPrice,
		params.State, params.Priority, params.CurrentStateID, params.Notes, params.ExpectedDate, params.CreatedBy,
	).Scan(
		&order.ID, &order.OrderNumber, &order.CustomerID, &order.FinalProductID, &order.SemiFinishedProductID,
		&order.LensBrandID, &order.LensTypeID, &order.LensIndexID, &order.LensMaterialID,
		&order.LensColorID, &order.LensDesignID,
		&order.RightSph, &order.RightCyl, &order.RightAxis, &order.RightAddition, &order.RightPd,
		&order.RightDecentration, &order.RightPrismValue, &order.RightPrismBase,
		&order.LeftSph, &order.LeftCyl, &order.LeftAxis, &order.LeftAddition, &order.LeftPd,
		&order.LeftDecentration, &order.LeftPrismValue, &order.LeftPrismBase,
		&order.FrameType, &order.Hbox, &order.Vbox, &order.Dbl, &order.Ed, &order.Panto, &order.Ffa, &order.Bvd, &order.FrameShapeFile,
		&order.CoatingServiceID, &order.ColorServiceID, &order.ColorType, &order.ColorSample,
		&order.IsPriority, &order.BasePrice, &order.ServicePrice, &order.TotalPrice,
		&order.State, &order.Priority, &order.CurrentStateID, &order.Notes, &order.ExpectedDate, &order.CreatedBy,
		&order.CreatedAt, &order.UpdatedAt,
	)

	if err != nil {
		return nil, fmt.Errorf("create rx order: %w", err)
	}

	return &order, nil
}

func (r *Repository) GetRxOrder(ctx context.Context, id int64) (*RxOrder, error) {
	query := `
		SELECT 
			id, order_number, customer_id, final_product_id, semi_finished_product_id,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id,
			right_sph, right_cyl, right_axis, right_addition, right_pd,
			right_decentration, right_prism_value, right_prism_base,
			left_sph, left_cyl, left_axis, left_addition, left_pd,
			left_decentration, left_prism_value, left_prism_base,
			frame_type, hbox, vbox, dbl, ed, panto, ffa, bvd, frame_shape_file,
			coating_service_id, color_service_id, color_type, color_sample,
			is_priority, base_price, service_price, total_price,
			state, priority, current_state_id, notes, expected_date, created_by,
			created_at, updated_at
		FROM rx_orders
		WHERE id = $1
	`

	var order RxOrder
	err := r.db.QueryRow(ctx, query, id).Scan(
		&order.ID, &order.OrderNumber, &order.CustomerID, &order.FinalProductID, &order.SemiFinishedProductID,
		&order.LensBrandID, &order.LensTypeID, &order.LensIndexID, &order.LensMaterialID,
		&order.LensColorID, &order.LensDesignID,
		&order.RightSph, &order.RightCyl, &order.RightAxis, &order.RightAddition, &order.RightPd,
		&order.RightDecentration, &order.RightPrismValue, &order.RightPrismBase,
		&order.LeftSph, &order.LeftCyl, &order.LeftAxis, &order.LeftAddition, &order.LeftPd,
		&order.LeftDecentration, &order.LeftPrismValue, &order.LeftPrismBase,
		&order.FrameType, &order.Hbox, &order.Vbox, &order.Dbl, &order.Ed, &order.Panto, &order.Ffa, &order.Bvd, &order.FrameShapeFile,
		&order.CoatingServiceID, &order.ColorServiceID, &order.ColorType, &order.ColorSample,
		&order.IsPriority, &order.BasePrice, &order.ServicePrice, &order.TotalPrice,
		&order.State, &order.Priority, &order.CurrentStateID, &order.Notes, &order.ExpectedDate, &order.CreatedBy,
		&order.CreatedAt, &order.UpdatedAt,
	)

	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("rx order not found")
	}
	if err != nil {
		return nil, fmt.Errorf("get rx order: %w", err)
	}

	return &order, nil
}

func (r *Repository) ListRxOrders(ctx context.Context, params ListRxOrdersParams) ([]RxOrder, error) {
	query := `
		SELECT 
			id, order_number, customer_id, final_product_id, semi_finished_product_id,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id,
			right_sph, right_cyl, right_axis, right_addition, right_pd,
			right_decentration, right_prism_value, right_prism_base,
			left_sph, left_cyl, left_axis, left_addition, left_pd,
			left_decentration, left_prism_value, left_prism_base,
			frame_type, hbox, vbox, dbl, ed, panto, ffa, bvd, frame_shape_file,
			coating_service_id, color_service_id, color_type, color_sample,
			is_priority, base_price, service_price, total_price,
			state, priority, current_state_id, notes, expected_date, created_by,
			created_at, updated_at
		FROM rx_orders
		WHERE 
			($1::text IS NULL OR order_number ILIKE '%' || $1 || '%')
			AND ($2::bigint IS NULL OR customer_id = $2)
			AND ($3::text IS NULL OR state = $3)
			AND ($4::bigint IS NULL OR current_state_id = $4)
			AND ($5::timestamp IS NULL OR created_at >= $5)
			AND ($6::timestamp IS NULL OR created_at <= $6)
			AND ($7::boolean IS NULL OR is_priority = $7)
		ORDER BY created_at DESC
		LIMIT $8 OFFSET $9
	`

	rows, err := r.db.Query(ctx, query,
		params.Search,
		params.CustomerID,
		params.State,
		params.StateID,
		params.FromDate,
		params.ToDate,
		params.IsPriority,
		params.Limit,
		params.Offset,
	)
	if err != nil {
		return nil, fmt.Errorf("list rx orders: %w", err)
	}
	defer rows.Close()

	var orders []RxOrder
	for rows.Next() {
		var order RxOrder
		if err := rows.Scan(
			&order.ID, &order.OrderNumber, &order.CustomerID, &order.FinalProductID, &order.SemiFinishedProductID,
			&order.LensBrandID, &order.LensTypeID, &order.LensIndexID, &order.LensMaterialID,
			&order.LensColorID, &order.LensDesignID,
			&order.RightSph, &order.RightCyl, &order.RightAxis, &order.RightAddition, &order.RightPd,
			&order.RightDecentration, &order.RightPrismValue, &order.RightPrismBase,
			&order.LeftSph, &order.LeftCyl, &order.LeftAxis, &order.LeftAddition, &order.LeftPd,
			&order.LeftDecentration, &order.LeftPrismValue, &order.LeftPrismBase,
			&order.FrameType, &order.Hbox, &order.Vbox, &order.Dbl, &order.Ed, &order.Panto, &order.Ffa, &order.Bvd, &order.FrameShapeFile,
			&order.CoatingServiceID, &order.ColorServiceID, &order.ColorType, &order.ColorSample,
			&order.IsPriority, &order.BasePrice, &order.ServicePrice, &order.TotalPrice,
			&order.State, &order.Priority, &order.CurrentStateID, &order.Notes, &order.ExpectedDate, &order.CreatedBy,
			&order.CreatedAt, &order.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan rx order: %w", err)
		}
		orders = append(orders, order)
	}

	return orders, rows.Err()
}

func (r *Repository) CountRxOrders(ctx context.Context, params CountRxOrdersParams) (int64, error) {
	query := `
		SELECT COUNT(*)
		FROM rx_orders
		WHERE 
			($1::text IS NULL OR order_number ILIKE '%' || $1 || '%')
			AND ($2::bigint IS NULL OR customer_id = $2)
			AND ($3::bigint IS NULL OR current_state_id = $3)
			AND ($4::timestamp IS NULL OR created_at >= $4)
			AND ($5::timestamp IS NULL OR created_at <= $5)
			AND ($6::boolean IS NULL OR is_priority = $6)
	`

	var count int64
	err := r.db.QueryRow(ctx, query,
		params.Search,
		params.CustomerID,
		params.StateID,
		params.FromDate,
		params.ToDate,
		params.IsPriority,
	).Scan(&count)

	if err != nil {
		return 0, fmt.Errorf("count rx orders: %w", err)
	}

	return count, nil
}

func (r *Repository) UpdateRxOrder(ctx context.Context, params UpdateRxOrderParams) (*RxOrder, error) {
	query := `
		UPDATE rx_orders
		SET 
			right_sph = COALESCE($2, right_sph),
			right_cyl = COALESCE($3, right_cyl),
			left_sph = COALESCE($4, left_sph),
			left_cyl = COALESCE($5, left_cyl),
			hbox = COALESCE($6, hbox),
			vbox = COALESCE($7, vbox),
			color_service_id = COALESCE($8, color_service_id),
			priority = COALESCE($9, priority),
			notes = COALESCE($10, notes),
			updated_at = NOW()
		WHERE id = $1
		RETURNING 
			id, order_number, customer_id, final_product_id, semi_finished_product_id,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id,
			right_sph, right_cyl, right_axis, right_addition, right_pd,
			right_decentration, right_prism_value, right_prism_base,
			left_sph, left_cyl, left_axis, left_addition, left_pd,
			left_decentration, left_prism_value, left_prism_base,
			frame_type, hbox, vbox, dbl, ed, panto, ffa, bvd, frame_shape_file,
			coating_service_id, color_service_id, color_type, color_sample,
			is_priority, base_price, service_price, total_price,
			state, priority, current_state_id, notes, expected_date, created_by,
			created_at, updated_at
	`

	var order RxOrder
	err := r.db.QueryRow(ctx, query,
		params.ID,
		params.RightSph,
		params.RightCyl,
		params.LeftSph,
		params.LeftCyl,
		params.HBOX,
		params.VBOX,
		params.ColorServiceID,
		params.Priority,
		params.Notes,
	).Scan(
		&order.ID, &order.OrderNumber, &order.CustomerID, &order.FinalProductID, &order.SemiFinishedProductID,
		&order.LensBrandID, &order.LensTypeID, &order.LensIndexID, &order.LensMaterialID,
		&order.LensColorID, &order.LensDesignID,
		&order.RightSph, &order.RightCyl, &order.RightAxis, &order.RightAddition, &order.RightPd,
		&order.RightDecentration, &order.RightPrismValue, &order.RightPrismBase,
		&order.LeftSph, &order.LeftCyl, &order.LeftAxis, &order.LeftAddition, &order.LeftPd,
		&order.LeftDecentration, &order.LeftPrismValue, &order.LeftPrismBase,
		&order.FrameType, &order.Hbox, &order.Vbox, &order.Dbl, &order.Ed, &order.Panto, &order.Ffa, &order.Bvd, &order.FrameShapeFile,
		&order.CoatingServiceID, &order.ColorServiceID, &order.ColorType, &order.ColorSample,
		&order.IsPriority, &order.BasePrice, &order.ServicePrice, &order.TotalPrice,
		&order.State, &order.Priority, &order.CurrentStateID, &order.Notes, &order.ExpectedDate, &order.CreatedBy,
		&order.CreatedAt, &order.UpdatedAt,
	)

	if err != nil {
		return nil, fmt.Errorf("update rx order: %w", err)
	}

	return &order, nil
}

func (r *Repository) DeleteRxOrder(ctx context.Context, id int64) error {
	query := `DELETE FROM rx_orders WHERE id = $1`

	result, err := r.db.Exec(ctx, query, id)
	if err != nil {
		return fmt.Errorf("delete rx order: %w", err)
	}

	if result.RowsAffected() == 0 {
		return fmt.Errorf("rx order not found")
	}

	return nil
}

// Helper methods
func (r *Repository) AddRxOrderExtraService(ctx context.Context, params AddRxOrderExtraServiceParams) error {
	query := `INSERT INTO rx_order_extra_services (rx_order_id, service_id, price) VALUES ($1, $2, $3)`
	_, err := r.db.Exec(ctx, query, params.RxOrderID, params.ServiceID, params.Price)
	return err
}

func (r *Repository) ClearRxOrderExtraServices(ctx context.Context, rxOrderID int64) error {
	query := `DELETE FROM rx_order_extra_services WHERE rx_order_id = $1`
	_, err := r.db.Exec(ctx, query, rxOrderID)
	return err
}

func (r *Repository) CreateRxOrderStateHistory(ctx context.Context, params CreateRxOrderStateHistoryParams) error {
	query := `INSERT INTO rx_order_state_history (rx_order_id, from_state, to_state, changed_by, notes) VALUES ($1, $2, $3, $4, $5)`
	_, err := r.db.Exec(ctx, query, params.RxOrderID, params.FromState, params.ToState, params.ChangedBy, params.Notes)
	return err
}

func (r *Repository) UpdateRxOrderState(ctx context.Context, params UpdateRxOrderStateParams) error {
	query := `UPDATE rx_orders SET current_state_id = $2, updated_at = NOW() WHERE id = $1`
	_, err := r.db.Exec(ctx, query, params.ID, params.StateID)
	return err
}

func (r *Repository) GetStateByCode(ctx context.Context, stateCode string, orderType string) (*State, error) {
	query := `SELECT id, state_code, state_name, state_type, description, color, icon, display_order, is_active, order_type, created_at FROM states WHERE state_code = $1 AND order_type = $2`
	var state State
	err := r.db.QueryRow(ctx, query, stateCode, orderType).Scan(&state.ID, &state.StateCode, &state.StateName, &state.StateType, &state.Description, &state.Color, &state.Icon, &state.DisplayOrder, &state.IsActive, &state.OrderType, &state.CreatedAt)
	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("state not found")
	}
	return &state, err
}

func (r *Repository) GetState(ctx context.Context, id int64) (*State, error) {
	query := `SELECT id, state_code, state_name, state_type, description, color, icon, display_order, is_active, order_type, created_at FROM states WHERE id = $1`
	var state State
	err := r.db.QueryRow(ctx, query, id).Scan(&state.ID, &state.StateCode, &state.StateName, &state.StateType, &state.Description, &state.Color, &state.Icon, &state.DisplayOrder, &state.IsActive, &state.OrderType, &state.CreatedAt)
	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("state not found")
	}
	return &state, err
}

func (r *Repository) GetNextRxOrderNumber(ctx context.Context) (string, error) {
	query := `SELECT COALESCE(MAX(CAST(SUBSTRING(order_number FROM '[0-9]+') AS INTEGER)), 0) + 1 FROM rx_orders WHERE order_number ~ '^RX[0-9]+$'`
	var nextNum int
	err := r.db.QueryRow(ctx, query).Scan(&nextNum)
	if err != nil {
		return "", err
	}
	return fmt.Sprintf("RX%06d", nextNum), nil
}

func (r *Repository) GetStateTransition(ctx context.Context, params GetStateTransitionParams) (*StateTransition, error) {
	query := `SELECT id, from_state_id, to_state_id, from_state, to_state, order_type, transition_name, description, requires_auth, requires_approval, requires_comment, auto_transition, transition_condition, display_order, is_active, created_at FROM state_transitions WHERE from_state_id = $1 AND to_state_id = $2 AND order_type = $3`
	var t StateTransition
	err := r.db.QueryRow(ctx, query, params.FromStateID, params.ToStateID, params.OrderType).Scan(&t.ID, &t.FromStateID, &t.ToStateID, &t.FromState, &t.ToState, &t.OrderType, &t.TransitionName, &t.Description, &t.RequiresAuth, &t.RequiresApproval, &t.RequiresComment, &t.AutoTransition, &t.TransitionCondition, &t.DisplayOrder, &t.IsActive, &t.CreatedAt)
	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("transition not found")
	}
	return &t, err
}

func (r *Repository) CheckTransitionPermission(ctx context.Context, params CheckTransitionPermissionParams) (bool, error) {
	query := `SELECT is_system_admin FROM users WHERE id = $1`
	var isAdmin bool
	err := r.db.QueryRow(ctx, query, params.UserID).Scan(&isAdmin)
	return isAdmin, err
}
