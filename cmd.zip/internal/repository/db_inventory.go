package repository

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5"
)

// ============================================================================
// INVENTORY METHODS - COMPLETE WITH SQL
// ============================================================================

func (r *Repository) GetInventoryBalance(ctx context.Context, productID int64, warehouseID int64, unitID int64) (*InventoryBalance, error) {
	query := `
		SELECT id, product_id, warehouse_id, unit_id, quantity_on_hand, 
		       quantity_reserved, quantity_available, last_updated
		FROM inventory_balances
		WHERE product_id = $1 AND warehouse_id = $2 AND unit_id = $3
	`
	
	var balance InventoryBalance
	err := r.db.QueryRow(ctx, query, productID, warehouseID, unitID).Scan(
		&balance.ID,
		&balance.ProductID,
		&balance.WarehouseID,
		&balance.UnitID,
		&balance.QuantityOnHand,
		&balance.QuantityReserved,
		&balance.QuantityAvailable,
		&balance.LastUpdated,
	)
	
	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("inventory balance not found")
	}
	if err != nil {
		return nil, fmt.Errorf("get inventory balance: %w", err)
	}
	
	return &balance, nil
}

func (r *Repository) GetInventoryBalanceByProduct(ctx context.Context, productID int64) ([]InventoryBalance, error) {
	query := `
		SELECT id, product_id, warehouse_id, unit_id, quantity_on_hand, 
		       quantity_reserved, quantity_available, last_updated
		FROM inventory_balances
		WHERE product_id = $1
	`
	
	rows, err := r.db.Query(ctx, query, productID)
	if err != nil {
		return nil, fmt.Errorf("get inventory balance by product: %w", err)
	}
	defer rows.Close()
	
	var balances []InventoryBalance
	for rows.Next() {
		var balance InventoryBalance
		if err := rows.Scan(
			&balance.ID,
			&balance.ProductID,
			&balance.WarehouseID,
			&balance.UnitID,
			&balance.QuantityOnHand,
			&balance.QuantityReserved,
			&balance.QuantityAvailable,
			&balance.LastUpdated,
		); err != nil {
			return nil, fmt.Errorf("scan inventory balance: %w", err)
		}
		balances = append(balances, balance)
	}
	
	return balances, rows.Err()
}

func (r *Repository) ListInventoryBalances(ctx context.Context, warehouseID int64) ([]InventoryBalance, error) {
	query := `
		SELECT id, product_id, warehouse_id, unit_id, quantity_on_hand, 
		       quantity_reserved, quantity_available, last_updated
		FROM inventory_balances
		WHERE warehouse_id = $1
		ORDER BY product_id
	`
	
	rows, err := r.db.Query(ctx, query, warehouseID)
	if err != nil {
		return nil, fmt.Errorf("list inventory balances: %w", err)
	}
	defer rows.Close()
	
	var balances []InventoryBalance
	for rows.Next() {
		var balance InventoryBalance
		if err := rows.Scan(
			&balance.ID,
			&balance.ProductID,
			&balance.WarehouseID,
			&balance.UnitID,
			&balance.QuantityOnHand,
			&balance.QuantityReserved,
			&balance.QuantityAvailable,
			&balance.LastUpdated,
		); err != nil {
			return nil, fmt.Errorf("scan inventory balance: %w", err)
		}
		balances = append(balances, balance)
	}
	
	return balances, rows.Err()
}

func (r *Repository) ListInventoryBalancesByProduct(ctx context.Context, productID int64) ([]InventoryBalance, error) {
	return r.GetInventoryBalanceByProduct(ctx, productID)
}

func (r *Repository) UpdateInventoryReservation(ctx context.Context, productID int64, warehouseID int64, unitID int64, quantity float64) error {
	query := `
		UPDATE inventory_balances
		SET quantity_reserved = quantity_reserved + $4,
		    quantity_available = quantity_available - $4,
		    last_updated = NOW()
		WHERE product_id = $1 AND warehouse_id = $2 AND unit_id = $3
		  AND quantity_available >= $4
	`
	
	result, err := r.db.Exec(ctx, query, productID, warehouseID, unitID, quantity)
	if err != nil {
		return fmt.Errorf("update inventory reservation: %w", err)
	}
	
	if result.RowsAffected() == 0 {
		return fmt.Errorf("insufficient inventory or balance not found")
	}
	
	return nil
}

func (r *Repository) ReleaseInventoryReservation(ctx context.Context, productID int64, warehouseID int64, unitID int64, quantity float64) error {
	query := `
		UPDATE inventory_balances
		SET quantity_reserved = quantity_reserved - $4,
		    quantity_available = quantity_available + $4,
		    last_updated = NOW()
		WHERE product_id = $1 AND warehouse_id = $2 AND unit_id = $3
	`
	
	_, err := r.db.Exec(ctx, query, productID, warehouseID, unitID, quantity)
	if err != nil {
		return fmt.Errorf("release inventory reservation: %w", err)
	}
	
	return nil
}

func (r *Repository) InsertInventoryTransaction(ctx context.Context, params CreateInventoryTransactionParams) (*InventoryTransaction, error) {
	query := `
		INSERT INTO inventory_transactions (
			warehouse_id, product_id, unit_id, quantity, quantity_change,
			balance_after, transaction_type, transaction_date, reference_type,
			reference_id, notes, description, product_code, product_name, created_by
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
		RETURNING id, warehouse_id, product_id, unit_id, quantity, quantity_change,
		          balance_after, transaction_type, transaction_date, reference_type,
		          reference_id, notes, description, product_code, product_name, 
		          created_at, created_by
	`
	
	var txn InventoryTransaction
	err := r.db.QueryRow(ctx, query,
		params.WarehouseID,
		params.ProductID,
		params.UnitID,
		params.Quantity,
		params.QuantityChange,
		params.BalanceAfter,
		params.TransactionType,
		params.TransactionDate,
		params.ReferenceType,
		params.ReferenceID,
		params.Notes,
		params.Description,
		params.ProductCode,
		params.ProductName,
		params.CreatedBy,
	).Scan(
		&txn.ID,
		&txn.WarehouseID,
		&txn.ProductID,
		&txn.UnitID,
		&txn.Quantity,
		&txn.QuantityChange,
		&txn.BalanceAfter,
		&txn.TransactionType,
		&txn.TransactionDate,
		&txn.ReferenceType,
		&txn.ReferenceID,
		&txn.Notes,
		&txn.Description,
		&txn.ProductCode,
		&txn.ProductName,
		&txn.CreatedAt,
		&txn.CreatedBy,
	)
	
	if err != nil {
		return nil, fmt.Errorf("insert inventory transaction: %w", err)
	}
	
	return &txn, nil
}

func (r *Repository) CreateInventoryTransaction(ctx context.Context, params CreateInventoryTransactionParams) (*InventoryTransaction, error) {
	return r.InsertInventoryTransaction(ctx, params)
}

func (r *Repository) ListInventoryTransactions(ctx context.Context, params ListInventoryTransactionsParams) ([]InventoryTransaction, error) {
	query := `
		SELECT id, warehouse_id, product_id, unit_id, quantity, quantity_change,
		       balance_after, transaction_type, transaction_date, reference_type,
		       reference_id, notes, description, product_code, product_name, 
		       created_at, created_by
		FROM inventory_transactions
		WHERE ($1::bigint IS NULL OR warehouse_id = $1)
		  AND ($2::bigint IS NULL OR product_id = $2)
		  AND ($3::text IS NULL OR transaction_type = $3)
		  AND ($4::timestamp IS NULL OR transaction_date >= $4)
		  AND ($5::timestamp IS NULL OR transaction_date <= $5)
		ORDER BY transaction_date DESC, created_at DESC
		LIMIT $6 OFFSET $7
	`
	
	rows, err := r.db.Query(ctx, query,
		params.WarehouseID,
		params.ProductID,
		params.TransactionType,
		params.FromDate,
		params.ToDate,
		params.Limit,
		params.Offset,
	)
	if err != nil {
		return nil, fmt.Errorf("list inventory transactions: %w", err)
	}
	defer rows.Close()
	
	var transactions []InventoryTransaction
	for rows.Next() {
		var txn InventoryTransaction
		if err := rows.Scan(
			&txn.ID,
			&txn.WarehouseID,
			&txn.ProductID,
			&txn.UnitID,
			&txn.Quantity,
			&txn.QuantityChange,
			&txn.BalanceAfter,
			&txn.TransactionType,
			&txn.TransactionDate,
			&txn.ReferenceType,
			&txn.ReferenceID,
			&txn.Notes,
			&txn.Description,
			&txn.ProductCode,
			&txn.ProductName,
			&txn.CreatedAt,
			&txn.CreatedBy,
		); err != nil {
			return nil, fmt.Errorf("scan inventory transaction: %w", err)
		}
		transactions = append(transactions, txn)
	}
	
	return transactions, rows.Err()
}

// Warranty methods
func (r *Repository) ListWarrantyClaims(ctx context.Context, params ListWarrantyClaimsParams) ([]WarrantyClaim, error) {
	query := `
		SELECT id, warranty_card_number, rx_order_id, claim_date, claim_type,
		       issue_description, resolution, resolved_at, status, created_by, created_at
		FROM warranty_claims
		WHERE ($1::text IS NULL OR warranty_card_number = $1)
		  AND ($2::bigint IS NULL OR rx_order_id = $2)
		  AND ($3::text IS NULL OR status = $3)
		ORDER BY created_at DESC
		LIMIT $4 OFFSET $5
	`
	
	rows, err := r.db.Query(ctx, query,
		params.WarrantyCardNumber,
		params.RxOrderID,
		params.Status,
		params.Limit,
		params.Offset,
	)
	if err != nil {
		return nil, fmt.Errorf("list warranty claims: %w", err)
	}
	defer rows.Close()
	
	var claims []WarrantyClaim
	for rows.Next() {
		var claim WarrantyClaim
		if err := rows.Scan(
			&claim.ID,
			&claim.WarrantyCardNumber,
			&claim.RxOrderID,
			&claim.ClaimDate,
			&claim.ClaimType,
			&claim.IssueDescription,
			&claim.Resolution,
			&claim.ResolvedAt,
			&claim.Status,
			&claim.CreatedBy,
			&claim.CreatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan warranty claim: %w", err)
		}
		claims = append(claims, claim)
	}
	
	return claims, rows.Err()
}
