package repository

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5"
)

// ============================================================================
// ST ORDER METHODS - COMPLETE WITH SQL
// ============================================================================

func (r *Repository) CreateStOrder(ctx context.Context, params CreateStOrderParams) (*StOrder, error) {
	query := `
		INSERT INTO st_orders (
			order_number, customer_id, state, use_cutting_service,
			cutting_service_id, items_price, service_price, total_price,
			current_state_id, notes, expected_date, created_by
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
		RETURNING 
			id, order_number, customer_id, state, use_cutting_service,
			cutting_service_id, items_price, service_price, total_price,
			current_state_id, notes, expected_date, created_by,
			created_at, updated_at
	`
	
	var order StOrder
	err := r.db.QueryRow(ctx, query,
		params.OrderNumber, params.CustomerID, params.State, params.UseCuttingService,
		params.CuttingServiceID, params.ItemsPrice, params.ServicePrice, params.TotalPrice,
		params.CurrentStateID, params.Notes, params.ExpectedDate, params.CreatedBy,
	).Scan(
		&order.ID, &order.OrderNumber, &order.CustomerID, &order.State, &order.UseCuttingService,
		&order.CuttingServiceID, &order.ItemsPrice, &order.ServicePrice, &order.TotalPrice,
		&order.CurrentStateID, &order.Notes, &order.ExpectedDate, &order.CreatedBy,
		&order.CreatedAt, &order.UpdatedAt,
	)
	
	if err != nil {
		return nil, fmt.Errorf("create st order: %w", err)
	}
	
	return &order, nil
}

func (r *Repository) GetStOrder(ctx context.Context, id int64) (*StOrder, error) {
	query := `
		SELECT 
			id, order_number, customer_id, state, use_cutting_service,
			cutting_service_id, items_price, service_price, total_price,
			current_state_id, notes, expected_date, created_by,
			created_at, updated_at
		FROM st_orders
		WHERE id = $1
	`
	
	var order StOrder
	err := r.db.QueryRow(ctx, query, id).Scan(
		&order.ID, &order.OrderNumber, &order.CustomerID, &order.State, &order.UseCuttingService,
		&order.CuttingServiceID, &order.ItemsPrice, &order.ServicePrice, &order.TotalPrice,
		&order.CurrentStateID, &order.Notes, &order.ExpectedDate, &order.CreatedBy,
		&order.CreatedAt, &order.UpdatedAt,
	)
	
	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("st order not found")
	}
	if err != nil {
		return nil, fmt.Errorf("get st order: %w", err)
	}
	
	return &order, nil
}

func (r *Repository) ListStOrders(ctx context.Context, params ListStOrdersParams) ([]StOrder, error) {
	query := `
		SELECT 
			id, order_number, customer_id, state, use_cutting_service,
			cutting_service_id, items_price, service_price, total_price,
			current_state_id, notes, expected_date, created_by,
			created_at, updated_at
		FROM st_orders
		WHERE 
			($1::text IS NULL OR order_number ILIKE '%' || $1 || '%')
			AND ($2::bigint IS NULL OR customer_id = $2)
			AND ($3::text IS NULL OR state = $3)
			AND ($4::bigint IS NULL OR current_state_id = $4)
			AND ($5::timestamp IS NULL OR created_at >= $5)
			AND ($6::timestamp IS NULL OR created_at <= $6)
		ORDER BY created_at DESC
		LIMIT $7 OFFSET $8
	`
	
	rows, err := r.db.Query(ctx, query,
		params.Search,
		params.CustomerID,
		params.State,
		params.StateID,
		params.FromDate,
		params.ToDate,
		params.Limit,
		params.Offset,
	)
	if err != nil {
		return nil, fmt.Errorf("list st orders: %w", err)
	}
	defer rows.Close()
	
	var orders []StOrder
	for rows.Next() {
		var order StOrder
		if err := rows.Scan(
			&order.ID, &order.OrderNumber, &order.CustomerID, &order.State, &order.UseCuttingService,
			&order.CuttingServiceID, &order.ItemsPrice, &order.ServicePrice, &order.TotalPrice,
			&order.CurrentStateID, &order.Notes, &order.ExpectedDate, &order.CreatedBy,
			&order.CreatedAt, &order.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan st order: %w", err)
		}
		orders = append(orders, order)
	}
	
	return orders, rows.Err()
}

func (r *Repository) CountStOrders(ctx context.Context, params CountStOrdersParams) (int64, error) {
	query := `
		SELECT COUNT(*)
		FROM st_orders
		WHERE 
			($1::text IS NULL OR order_number ILIKE '%' || $1 || '%')
			AND ($2::bigint IS NULL OR customer_id = $2)
			AND ($3::bigint IS NULL OR current_state_id = $3)
			AND ($4::timestamp IS NULL OR created_at >= $4)
			AND ($5::timestamp IS NULL OR created_at <= $5)
	`
	
	var count int64
	err := r.db.QueryRow(ctx, query,
		params.Search,
		params.CustomerID,
		params.StateID,
		params.FromDate,
		params.ToDate,
	).Scan(&count)
	
	if err != nil {
		return 0, fmt.Errorf("count st orders: %w", err)
	}
	
	return count, nil
}

func (r *Repository) UpdateStOrder(ctx context.Context, params UpdateStOrderParams) (*StOrder, error) {
	query := `
		UPDATE st_orders
		SET 
			use_cutting_service = COALESCE($2, use_cutting_service),
			cutting_service_id = COALESCE($3, cutting_service_id),
			notes = COALESCE($4, notes),
			updated_at = NOW()
		WHERE id = $1
		RETURNING 
			id, order_number, customer_id, state, use_cutting_service,
			cutting_service_id, items_price, service_price, total_price,
			current_state_id, notes, expected_date, created_by,
			created_at, updated_at
	`
	
	var order StOrder
	err := r.db.QueryRow(ctx, query,
		params.ID,
		params.UseCuttingService,
		params.CuttingServiceID,
		params.Notes,
	).Scan(
		&order.ID, &order.OrderNumber, &order.CustomerID, &order.State, &order.UseCuttingService,
		&order.CuttingServiceID, &order.ItemsPrice, &order.ServicePrice, &order.TotalPrice,
		&order.CurrentStateID, &order.Notes, &order.ExpectedDate, &order.CreatedBy,
		&order.CreatedAt, &order.UpdatedAt,
	)
	
	if err != nil {
		return nil, fmt.Errorf("update st order: %w", err)
	}
	
	return &order, nil
}

func (r *Repository) DeleteStOrder(ctx context.Context, id int64) error {
	query := `DELETE FROM st_orders WHERE id = $1`
	
	result, err := r.db.Exec(ctx, query, id)
	if err != nil {
		return fmt.Errorf("delete st order: %w", err)
	}
	
	if result.RowsAffected() == 0 {
		return fmt.Errorf("st order not found")
	}
	
	return nil
}

// Helper methods for ST Orders
func (r *Repository) CreateStOrderPairItem(ctx context.Context, params CreateStOrderPairItemParams) error {
	query := `
		INSERT INTO st_order_pair_items (
			st_order_id, product_id, right_sph, right_cyl, left_sph, left_cyl,
			quantity, unit_price, total_price
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
	`
	
	_, err := r.db.Exec(ctx, query,
		params.StOrderID, params.ProductID,
		params.RightSPH, params.RightCYL,
		params.LeftSPH, params.LeftCYL,
		params.Quantity, params.UnitPrice, params.TotalPrice,
	)
	if err != nil {
		return fmt.Errorf("create st order pair item: %w", err)
	}
	
	return nil
}

func (r *Repository) CreateStOrderSingleItem(ctx context.Context, params CreateStOrderSingleItemParams) error {
	query := `
		INSERT INTO st_order_single_items (
			st_order_id, product_id, sph, cyl, quantity, unit_price, total_price
		) VALUES ($1, $2, $3, $4, $5, $6, $7)
	`
	
	_, err := r.db.Exec(ctx, query,
		params.StOrderID, params.ProductID,
		params.SPH, params.CYL,
		params.Quantity, params.UnitPrice, params.TotalPrice,
	)
	if err != nil {
		return fmt.Errorf("create st order single item: %w", err)
	}
	
	return nil
}

func (r *Repository) UpdateStOrderPricing(ctx context.Context, params UpdateStOrderPricingParams) error {
	query := `
		UPDATE st_orders
		SET 
			items_price = COALESCE($2, items_price),
			service_price = COALESCE($3, service_price),
			total_price = COALESCE($4, total_price),
			updated_at = NOW()
		WHERE id = $1
	`
	
	_, err := r.db.Exec(ctx, query,
		params.ID,
		params.ItemsPrice,
		params.ServicePrice,
		params.TotalPrice,
	)
	if err != nil {
		return fmt.Errorf("update st order pricing: %w", err)
	}
	
	return nil
}

func (r *Repository) CreateStOrderStateHistory(ctx context.Context, params CreateStOrderStateHistoryParams) error {
	query := `
		INSERT INTO st_order_state_history (st_order_id, from_state, to_state, changed_by, notes)
		VALUES ($1, $2, $3, $4, $5)
	`
	
	_, err := r.db.Exec(ctx, query,
		params.StOrderID,
		params.FromState,
		params.ToState,
		params.ChangedBy,
		params.Notes,
	)
	if err != nil {
		return fmt.Errorf("create st order state history: %w", err)
	}
	
	return nil
}

func (r *Repository) UpdateStOrderState(ctx context.Context, params UpdateStOrderStateParams) error {
	query := `UPDATE st_orders SET current_state_id = $2, updated_at = NOW() WHERE id = $1`
	
	_, err := r.db.Exec(ctx, query, params.ID, params.StateID)
	if err != nil {
		return fmt.Errorf("update st order state: %w", err)
	}
	
	return nil
}

func (r *Repository) GetNextStOrderNumber(ctx context.Context) (string, error) {
	// Simple implementation - در production از sequence استفاده کنید
	query := `
		SELECT COALESCE(MAX(CAST(SUBSTRING(order_number FROM '[0-9]+') AS INTEGER)), 0) + 1
		FROM st_orders
		WHERE order_number ~ '^ST[0-9]+$'
	`
	
	var nextNum int
	err := r.db.QueryRow(ctx, query).Scan(&nextNum)
	if err != nil {
		return "", fmt.Errorf("get next st order number: %w", err)
	}
	
	return fmt.Sprintf("ST%06d", nextNum), nil
}
