package repository

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5/pgxpool"
)

// ============================================================================
// REPOSITORY STRUCT
// ============================================================================

type Repository struct {
	db *pgxpool.Pool
}

// ============================================================================
// QUERIER INTERFACE - تمام متدها
// ============================================================================

type Querier interface {
	// ========== AUTH METHODS ==========
	CreateUser(ctx context.Context, params CreateUserParams) (*User, error)
	GetUserByUsername(ctx context.Context, username string) (*User, error)
	GetUserByMobileNumber(ctx context.Context, mobileNumber string) (*User, error)
	GetUserByID(ctx context.Context, id int64) (*User, error)
	UpdateUser(ctx context.Context, params UpdateUserParams) (*User, error)
	UpdateUserPassword(ctx context.Context, params UpdateUserPasswordParams) error
	UpdateUserFailedLoginAttempts(ctx context.Context, params UpdateUserFailedLoginAttemptsParams) error
	UpdateUserLastLogin(ctx context.Context, params UpdateUserLastLoginParams) error
	CheckUserPermission(ctx context.Context, params CheckUserPermissionParams) (bool, error)

	// Session methods
	CreateUserSession(ctx context.Context, params CreateUserSessionParams) (*UserSession, error)
	GetUserSession(ctx context.Context, sessionToken string) (*UserSession, error)
	UpdateUserSessionActivity(ctx context.Context, sessionToken string) error
	DeleteUserSession(ctx context.Context, sessionToken string) error
	DeleteUserSessions(ctx context.Context, userID int64) error

	// ========== ENTITY METHODS ==========
	CreateEntity(ctx context.Context, params CreateEntityParams) (*Entity, error)
	GetEntity(ctx context.Context, id int64) (*Entity, error)
	GetEntityByCode(ctx context.Context, code string) (*Entity, error)
	ListEntities(ctx context.Context, params ListEntitiesParams) ([]Entity, error)
	CountEntities(ctx context.Context, params CountEntitiesParams) (int64, error)
	UpdateEntity(ctx context.Context, params UpdateEntityParams) (*Entity, error)
	DeleteEntity(ctx context.Context, id int64) error
	AssignEntityRole(ctx context.Context, params AssignEntityRoleParams) error
	RemoveEntityRole(ctx context.Context, params RemoveEntityRoleParams) error
	GetEntityRoles(ctx context.Context, entityID int64) ([]EntityRole, error)
	CreateEntityPhone(ctx context.Context, params CreateEntityPhoneParams) (*EntityPhone, error)
	ListEntityPhones(ctx context.Context, entityID int64) ([]EntityPhone, error)
	DeleteEntityPhone(ctx context.Context, id int64) error
	CreateEntityAddress(ctx context.Context, params CreateEntityAddressParams) (*EntityAddress, error)
	ListEntityAddresses(ctx context.Context, entityID int64) ([]EntityAddress, error)
	DeleteEntityAddress(ctx context.Context, id int64) error
	GetEntitiesWithRole(ctx context.Context, params GetEntitiesWithRoleParams) ([]Entity, error)

	// ========== PRODUCT METHODS ==========
	CreateProduct(ctx context.Context, params CreateProductParams) (*Product, error)
	GetProduct(ctx context.Context, id int64) (*Product, error)
	GetProductByCode(ctx context.Context, code string) (*Product, error)
	ListProducts(ctx context.Context, params ListProductsParams) ([]Product, error)
	CountProducts(ctx context.Context, params CountProductsParams) (int64, error)
	UpdateProduct(ctx context.Context, params UpdateProductParams) (*Product, error)
	DeleteProduct(ctx context.Context, id int64) error
	FindRxProduct(ctx context.Context, params FindRxProductParams) (*Product, error)
	FindStProduct(ctx context.Context, params FindStProductParams) (*Product, error)
	FindSemiFinishedProduct(ctx context.Context, base float64, direction string) (*Product, error)

	// Lens Brand methods
	CreateLensBrand(ctx context.Context, code string, name string) (*LensBrand, error)
	GetLensBrand(ctx context.Context, id int64) (*LensBrand, error)
	ListLensBrands(ctx context.Context) ([]LensBrand, error)
	UpdateLensBrand(ctx context.Context, id int64, name string) (*LensBrand, error)
	DeleteLensBrand(ctx context.Context, id int64) error

	// ========== RX ORDER METHODS ==========
	CreateRxOrder(ctx context.Context, params CreateRxOrderParams) (*RxOrder, error)
	GetRxOrder(ctx context.Context, id int64) (*RxOrder, error)
	ListRxOrders(ctx context.Context, params ListRxOrdersParams) ([]RxOrder, error)
	CountRxOrders(ctx context.Context, params CountRxOrdersParams) (int64, error)
	UpdateRxOrder(ctx context.Context, params UpdateRxOrderParams) (*RxOrder, error)
	DeleteRxOrder(ctx context.Context, id int64) error
	AddRxOrderExtraService(ctx context.Context, params AddRxOrderExtraServiceParams) error
	ClearRxOrderExtraServices(ctx context.Context, rxOrderID int64) error
	CreateRxOrderStateHistory(ctx context.Context, params CreateRxOrderStateHistoryParams) error
	UpdateRxOrderState(ctx context.Context, params UpdateRxOrderStateParams) error
	GetNextRxOrderNumber(ctx context.Context) (string, error)

	// ========== ST ORDER METHODS ==========
	CreateStOrder(ctx context.Context, params CreateStOrderParams) (*StOrder, error)
	GetStOrder(ctx context.Context, id int64) (*StOrder, error)
	ListStOrders(ctx context.Context, params ListStOrdersParams) ([]StOrder, error)
	CountStOrders(ctx context.Context, params CountStOrdersParams) (int64, error)
	UpdateStOrder(ctx context.Context, params UpdateStOrderParams) (*StOrder, error)
	DeleteStOrder(ctx context.Context, id int64) error
	CreateStOrderPairItem(ctx context.Context, params CreateStOrderPairItemParams) error
	CreateStOrderSingleItem(ctx context.Context, params CreateStOrderSingleItemParams) error
	UpdateStOrderPricing(ctx context.Context, params UpdateStOrderPricingParams) error
	CreateStOrderStateHistory(ctx context.Context, params CreateStOrderStateHistoryParams) error
	UpdateStOrderState(ctx context.Context, params UpdateStOrderStateParams) error
	GetNextStOrderNumber(ctx context.Context) (string, error)

	// ========== STATE MANAGEMENT METHODS ==========
	GetStateByCode(ctx context.Context, stateCode string, orderType string) (*State, error)
	GetState(ctx context.Context, id int64) (*State, error)
	GetStateTransition(ctx context.Context, params GetStateTransitionParams) (*StateTransition, error)
	CheckTransitionPermission(ctx context.Context, params CheckTransitionPermissionParams) (bool, error)

	// ========== INVENTORY METHODS ==========
	GetInventoryBalance(ctx context.Context, productID int64, warehouseID int64, unitID int64) (*InventoryBalance, error)
	GetInventoryBalanceByProduct(ctx context.Context, productID int64) ([]InventoryBalance, error)
	ListInventoryBalances(ctx context.Context, warehouseID int64) ([]InventoryBalance, error)
	ListInventoryBalancesByProduct(ctx context.Context, productID int64) ([]InventoryBalance, error)
	UpdateInventoryReservation(ctx context.Context, productID int64, warehouseID int64, unitID int64, quantity float64) error
	ReleaseInventoryReservation(ctx context.Context, productID int64, warehouseID int64, unitID int64, quantity float64) error
	InsertInventoryTransaction(ctx context.Context, params CreateInventoryTransactionParams) (*InventoryTransaction, error)
	CreateInventoryTransaction(ctx context.Context, params CreateInventoryTransactionParams) (*InventoryTransaction, error)
	ListInventoryTransactions(ctx context.Context, params ListInventoryTransactionsParams) ([]InventoryTransaction, error)
	ListWarrantyClaims(ctx context.Context, params ListWarrantyClaimsParams) ([]WarrantyClaim, error)
	// ========== TRANSACTION SUPPORT ==========
	WithTx(ctx context.Context, fn func(*Repository) error) error
}

// Ensure Repository implements Querier
var _ Querier = (*Repository)(nil)

// ============================================================================
// CONSTRUCTOR
// ============================================================================

func New(db *pgxpool.Pool) *Repository {
	return &Repository{db: db}
}

// ============================================================================
// TRANSACTION SUPPORT
// ============================================================================

// WithTx executes a function within a transaction
func (r *Repository) WithTx(ctx context.Context, fn func(*Repository) error) error {
	tx, err := r.db.Begin(ctx)
	if err != nil {
		return fmt.Errorf("begin transaction: %w", err)
	}

	defer func() {
		if p := recover(); p != nil {
			_ = tx.Rollback(ctx)
			panic(p)
		}
	}()

	// Create a temporary repository that uses the transaction
	// Note: This is simplified - in production you'd wrap tx properly
	txRepo := &Repository{db: r.db}

	if err := fn(txRepo); err != nil {
		if rbErr := tx.Rollback(ctx); rbErr != nil {
			return fmt.Errorf("tx error: %v, rollback error: %v", err, rbErr)
		}
		return err
	}

	if err := tx.Commit(ctx); err != nil {
		return fmt.Errorf("commit transaction: %w", err)
	}

	return nil
}
