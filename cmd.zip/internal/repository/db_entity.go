package repository

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5"
)

// ============================================================================
// ENTITY METHODS - COMPLETE WITH SQL
// ============================================================================

func (r *Repository) CreateEntity(ctx context.Context, params CreateEntityParams) (*Entity, error) {
	query := `
		INSERT INTO entities (
			code, secondary_code, entity_type, company_name, legal_name,
			first_name, last_name, national_id, registration_number, email,
			is_active, created_by
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
		RETURNING 
			id, code, secondary_code, entity_type, company_name, legal_name,
			first_name, last_name, national_id, registration_number, email,
			is_active, created_by, created_at, updated_by, updated_at
	`
	
	var entity Entity
	err := r.db.QueryRow(ctx, query,
		params.Code,
		params.SecondaryCode,
		params.EntityType,
		params.CompanyName,
		params.LegalName,
		params.FirstName,
		params.LastName,
		params.NationalID,
		params.RegistrationNumber,
		params.Email,
		params.IsActive,
		params.CreatedBy,
	).Scan(
		&entity.ID,
		&entity.Code,
		&entity.SecondaryCode,
		&entity.EntityType,
		&entity.CompanyName,
		&entity.LegalName,
		&entity.FirstName,
		&entity.LastName,
		&entity.NationalID,
		&entity.RegistrationNumber,
		&entity.Email,
		&entity.IsActive,
		&entity.CreatedBy,
		&entity.CreatedAt,
		&entity.UpdatedBy,
		&entity.UpdatedAt,
	)
	
	if err != nil {
		return nil, fmt.Errorf("create entity: %w", err)
	}
	
	return &entity, nil
}

func (r *Repository) GetEntity(ctx context.Context, id int64) (*Entity, error) {
	query := `
		SELECT 
			id, code, secondary_code, entity_type, company_name, legal_name,
			first_name, last_name, national_id, registration_number, email,
			is_active, created_by, created_at, updated_by, updated_at
		FROM entities
		WHERE id = $1
	`
	
	var entity Entity
	err := r.db.QueryRow(ctx, query, id).Scan(
		&entity.ID,
		&entity.Code,
		&entity.SecondaryCode,
		&entity.EntityType,
		&entity.CompanyName,
		&entity.LegalName,
		&entity.FirstName,
		&entity.LastName,
		&entity.NationalID,
		&entity.RegistrationNumber,
		&entity.Email,
		&entity.IsActive,
		&entity.CreatedBy,
		&entity.CreatedAt,
		&entity.UpdatedBy,
		&entity.UpdatedAt,
	)
	
	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("entity not found")
	}
	if err != nil {
		return nil, fmt.Errorf("get entity: %w", err)
	}
	
	return &entity, nil
}

func (r *Repository) GetEntityByCode(ctx context.Context, code string) (*Entity, error) {
	query := `
		SELECT 
			id, code, secondary_code, entity_type, company_name, legal_name,
			first_name, last_name, national_id, registration_number, email,
			is_active, created_by, created_at, updated_by, updated_at
		FROM entities
		WHERE code = $1
	`
	
	var entity Entity
	err := r.db.QueryRow(ctx, query, code).Scan(
		&entity.ID,
		&entity.Code,
		&entity.SecondaryCode,
		&entity.EntityType,
		&entity.CompanyName,
		&entity.LegalName,
		&entity.FirstName,
		&entity.LastName,
		&entity.NationalID,
		&entity.RegistrationNumber,
		&entity.Email,
		&entity.IsActive,
		&entity.CreatedBy,
		&entity.CreatedAt,
		&entity.UpdatedBy,
		&entity.UpdatedAt,
	)
	
	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("entity not found")
	}
	if err != nil {
		return nil, fmt.Errorf("get entity by code: %w", err)
	}
	
	return &entity, nil
}

func (r *Repository) ListEntities(ctx context.Context, params ListEntitiesParams) ([]Entity, error) {
	query := `
		SELECT 
			id, code, secondary_code, entity_type, company_name, legal_name,
			first_name, last_name, national_id, registration_number, email,
			is_active, created_by, created_at, updated_by, updated_at
		FROM entities
		WHERE 
			($1::text IS NULL OR code ILIKE '%' || $1 || '%' OR company_name ILIKE '%' || $1 || '%')
			AND ($2::text IS NULL OR entity_type = $2)
			AND ($3::boolean IS NULL OR is_active = $3)
		ORDER BY created_at DESC
		LIMIT $4 OFFSET $5
	`
	
	rows, err := r.db.Query(ctx, query,
		params.Search,
		params.EntityType,
		params.IsActive,
		params.Limit,
		params.Offset,
	)
	if err != nil {
		return nil, fmt.Errorf("list entities: %w", err)
	}
	defer rows.Close()
	
	var entities []Entity
	for rows.Next() {
		var entity Entity
		if err := rows.Scan(
			&entity.ID,
			&entity.Code,
			&entity.SecondaryCode,
			&entity.EntityType,
			&entity.CompanyName,
			&entity.LegalName,
			&entity.FirstName,
			&entity.LastName,
			&entity.NationalID,
			&entity.RegistrationNumber,
			&entity.Email,
			&entity.IsActive,
			&entity.CreatedBy,
			&entity.CreatedAt,
			&entity.UpdatedBy,
			&entity.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan entity: %w", err)
		}
		entities = append(entities, entity)
	}
	
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate entities: %w", err)
	}
	
	return entities, nil
}

func (r *Repository) CountEntities(ctx context.Context, params CountEntitiesParams) (int64, error) {
	query := `
		SELECT COUNT(*)
		FROM entities
		WHERE 
			($1::text IS NULL OR code ILIKE '%' || $1 || '%' OR company_name ILIKE '%' || $1 || '%')
			AND ($2::text IS NULL OR entity_type = $2)
			AND ($3::boolean IS NULL OR is_active = $3)
	`
	
	var count int64
	err := r.db.QueryRow(ctx, query,
		params.Search,
		params.EntityType,
		params.IsActive,
	).Scan(&count)
	
	if err != nil {
		return 0, fmt.Errorf("count entities: %w", err)
	}
	
	return count, nil
}

func (r *Repository) UpdateEntity(ctx context.Context, params UpdateEntityParams) (*Entity, error) {
	query := `
		UPDATE entities
		SET 
			secondary_code = $2,
			company_name = $3,
			legal_name = $4,
			first_name = $5,
			last_name = $6,
			national_id = $7,
			registration_number = $8,
			email = $9,
			is_active = $10,
			updated_by = $11,
			updated_at = NOW()
		WHERE id = $1
		RETURNING 
			id, code, secondary_code, entity_type, company_name, legal_name,
			first_name, last_name, national_id, registration_number, email,
			is_active, created_by, created_at, updated_by, updated_at
	`
	
	var entity Entity
	err := r.db.QueryRow(ctx, query,
		params.ID,
		params.SecondaryCode,
		params.CompanyName,
		params.LegalName,
		params.FirstName,
		params.LastName,
		params.NationalID,
		params.RegistrationNumber,
		params.Email,
		params.IsActive,
		params.UpdatedBy,
	).Scan(
		&entity.ID,
		&entity.Code,
		&entity.SecondaryCode,
		&entity.EntityType,
		&entity.CompanyName,
		&entity.LegalName,
		&entity.FirstName,
		&entity.LastName,
		&entity.NationalID,
		&entity.RegistrationNumber,
		&entity.Email,
		&entity.IsActive,
		&entity.CreatedBy,
		&entity.CreatedAt,
		&entity.UpdatedBy,
		&entity.UpdatedAt,
	)
	
	if err != nil {
		return nil, fmt.Errorf("update entity: %w", err)
	}
	
	return &entity, nil
}

func (r *Repository) DeleteEntity(ctx context.Context, id int64) error {
	query := `DELETE FROM entities WHERE id = $1`
	
	result, err := r.db.Exec(ctx, query, id)
	if err != nil {
		return fmt.Errorf("delete entity: %w", err)
	}
	
	if result.RowsAffected() == 0 {
		return fmt.Errorf("entity not found")
	}
	
	return nil
}

// Entity Roles
func (r *Repository) AssignEntityRole(ctx context.Context, params AssignEntityRoleParams) error {
	query := `
		INSERT INTO entity_roles (entity_id, role_type)
		VALUES ($1, $2)
		ON CONFLICT (entity_id, role_type) DO NOTHING
	`
	
	_, err := r.db.Exec(ctx, query, params.EntityID, params.RoleType)
	if err != nil {
		return fmt.Errorf("assign entity role: %w", err)
	}
	
	return nil
}

func (r *Repository) RemoveEntityRole(ctx context.Context, params RemoveEntityRoleParams) error {
	query := `DELETE FROM entity_roles WHERE entity_id = $1 AND role_type = $2`
	
	_, err := r.db.Exec(ctx, query, params.EntityID, params.RoleType)
	if err != nil {
		return fmt.Errorf("remove entity role: %w", err)
	}
	
	return nil
}

func (r *Repository) GetEntityRoles(ctx context.Context, entityID int64) ([]EntityRole, error) {
	query := `
		SELECT id, entity_id, role_type, role_name, role_code, description, created_at
		FROM entity_roles
		WHERE entity_id = $1
		ORDER BY created_at
	`
	
	rows, err := r.db.Query(ctx, query, entityID)
	if err != nil {
		return nil, fmt.Errorf("get entity roles: %w", err)
	}
	defer rows.Close()
	
	var roles []EntityRole
	for rows.Next() {
		var role EntityRole
		if err := rows.Scan(
			&role.ID,
			&role.EntityID,
			&role.RoleType,
			&role.RoleName,
			&role.RoleCode,
			&role.Description,
			&role.CreatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan role: %w", err)
		}
		roles = append(roles, role)
	}
	
	return roles, rows.Err()
}

// Entity Phones
func (r *Repository) CreateEntityPhone(ctx context.Context, params CreateEntityPhoneParams) (*EntityPhone, error) {
	query := `
		INSERT INTO entity_phones (entity_id, phone_number, phone_type, is_primary)
		VALUES ($1, $2, $3, $4)
		RETURNING id, entity_id, phone_number, phone_type, is_primary, created_at
	`
	
	var phone EntityPhone
	err := r.db.QueryRow(ctx, query,
		params.EntityID,
		params.PhoneNumber,
		params.PhoneType,
		params.IsPrimary,
	).Scan(
		&phone.ID,
		&phone.EntityID,
		&phone.PhoneNumber,
		&phone.PhoneType,
		&phone.IsPrimary,
		&phone.CreatedAt,
	)
	
	if err != nil {
		return nil, fmt.Errorf("create entity phone: %w", err)
	}
	
	return &phone, nil
}

func (r *Repository) ListEntityPhones(ctx context.Context, entityID int64) ([]EntityPhone, error) {
	query := `
		SELECT id, entity_id, phone_number, phone_type, is_primary, created_at
		FROM entity_phones
		WHERE entity_id = $1
		ORDER BY is_primary DESC, created_at
	`
	
	rows, err := r.db.Query(ctx, query, entityID)
	if err != nil {
		return nil, fmt.Errorf("list entity phones: %w", err)
	}
	defer rows.Close()
	
	var phones []EntityPhone
	for rows.Next() {
		var phone EntityPhone
		if err := rows.Scan(
			&phone.ID,
			&phone.EntityID,
			&phone.PhoneNumber,
			&phone.PhoneType,
			&phone.IsPrimary,
			&phone.CreatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan phone: %w", err)
		}
		phones = append(phones, phone)
	}
	
	return phones, rows.Err()
}

func (r *Repository) DeleteEntityPhone(ctx context.Context, id int64) error {
	query := `DELETE FROM entity_phones WHERE id = $1`
	
	_, err := r.db.Exec(ctx, query, id)
	if err != nil {
		return fmt.Errorf("delete entity phone: %w", err)
	}
	
	return nil
}

// Entity Addresses
func (r *Repository) CreateEntityAddress(ctx context.Context, params CreateEntityAddressParams) (*EntityAddress, error) {
	query := `
		INSERT INTO entity_addresses (
			entity_id, address_type, address, city, province, postal_code, is_primary
		) VALUES ($1, $2, $3, $4, $5, $6, $7)
		RETURNING id, entity_id, address_type, address, address_line, city, province, country, postal_code, is_primary, created_at
	`
	
	var addr EntityAddress
	err := r.db.QueryRow(ctx, query,
		params.EntityID,
		params.AddressType,
		params.Address,
		params.City,
		params.Province,
		params.PostalCode,
		params.IsPrimary,
	).Scan(
		&addr.ID,
		&addr.EntityID,
		&addr.AddressType,
		&addr.Address,
		&addr.AddressLine,
		&addr.City,
		&addr.Province,
		&addr.Country,
		&addr.PostalCode,
		&addr.IsPrimary,
		&addr.CreatedAt,
	)
	
	if err != nil {
		return nil, fmt.Errorf("create entity address: %w", err)
	}
	
	return &addr, nil
}

func (r *Repository) ListEntityAddresses(ctx context.Context, entityID int64) ([]EntityAddress, error) {
	query := `
		SELECT id, entity_id, address_type, address, address_line, city, province, country, postal_code, is_primary, created_at
		FROM entity_addresses
		WHERE entity_id = $1
		ORDER BY is_primary DESC, created_at
	`
	
	rows, err := r.db.Query(ctx, query, entityID)
	if err != nil {
		return nil, fmt.Errorf("list entity addresses: %w", err)
	}
	defer rows.Close()
	
	var addresses []EntityAddress
	for rows.Next() {
		var addr EntityAddress
		if err := rows.Scan(
			&addr.ID,
			&addr.EntityID,
			&addr.AddressType,
			&addr.Address,
			&addr.AddressLine,
			&addr.City,
			&addr.Province,
			&addr.Country,
			&addr.PostalCode,
			&addr.IsPrimary,
			&addr.CreatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan address: %w", err)
		}
		addresses = append(addresses, addr)
	}
	
	return addresses, rows.Err()
}

func (r *Repository) DeleteEntityAddress(ctx context.Context, id int64) error {
	query := `DELETE FROM entity_addresses WHERE id = $1`
	
	_, err := r.db.Exec(ctx, query, id)
	if err != nil {
		return fmt.Errorf("delete entity address: %w", err)
	}
	
	return nil
}

func (r *Repository) GetEntitiesWithRole(ctx context.Context, params GetEntitiesWithRoleParams) ([]Entity, error) {
	query := `
		SELECT DISTINCT
			e.id, e.code, e.secondary_code, e.entity_type, e.company_name, e.legal_name,
			e.first_name, e.last_name, e.national_id, e.registration_number, e.email,
			e.is_active, e.created_by, e.created_at, e.updated_by, e.updated_at
		FROM entities e
		INNER JOIN entity_roles er ON e.id = er.entity_id
		WHERE ($1::text IS NULL OR er.role_type = $1)
			AND ($2::text IS NULL OR er.role_code = $2)
		ORDER BY e.created_at DESC
		LIMIT $3 OFFSET $4
	`
	
	rows, err := r.db.Query(ctx, query, 
		toNullString(&params.RoleType),
		toNullString(&params.RoleCode),
		params.Limit,
		params.Offset,
	)
	if err != nil {
		return nil, fmt.Errorf("get entities with role: %w", err)
	}
	defer rows.Close()
	
	var entities []Entity
	for rows.Next() {
		var entity Entity
		if err := rows.Scan(
			&entity.ID,
			&entity.Code,
			&entity.SecondaryCode,
			&entity.EntityType,
			&entity.CompanyName,
			&entity.LegalName,
			&entity.FirstName,
			&entity.LastName,
			&entity.NationalID,
			&entity.RegistrationNumber,
			&entity.Email,
			&entity.IsActive,
			&entity.CreatedBy,
			&entity.CreatedAt,
			&entity.UpdatedBy,
			&entity.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan entity: %w", err)
		}
		entities = append(entities, entity)
	}
	
	return entities, rows.Err()
}
