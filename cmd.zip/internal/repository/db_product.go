package repository

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5"
)

// ============================================================================
// PRODUCT METHODS - COMPLETE WITH SQL
// ============================================================================

func (r *Repository) CreateProduct(ctx context.Context, params CreateProductParams) (*Product, error) {
	query := `
		INSERT INTO products (
			code, secondary_code, financial_system_code, name, product_type,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id, lens_coating_id,
			lens_sph, lens_cyl, lens_base, direction, service_type,
			base_unit_id, is_active, created_by
		) VALUES (
			$1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12,
			$13, $14, $15, $16, $17, $18, $19, $20
		)
		RETURNING 
			id, code, secondary_code, financial_system_code, name, product_type,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id, lens_coating_id,
			lens_sph, lens_cyl, lens_base, direction, service_type,
			base_unit_id, is_active, created_by, created_at, updated_by, updated_at
	`
	
	var product Product
	err := r.db.QueryRow(ctx, query,
		params.Code,
		params.SecondaryCode,
		params.FinancialSystemCode,
		params.Name,
		params.ProductType,
		params.LensBrandID,
		params.LensTypeID,
		params.LensIndexID,
		params.LensMaterialID,
		params.LensColorID,
		params.LensDesignID,
		params.LensCoatingID,
		params.LensSPH,
		params.LensCYL,
		params.LensBase,
		params.Direction,
		params.ServiceType,
		params.BaseUnitID,
		params.IsActive,
		params.CreatedBy,
	).Scan(
		&product.ID,
		&product.Code,
		&product.SecondaryCode,
		&product.FinancialSystemCode,
		&product.Name,
		&product.ProductType,
		&product.LensBrandID,
		&product.LensTypeID,
		&product.LensIndexID,
		&product.LensMaterialID,
		&product.LensColorID,
		&product.LensDesignID,
		&product.LensCoatingID,
		&product.LensSPH,
		&product.LensCYL,
		&product.LensBase,
		&product.Direction,
		&product.ServiceType,
		&product.BaseUnitID,
		&product.IsActive,
		&product.CreatedBy,
		&product.CreatedAt,
		&product.UpdatedBy,
		&product.UpdatedAt,
	)
	
	if err != nil {
		return nil, fmt.Errorf("create product: %w", err)
	}
	
	return &product, nil
}

func (r *Repository) GetProduct(ctx context.Context, id int64) (*Product, error) {
	query := `
		SELECT 
			id, code, secondary_code, financial_system_code, name, product_type,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id, lens_coating_id,
			lens_sph, lens_cyl, lens_base, direction, service_type,
			base_unit_id, is_active, created_by, created_at, updated_by, updated_at
		FROM products
		WHERE id = $1
	`
	
	var product Product
	err := r.db.QueryRow(ctx, query, id).Scan(
		&product.ID,
		&product.Code,
		&product.SecondaryCode,
		&product.FinancialSystemCode,
		&product.Name,
		&product.ProductType,
		&product.LensBrandID,
		&product.LensTypeID,
		&product.LensIndexID,
		&product.LensMaterialID,
		&product.LensColorID,
		&product.LensDesignID,
		&product.LensCoatingID,
		&product.LensSPH,
		&product.LensCYL,
		&product.LensBase,
		&product.Direction,
		&product.ServiceType,
		&product.BaseUnitID,
		&product.IsActive,
		&product.CreatedBy,
		&product.CreatedAt,
		&product.UpdatedBy,
		&product.UpdatedAt,
	)
	
	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("product not found")
	}
	if err != nil {
		return nil, fmt.Errorf("get product: %w", err)
	}
	
	return &product, nil
}

func (r *Repository) GetProductByCode(ctx context.Context, code string) (*Product, error) {
	query := `
		SELECT 
			id, code, secondary_code, financial_system_code, name, product_type,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id, lens_coating_id,
			lens_sph, lens_cyl, lens_base, direction, service_type,
			base_unit_id, is_active, created_by, created_at, updated_by, updated_at
		FROM products
		WHERE code = $1
	`
	
	var product Product
	err := r.db.QueryRow(ctx, query, code).Scan(
		&product.ID,
		&product.Code,
		&product.SecondaryCode,
		&product.FinancialSystemCode,
		&product.Name,
		&product.ProductType,
		&product.LensBrandID,
		&product.LensTypeID,
		&product.LensIndexID,
		&product.LensMaterialID,
		&product.LensColorID,
		&product.LensDesignID,
		&product.LensCoatingID,
		&product.LensSPH,
		&product.LensCYL,
		&product.LensBase,
		&product.Direction,
		&product.ServiceType,
		&product.BaseUnitID,
		&product.IsActive,
		&product.CreatedBy,
		&product.CreatedAt,
		&product.UpdatedBy,
		&product.UpdatedAt,
	)
	
	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("product not found")
	}
	if err != nil {
		return nil, fmt.Errorf("get product by code: %w", err)
	}
	
	return &product, nil
}

func (r *Repository) ListProducts(ctx context.Context, params ListProductsParams) ([]Product, error) {
	query := `
		SELECT 
			id, code, secondary_code, financial_system_code, name, product_type,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id, lens_coating_id,
			lens_sph, lens_cyl, lens_base, direction, service_type,
			base_unit_id, is_active, created_by, created_at, updated_by, updated_at
		FROM products
		WHERE 
			($1::text IS NULL OR product_type = $1)
			AND ($2::bigint IS NULL OR lens_brand_id = $2)
			AND ($3::text IS NULL OR code ILIKE '%' || $3 || '%' OR name ILIKE '%' || $3 || '%')
		ORDER BY created_at DESC
		LIMIT $4 OFFSET $5
	`
	
	rows, err := r.db.Query(ctx, query,
		params.ProductType,
		params.LensBrandID,
		params.Search,
		params.Limit,
		params.Offset,
	)
	if err != nil {
		return nil, fmt.Errorf("list products: %w", err)
	}
	defer rows.Close()
	
	var products []Product
	for rows.Next() {
		var product Product
		if err := rows.Scan(
			&product.ID,
			&product.Code,
			&product.SecondaryCode,
			&product.FinancialSystemCode,
			&product.Name,
			&product.ProductType,
			&product.LensBrandID,
			&product.LensTypeID,
			&product.LensIndexID,
			&product.LensMaterialID,
			&product.LensColorID,
			&product.LensDesignID,
			&product.LensCoatingID,
			&product.LensSPH,
			&product.LensCYL,
			&product.LensBase,
			&product.Direction,
			&product.ServiceType,
			&product.BaseUnitID,
			&product.IsActive,
			&product.CreatedBy,
			&product.CreatedAt,
			&product.UpdatedBy,
			&product.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan product: %w", err)
		}
		products = append(products, product)
	}
	
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate products: %w", err)
	}
	
	return products, nil
}

func (r *Repository) CountProducts(ctx context.Context, params CountProductsParams) (int64, error) {
	query := `
		SELECT COUNT(*)
		FROM products
		WHERE ($1::text IS NULL OR product_type = $1)
	`
	
	var count int64
	err := r.db.QueryRow(ctx, query, params.ProductType).Scan(&count)
	if err != nil {
		return 0, fmt.Errorf("count products: %w", err)
	}
	
	return count, nil
}

func (r *Repository) UpdateProduct(ctx context.Context, params UpdateProductParams) (*Product, error) {
	query := `
		UPDATE products
		SET 
			secondary_code = $2,
			financial_system_code = $3,
			name = COALESCE($4, name),
			is_active = COALESCE($5, is_active),
			updated_by = $6,
			updated_at = NOW()
		WHERE id = $1
		RETURNING 
			id, code, secondary_code, financial_system_code, name, product_type,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id, lens_coating_id,
			lens_sph, lens_cyl, lens_base, direction, service_type,
			base_unit_id, is_active, created_by, created_at, updated_by, updated_at
	`
	
	var product Product
	err := r.db.QueryRow(ctx, query,
		params.ID,
		params.SecondaryCode,
		params.FinancialSystemCode,
		params.Name,
		params.IsActive,
		params.UpdatedBy,
	).Scan(
		&product.ID,
		&product.Code,
		&product.SecondaryCode,
		&product.FinancialSystemCode,
		&product.Name,
		&product.ProductType,
		&product.LensBrandID,
		&product.LensTypeID,
		&product.LensIndexID,
		&product.LensMaterialID,
		&product.LensColorID,
		&product.LensDesignID,
		&product.LensCoatingID,
		&product.LensSPH,
		&product.LensCYL,
		&product.LensBase,
		&product.Direction,
		&product.ServiceType,
		&product.BaseUnitID,
		&product.IsActive,
		&product.CreatedBy,
		&product.CreatedAt,
		&product.UpdatedBy,
		&product.UpdatedAt,
	)
	
	if err != nil {
		return nil, fmt.Errorf("update product: %w", err)
	}
	
	return &product, nil
}

func (r *Repository) DeleteProduct(ctx context.Context, id int64) error {
	query := `DELETE FROM products WHERE id = $1`
	
	result, err := r.db.Exec(ctx, query, id)
	if err != nil {
		return fmt.Errorf("delete product: %w", err)
	}
	
	if result.RowsAffected() == 0 {
		return fmt.Errorf("product not found")
	}
	
	return nil
}

func (r *Repository) FindRxProduct(ctx context.Context, params FindRxProductParams) (*Product, error) {
	query := `
		SELECT 
			id, code, secondary_code, financial_system_code, name, product_type,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id, lens_coating_id,
			lens_sph, lens_cyl, lens_base, direction, service_type,
			base_unit_id, is_active, created_by, created_at, updated_by, updated_at
		FROM products
		WHERE product_type = 'rx_lens'
			AND ($1::bigint IS NULL OR lens_brand_id = $1)
			AND ($2::bigint IS NULL OR lens_type_id = $2)
			AND ($3::bigint IS NULL OR lens_index_id = $3)
			AND ($4::bigint IS NULL OR lens_material_id = $4)
			AND ($5::bigint IS NULL OR lens_color_id = $5)
			AND ($6::bigint IS NULL OR lens_design_id = $6)
			AND is_active = true
		LIMIT 1
	`
	
	var product Product
	err := r.db.QueryRow(ctx, query,
		params.LensBrandID,
		params.LensTypeID,
		params.LensIndexID,
		params.LensMaterialID,
		params.LensColorID,
		params.LensDesignID,
	).Scan(
		&product.ID,
		&product.Code,
		&product.SecondaryCode,
		&product.FinancialSystemCode,
		&product.Name,
		&product.ProductType,
		&product.LensBrandID,
		&product.LensTypeID,
		&product.LensIndexID,
		&product.LensMaterialID,
		&product.LensColorID,
		&product.LensDesignID,
		&product.LensCoatingID,
		&product.LensSPH,
		&product.LensCYL,
		&product.LensBase,
		&product.Direction,
		&product.ServiceType,
		&product.BaseUnitID,
		&product.IsActive,
		&product.CreatedBy,
		&product.CreatedAt,
		&product.UpdatedBy,
		&product.UpdatedAt,
	)
	
	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("rx product not found")
	}
	if err != nil {
		return nil, fmt.Errorf("find rx product: %w", err)
	}
	
	return &product, nil
}

func (r *Repository) FindStProduct(ctx context.Context, params FindStProductParams) (*Product, error) {
	query := `
		SELECT 
			id, code, secondary_code, financial_system_code, name, product_type,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id, lens_coating_id,
			lens_sph, lens_cyl, lens_base, direction, service_type,
			base_unit_id, is_active, created_by, created_at, updated_by, updated_at
		FROM products
		WHERE product_type = 'st_lens'
			AND ($1::bigint IS NULL OR lens_brand_id = $1)
			AND ($2::bigint IS NULL OR lens_index_id = $2)
			AND ($3::bigint IS NULL OR lens_coating_id = $3)
			AND is_active = true
		LIMIT 1
	`
	
	var product Product
	err := r.db.QueryRow(ctx, query,
		params.LensBrandID,
		params.LensIndexID,
		params.LensCoatingID,
	).Scan(
		&product.ID,
		&product.Code,
		&product.SecondaryCode,
		&product.FinancialSystemCode,
		&product.Name,
		&product.ProductType,
		&product.LensBrandID,
		&product.LensTypeID,
		&product.LensIndexID,
		&product.LensMaterialID,
		&product.LensColorID,
		&product.LensDesignID,
		&product.LensCoatingID,
		&product.LensSPH,
		&product.LensCYL,
		&product.LensBase,
		&product.Direction,
		&product.ServiceType,
		&product.BaseUnitID,
		&product.IsActive,
		&product.CreatedBy,
		&product.CreatedAt,
		&product.UpdatedBy,
		&product.UpdatedAt,
	)
	
	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("st product not found")
	}
	if err != nil {
		return nil, fmt.Errorf("find st product: %w", err)
	}
	
	return &product, nil
}

func (r *Repository) FindSemiFinishedProduct(ctx context.Context, base float64, direction string) (*Product, error) {
	query := `
		SELECT 
			id, code, secondary_code, financial_system_code, name, product_type,
			lens_brand_id, lens_type_id, lens_index_id, lens_material_id,
			lens_color_id, lens_design_id, lens_coating_id,
			lens_sph, lens_cyl, lens_base, direction, service_type,
			base_unit_id, is_active, created_by, created_at, updated_by, updated_at
		FROM products
		WHERE product_type = 'semi_finished'
			AND lens_base = $1
			AND direction = $2
			AND is_active = true
		LIMIT 1
	`
	
	var product Product
	err := r.db.QueryRow(ctx, query, base, direction).Scan(
		&product.ID,
		&product.Code,
		&product.SecondaryCode,
		&product.FinancialSystemCode,
		&product.Name,
		&product.ProductType,
		&product.LensBrandID,
		&product.LensTypeID,
		&product.LensIndexID,
		&product.LensMaterialID,
		&product.LensColorID,
		&product.LensDesignID,
		&product.LensCoatingID,
		&product.LensSPH,
		&product.LensCYL,
		&product.LensBase,
		&product.Direction,
		&product.ServiceType,
		&product.BaseUnitID,
		&product.IsActive,
		&product.CreatedBy,
		&product.CreatedAt,
		&product.UpdatedBy,
		&product.UpdatedAt,
	)
	
	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("semi-finished product not found")
	}
	if err != nil {
		return nil, fmt.Errorf("find semi-finished product: %w", err)
	}
	
	return &product, nil
}

// Lens Brand methods
func (r *Repository) CreateLensBrand(ctx context.Context, code string, name string) (*LensBrand, error) {
	query := `
		INSERT INTO lens_brands (code, name, is_active)
		VALUES ($1, $2, true)
		RETURNING id, code, name, is_active, created_at, updated_at
	`
	
	var brand LensBrand
	err := r.db.QueryRow(ctx, query, code, name).Scan(
		&brand.ID,
		&brand.Code,
		&brand.Name,
		&brand.IsActive,
		&brand.CreatedAt,
		&brand.UpdatedAt,
	)
	
	if err != nil {
		return nil, fmt.Errorf("create lens brand: %w", err)
	}
	
	return &brand, nil
}

func (r *Repository) GetLensBrand(ctx context.Context, id int64) (*LensBrand, error) {
	query := `
		SELECT id, code, name, is_active, created_at, updated_at
		FROM lens_brands
		WHERE id = $1
	`
	
	var brand LensBrand
	err := r.db.QueryRow(ctx, query, id).Scan(
		&brand.ID,
		&brand.Code,
		&brand.Name,
		&brand.IsActive,
		&brand.CreatedAt,
		&brand.UpdatedAt,
	)
	
	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("lens brand not found")
	}
	if err != nil {
		return nil, fmt.Errorf("get lens brand: %w", err)
	}
	
	return &brand, nil
}

func (r *Repository) ListLensBrands(ctx context.Context) ([]LensBrand, error) {
	query := `
		SELECT id, code, name, is_active, created_at, updated_at
		FROM lens_brands
		ORDER BY name
	`
	
	rows, err := r.db.Query(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("list lens brands: %w", err)
	}
	defer rows.Close()
	
	var brands []LensBrand
	for rows.Next() {
		var brand LensBrand
		if err := rows.Scan(
			&brand.ID,
			&brand.Code,
			&brand.Name,
			&brand.IsActive,
			&brand.CreatedAt,
			&brand.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("scan lens brand: %w", err)
		}
		brands = append(brands, brand)
	}
	
	return brands, rows.Err()
}

func (r *Repository) UpdateLensBrand(ctx context.Context, id int64, name string) (*LensBrand, error) {
	query := `
		UPDATE lens_brands
		SET name = $2, updated_at = NOW()
		WHERE id = $1
		RETURNING id, code, name, is_active, created_at, updated_at
	`
	
	var brand LensBrand
	err := r.db.QueryRow(ctx, query, id, name).Scan(
		&brand.ID,
		&brand.Code,
		&brand.Name,
		&brand.IsActive,
		&brand.CreatedAt,
		&brand.UpdatedAt,
	)
	
	if err != nil {
		return nil, fmt.Errorf("update lens brand: %w", err)
	}
	
	return &brand, nil
}

func (r *Repository) DeleteLensBrand(ctx context.Context, id int64) error {
	query := `DELETE FROM lens_brands WHERE id = $1`
	
	result, err := r.db.Exec(ctx, query, id)
	if err != nil {
		return fmt.Errorf("delete lens brand: %w", err)
	}
	
	if result.RowsAffected() == 0 {
		return fmt.Errorf("lens brand not found")
	}
	
	return nil
}
