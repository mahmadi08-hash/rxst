package repository

import (
	"context"
	"fmt"

	"github.com/jackc/pgx/v5"
)

// ============================================================================
// AUTH IMPLEMENTATIONS - COMPLETE WITH SQL
// ============================================================================

func (r *Repository) CreateUser(ctx context.Context, params CreateUserParams) (*User, error) {
	query := `
		INSERT INTO users (
			username, email, password_hash, entity_id, first_name, last_name, 
			mobile_number, is_active, is_approved, is_system_admin
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
		RETURNING 
			id, username, email, password_hash, entity_id, first_name, last_name,
			mobile_number, is_active, is_approved, is_admin, is_system_admin,
			failed_login_attempts, account_locked_until, last_login, 
			created_at, updated_at
	`

	var user User
	err := r.db.QueryRow(ctx, query,
		params.Username,
		params.Email,
		params.PasswordHash,
		params.EntityID,
		params.FirstName,
		params.LastName,
		params.MobileNumber,
		params.IsActive,
		params.IsApproved,
		params.IsSystemAdmin,
	).Scan(
		&user.ID,
		&user.Username,
		&user.Email,
		&user.PasswordHash,
		&user.EntityID,
		&user.FirstName,
		&user.LastName,
		&user.MobileNumber,
		&user.IsActive,
		&user.IsApproved,
		&user.IsAdmin,
		&user.IsSystemAdmin,
		&user.FailedLoginAttempts,
		&user.LockedUntil,
		&user.LastLogin,
		&user.CreatedAt,
		&user.UpdatedAt,
	)

	if err != nil {
		return nil, fmt.Errorf("create user: %w", err)
	}

	return &user, nil
}

func (r *Repository) GetUserByUsername(ctx context.Context, username string) (*User, error) {
	query := `
		SELECT 
			id, username, email, password_hash, entity_id, first_name, last_name,
			mobile_number, is_active, is_approved, is_admin, is_system_admin,
			failed_login_attempts, account_locked_until, last_login,
			created_at, updated_at
		FROM users
		WHERE username = $1
	`

	var user User
	err := r.db.QueryRow(ctx, query, username).Scan(
		&user.ID,
		&user.Username,
		&user.Email,
		&user.PasswordHash,
		&user.EntityID,
		&user.FirstName,
		&user.LastName,
		&user.MobileNumber,
		&user.IsActive,
		&user.IsApproved,
		&user.IsAdmin,
		&user.IsSystemAdmin,
		&user.FailedLoginAttempts,
		&user.LockedUntil,
		&user.LastLogin,
		&user.CreatedAt,
		&user.UpdatedAt,
	)

	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("user not found")
	}
	if err != nil {
		return nil, fmt.Errorf("get user by username: %w", err)
	}

	return &user, nil
}

func (r *Repository) GetUserByMobileNumber(ctx context.Context, mobileNumber string) (*User, error) {
	query := `
		SELECT 
			id, username, email, password_hash, entity_id, first_name, last_name,
			mobile_number, is_active, is_approved, is_admin, is_system_admin,
			failed_login_attempts, account_locked_until, last_login,
			created_at, updated_at
		FROM users
		WHERE mobile_number = $1
	`

	var user User
	err := r.db.QueryRow(ctx, query, mobileNumber).Scan(
		&user.ID,
		&user.Username,
		&user.Email,
		&user.PasswordHash,
		&user.EntityID,
		&user.FirstName,
		&user.LastName,
		&user.MobileNumber,
		&user.IsActive,
		&user.IsApproved,
		&user.IsAdmin,
		&user.IsSystemAdmin,
		&user.FailedLoginAttempts,
		&user.LockedUntil,
		&user.LastLogin,
		&user.CreatedAt,
		&user.UpdatedAt,
	)

	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("user not found")
	}
	if err != nil {
		return nil, fmt.Errorf("get user by mobile: %w", err)
	}

	return &user, nil
}

func (r *Repository) GetUserByID(ctx context.Context, id int64) (*User, error) {
	query := `
		SELECT 
			id, username, email, password_hash, entity_id, first_name, last_name,
			mobile_number, is_active, is_approved, is_admin, is_system_admin,
			failed_login_attempts, account_locked_until, last_login,
			created_at, updated_at
		FROM users
		WHERE id = $1
	`

	var user User
	err := r.db.QueryRow(ctx, query, id).Scan(
		&user.ID,
		&user.Username,
		&user.Email,
		&user.PasswordHash,
		&user.EntityID,
		&user.FirstName,
		&user.LastName,
		&user.MobileNumber,
		&user.IsActive,
		&user.IsApproved,
		&user.IsAdmin,
		&user.IsSystemAdmin,
		&user.FailedLoginAttempts,
		&user.LockedUntil,
		&user.LastLogin,
		&user.CreatedAt,
		&user.UpdatedAt,
	)

	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("user not found")
	}
	if err != nil {
		return nil, fmt.Errorf("get user by id: %w", err)
	}

	return &user, nil
}

func (r *Repository) UpdateUser(ctx context.Context, params UpdateUserParams) (*User, error) {
	query := `
		UPDATE users
		SET 
			email = $2,
			first_name = $3,
			last_name = $4,
			mobile_number = $5,
			is_active = $6,
			is_approved = $7,
			updated_at = NOW()
		WHERE id = $1
		RETURNING 
			id, username, email, password_hash, entity_id, first_name, last_name,
			mobile_number, is_active, is_approved, is_admin, is_system_admin,
			failed_login_attempts, account_locked_until, last_login,
			created_at, updated_at
	`

	var user User
	err := r.db.QueryRow(ctx, query,
		params.ID,
		params.Email,
		params.FirstName,
		params.LastName,
		params.MobileNumber,
		params.IsActive,
		params.IsApproved,
	).Scan(
		&user.ID,
		&user.Username,
		&user.Email,
		&user.PasswordHash,
		&user.EntityID,
		&user.FirstName,
		&user.LastName,
		&user.MobileNumber,
		&user.IsActive,
		&user.IsApproved,
		&user.IsAdmin,
		&user.IsSystemAdmin,
		&user.FailedLoginAttempts,
		&user.LockedUntil,
		&user.LastLogin,
		&user.CreatedAt,
		&user.UpdatedAt,
	)

	if err != nil {
		return nil, fmt.Errorf("update user: %w", err)
	}

	return &user, nil
}

func (r *Repository) UpdateUserPassword(ctx context.Context, params UpdateUserPasswordParams) error {
	query := `
		UPDATE users
		SET password_hash = $2, updated_at = NOW()
		WHERE id = $1
	`

	_, err := r.db.Exec(ctx, query, params.ID, params.NewPasswordHash)
	if err != nil {
		return fmt.Errorf("update user password: %w", err)
	}

	return nil
}

func (r *Repository) UpdateUserFailedLoginAttempts(ctx context.Context, params UpdateUserFailedLoginAttemptsParams) error {
	query := `
		UPDATE users
		SET 
			failed_login_attempts = $2,
			account_locked_until = $3
		WHERE id = $1
	`

	_, err := r.db.Exec(ctx, query, params.ID, params.FailedLoginAttempts, params.LockedUntil)
	if err != nil {
		return fmt.Errorf("update failed login attempts: %w", err)
	}

	return nil
}

func (r *Repository) UpdateUserLastLogin(ctx context.Context, params UpdateUserLastLoginParams) error {
	query := `
		UPDATE users
		SET last_login = $2
		WHERE id = $1
	`

	_, err := r.db.Exec(ctx, query, params.ID, params.LastLogin)
	if err != nil {
		return fmt.Errorf("update last login: %w", err)
	}

	return nil
}

func (r *Repository) CheckUserPermission(ctx context.Context, params CheckUserPermissionParams) (bool, error) {
	query := `SELECT is_system_admin FROM users WHERE id = $1`

	var isSystemAdmin bool
	err := r.db.QueryRow(ctx, query, params.UserID).Scan(&isSystemAdmin)
	if err != nil {
		return false, fmt.Errorf("check permission: %w", err)
	}

	return isSystemAdmin, nil
}

// Session methods
func (r *Repository) CreateUserSession(ctx context.Context, params CreateUserSessionParams) (*UserSession, error) {
	query := `
		INSERT INTO user_sessions (user_id, session_token, ip_address, user_agent, expires_at)
		VALUES ($1, $2, $3, $4, $5)
		RETURNING id, user_id, session_token, ip_address, user_agent, expires_at, last_activity, created_at
	`

	var session UserSession
	err := r.db.QueryRow(ctx, query,
		params.UserID,
		params.SessionToken,
		params.IpAddress,
		params.UserAgent,
		params.ExpiresAt,
	).Scan(
		&session.ID,
		&session.UserID,
		&session.SessionToken,
		&session.IpAddress,
		&session.UserAgent,
		&session.ExpiresAt,
		&session.LastActivity,
		&session.CreatedAt,
	)

	if err != nil {
		return nil, fmt.Errorf("create session: %w", err)
	}

	return &session, nil
}

func (r *Repository) GetUserSession(ctx context.Context, sessionToken string) (*UserSession, error) {
	query := `
		SELECT id, user_id, session_token, ip_address, user_agent, expires_at, last_activity, created_at
		FROM user_sessions
		WHERE session_token = $1 AND expires_at > NOW()
	`

	var session UserSession
	err := r.db.QueryRow(ctx, query, sessionToken).Scan(
		&session.ID,
		&session.UserID,
		&session.SessionToken,
		&session.IpAddress,
		&session.UserAgent,
		&session.ExpiresAt,
		&session.LastActivity,
		&session.CreatedAt,
	)

	if err == pgx.ErrNoRows {
		return nil, fmt.Errorf("session not found or expired")
	}
	if err != nil {
		return nil, fmt.Errorf("get session: %w", err)
	}

	return &session, nil
}

func (r *Repository) UpdateUserSessionActivity(ctx context.Context, sessionToken string) error {
	query := `UPDATE user_sessions SET last_activity = NOW() WHERE session_token = $1`

	_, err := r.db.Exec(ctx, query, sessionToken)
	if err != nil {
		return fmt.Errorf("update session activity: %w", err)
	}

	return nil
}

func (r *Repository) DeleteUserSession(ctx context.Context, sessionToken string) error {
	query := `DELETE FROM user_sessions WHERE session_token = $1`

	_, err := r.db.Exec(ctx, query, sessionToken)
	if err != nil {
		return fmt.Errorf("delete session: %w", err)
	}

	return nil
}

func (r *Repository) DeleteUserSessions(ctx context.Context, userID int64) error {
	query := `DELETE FROM user_sessions WHERE user_id = $1`

	_, err := r.db.Exec(ctx, query, userID)
	if err != nil {
		return fmt.Errorf("delete user sessions: %w", err)
	}

	return nil
}
