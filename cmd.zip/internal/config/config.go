package config

import (
	"time"

	"github.com/spf13/viper"
)

type Config struct {
	App          AppConfig
	Database     DatabaseConfig
	Redis        RedisConfig
	JWT          JWTConfig
	Cache        CacheConfig
	RateLimit    RateLimitConfig
	CORS         CORSConfig
	Logging      LoggingConfig
	Jobs         JobsConfig
	ExternalAPIs ExternalAPIsConfig
	Upload       UploadConfig
	Print        PrintConfig
}

type AppConfig struct {
	Name    string
	Version string
	Env     string
	Port    int
}

type DatabaseConfig struct {
	Host     string
	Port     int
	User     string
	Password string
	DBName   string
	SSLMode  string
	Pool     DatabasePoolConfig
}

type DatabasePoolConfig struct {
	MaxConns        int32
	MinConns        int32
	MaxConnLifetime time.Duration
	MaxConnIdleTime time.Duration
}

type RedisConfig struct {
	Host     string
	Port     int
	Password string
	DB       int
	PoolSize int
}

type JWTConfig struct {
	Secret             string
	AccessTokenExpiry  time.Duration
	RefreshTokenExpiry time.Duration
}

type CacheConfig struct {
	InventoryTTL  time.Duration
	PricingTTL    time.Duration
	LookupTTL     time.Duration
	LocalCacheTTL time.Duration
}

type RateLimitConfig struct {
	RequestsPerMinute int
	RequestsPerDay    int
}

type CORSConfig struct {
	AllowedOrigins   []string
	AllowedMethods   []string
	AllowedHeaders   []string
	ExposeHeaders    []string
	AllowCredentials bool
	MaxAge           int
}

type LoggingConfig struct {
	Level            string
	Encoding         string
	OutputPaths      []string
	ErrorOutputPaths []string
}

type JobsConfig struct {
	InvoiceGenerationTime           string
	MaterializedViewRefreshInterval time.Duration
	SessionCleanupInterval          time.Duration
	PrintQueuePollInterval          time.Duration
}

type ExternalAPIsConfig struct {
	FinancialSystem ExternalAPIConfig
	SMSProvider     ExternalAPIConfig
	Telegram        TelegramConfig
}

type ExternalAPIConfig struct {
	URL     string
	APIKey  string
	Timeout time.Duration
}

type TelegramConfig struct {
	BotToken string
}

type UploadConfig struct {
	MaxFileSize        int64
	AllowedExtensions  []string
	UploadDir          string
}

type PrintConfig struct {
	SSRSUrl        string
	DefaultPrinter string
}

var cfg *Config

// Load loads configuration from file
func Load(configPath string) (*Config, error) {
	viper.SetConfigFile(configPath)
	viper.AutomaticEnv()

	if err := viper.ReadInConfig(); err != nil {
		return nil, err
	}

	cfg = &Config{}

	// App Config
	cfg.App.Name = viper.GetString("app.name")
	cfg.App.Version = viper.GetString("app.version")
	cfg.App.Env = viper.GetString("app.env")
	cfg.App.Port = viper.GetInt("app.port")

	// Database Config
	cfg.Database.Host = viper.GetString("database.host")
	cfg.Database.Port = viper.GetInt("database.port")
	cfg.Database.User = viper.GetString("database.user")
	cfg.Database.Password = viper.GetString("database.password")
	cfg.Database.DBName = viper.GetString("database.dbname")
	cfg.Database.SSLMode = viper.GetString("database.sslmode")
	cfg.Database.Pool.MaxConns = int32(viper.GetInt("database.pool.max_conns"))
	cfg.Database.Pool.MinConns = int32(viper.GetInt("database.pool.min_conns"))
	cfg.Database.Pool.MaxConnLifetime = viper.GetDuration("database.pool.max_conn_lifetime")
	cfg.Database.Pool.MaxConnIdleTime = viper.GetDuration("database.pool.max_conn_idle_time")

	// Redis Config
	cfg.Redis.Host = viper.GetString("redis.host")
	cfg.Redis.Port = viper.GetInt("redis.port")
	cfg.Redis.Password = viper.GetString("redis.password")
	cfg.Redis.DB = viper.GetInt("redis.db")
	cfg.Redis.PoolSize = viper.GetInt("redis.pool_size")

	// JWT Config
	cfg.JWT.Secret = viper.GetString("jwt.secret")
	cfg.JWT.AccessTokenExpiry = viper.GetDuration("jwt.access_token_expiry")
	cfg.JWT.RefreshTokenExpiry = viper.GetDuration("jwt.refresh_token_expiry")

	// Cache Config
	cfg.Cache.InventoryTTL = viper.GetDuration("cache.inventory_ttl")
	cfg.Cache.PricingTTL = viper.GetDuration("cache.pricing_ttl")
	cfg.Cache.LookupTTL = viper.GetDuration("cache.lookup_ttl")
	cfg.Cache.LocalCacheTTL = viper.GetDuration("cache.local_cache_ttl")

	// Rate Limit Config
	cfg.RateLimit.RequestsPerMinute = viper.GetInt("rate_limit.requests_per_minute")
	cfg.RateLimit.RequestsPerDay = viper.GetInt("rate_limit.requests_per_day")

	// CORS Config
	cfg.CORS.AllowedOrigins = viper.GetStringSlice("cors.allowed_origins")
	cfg.CORS.AllowedMethods = viper.GetStringSlice("cors.allowed_methods")
	cfg.CORS.AllowedHeaders = viper.GetStringSlice("cors.allowed_headers")
	cfg.CORS.ExposeHeaders = viper.GetStringSlice("cors.expose_headers")
	cfg.CORS.AllowCredentials = viper.GetBool("cors.allow_credentials")
	cfg.CORS.MaxAge = viper.GetInt("cors.max_age")

	// Logging Config
	cfg.Logging.Level = viper.GetString("logging.level")
	cfg.Logging.Encoding = viper.GetString("logging.encoding")
	cfg.Logging.OutputPaths = viper.GetStringSlice("logging.output_paths")
	cfg.Logging.ErrorOutputPaths = viper.GetStringSlice("logging.error_output_paths")

	// Jobs Config
	cfg.Jobs.InvoiceGenerationTime = viper.GetString("jobs.invoice_generation_time")
	cfg.Jobs.MaterializedViewRefreshInterval = viper.GetDuration("jobs.materialized_view_refresh_interval")
	cfg.Jobs.SessionCleanupInterval = viper.GetDuration("jobs.session_cleanup_interval")
	cfg.Jobs.PrintQueuePollInterval = viper.GetDuration("jobs.print_queue_poll_interval")

	// External APIs Config
	cfg.ExternalAPIs.FinancialSystem.URL = viper.GetString("external_apis.financial_system.url")
	cfg.ExternalAPIs.FinancialSystem.APIKey = viper.GetString("external_apis.financial_system.api_key")
	cfg.ExternalAPIs.FinancialSystem.Timeout = viper.GetDuration("external_apis.financial_system.timeout")

	cfg.ExternalAPIs.SMSProvider.URL = viper.GetString("external_apis.sms_provider.url")
	cfg.ExternalAPIs.SMSProvider.APIKey = viper.GetString("external_apis.sms_provider.api_key")
	cfg.ExternalAPIs.SMSProvider.Timeout = viper.GetDuration("external_apis.sms_provider.timeout")

	cfg.ExternalAPIs.Telegram.BotToken = viper.GetString("external_apis.telegram.bot_token")

	// Upload Config
	cfg.Upload.MaxFileSize = viper.GetInt64("upload.max_file_size")
	cfg.Upload.AllowedExtensions = viper.GetStringSlice("upload.allowed_extensions")
	cfg.Upload.UploadDir = viper.GetString("upload.upload_dir")

	// Print Config
	cfg.Print.SSRSUrl = viper.GetString("print.ssrs_url")
	cfg.Print.DefaultPrinter = viper.GetString("print.default_printer")

	return cfg, nil
}

// Get returns the loaded configuration
func Get() *Config {
	return cfg
}
