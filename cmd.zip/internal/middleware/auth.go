package middleware

import (
	"strings"

	"rx-st-system/internal/dto"
	"rx-st-system/pkg/errors"

	"github.com/gofiber/fiber/v2"
	"github.com/golang-jwt/jwt/v5"
)

// AuthMiddleware creates a JWT authentication middleware
func AuthMiddleware(jwtSecret string) fiber.Handler {
	return func(c *fiber.Ctx) error {
		// Get token from header
		authHeader := c.Get("Authorization")
		if authHeader == "" {
			return c.Status(fiber.StatusUnauthorized).JSON(dto.ErrorResponse{
				Success: false,
				Error:   "Missing authorization header",
				Code:    errors.ErrCodeUnauthorized,
			})
		}

		// Extract token
		parts := strings.Split(authHeader, " ")
		if len(parts) != 2 || parts[0] != "Bearer" {
			return c.Status(fiber.StatusUnauthorized).JSON(dto.ErrorResponse{
				Success: false,
				Error:   "Invalid authorization format",
				Code:    errors.ErrCodeUnauthorized,
			})
		}

		tokenString := parts[1]

		// Parse and validate token
		token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
			// Validate signing method
			if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, errors.NewUnauthorizedError("Invalid signing method")
			}
			return []byte(jwtSecret), nil
		})

		if err != nil {
			return c.Status(fiber.StatusUnauthorized).JSON(dto.ErrorResponse{
				Success: false,
				Error:   "Invalid token",
				Code:    errors.ErrCodeInvalidToken,
			})
		}

		if !token.Valid {
			return c.Status(fiber.StatusUnauthorized).JSON(dto.ErrorResponse{
				Success: false,
				Error:   "Invalid token",
				Code:    errors.ErrCodeInvalidToken,
			})
		}

		// Extract claims
		claims, ok := token.Claims.(jwt.MapClaims)
		if !ok {
			return c.Status(fiber.StatusUnauthorized).JSON(dto.ErrorResponse{
				Success: false,
				Error:   "Invalid token claims",
				Code:    errors.ErrCodeInvalidToken,
			})
		}

		// Set user info in context
		userID, ok := claims["user_id"].(float64)
		if !ok {
			return c.Status(fiber.StatusUnauthorized).JSON(dto.ErrorResponse{
				Success: false,
				Error:   "Invalid user ID in token",
				Code:    errors.ErrCodeInvalidToken,
			})
		}

		c.Locals("user_id", int64(userID))
		c.Locals("username", claims["username"])
		c.Locals("is_admin", claims["is_admin"])

		return c.Next()
	}
}

// OptionalAuthMiddleware creates an optional JWT authentication middleware
// It will set user context if token is valid, but won't block if token is missing
func OptionalAuthMiddleware(jwtSecret string) fiber.Handler {
	return func(c *fiber.Ctx) error {
		authHeader := c.Get("Authorization")
		if authHeader == "" {
			return c.Next()
		}

		parts := strings.Split(authHeader, " ")
		if len(parts) != 2 || parts[0] != "Bearer" {
			return c.Next()
		}

		tokenString := parts[1]

		token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
			if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, errors.NewUnauthorizedError("Invalid signing method")
			}
			return []byte(jwtSecret), nil
		})

		if err != nil || !token.Valid {
			return c.Next()
		}

		if claims, ok := token.Claims.(jwt.MapClaims); ok {
			if userID, ok := claims["user_id"].(float64); ok {
				c.Locals("user_id", int64(userID))
				c.Locals("username", claims["username"])
				c.Locals("is_admin", claims["is_admin"])
			}
		}

		return c.Next()
	}
}

// AdminMiddleware ensures user is an admin
func AdminMiddleware() fiber.Handler {
	return func(c *fiber.Ctx) error {
		isAdmin, ok := c.Locals("is_admin").(bool)
		if !ok || !isAdmin {
			return c.Status(fiber.StatusForbidden).JSON(dto.ErrorResponse{
				Success: false,
				Error:   "Administrator access required",
				Code:    errors.ErrCodeForbidden,
			})
		}
		return c.Next()
	}
}
