package service

import (
	"context"
	"database/sql"

	"rx-st-system/internal/dto"
	"rx-st-system/internal/repository"
	"rx-st-system/pkg/errors"

	"github.com/jackc/pgx/v5/pgxpool"
)

// RxOrderService handles RX order business logic
type RxOrderService struct {
	repo             repository.Querier
	db               *pgxpool.Pool
	productService   *ProductService
	inventoryService *InventoryService
}

// NewRxOrderService creates a new RxOrderService
func NewRxOrderService(repo repository.Querier, db *pgxpool.Pool, productService *ProductService, inventoryService *InventoryService) *RxOrderService {
	return &RxOrderService{
		repo:             repo,
		db:               db,
		productService:   productService,
		inventoryService: inventoryService,
	}
}

// Create creates a new RX order
func (s *RxOrderService) Create(ctx context.Context, req dto.CreateRxOrderRequest, userID int64) (*dto.RxOrderResponse, error) {
	// Generate order number
	orderNumber, err := s.repo.GetNextRxOrderNumber(ctx)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Calculate base and direction for semi-finished products
	rightBase := s.calculateBase(req.RightSPH)
	rightDirection := s.calculateDirection(req.RightSPH)
	leftBase := s.calculateBase(req.LeftSPH)
	leftDirection := s.calculateDirection(req.LeftSPH)

	// Find appropriate products
	finalProduct, err := s.repo.FindRxProduct(ctx, repository.FindRxProductParams{
		LensBrandID:    toNullInt64(req.LensBrandID),
		LensTypeID:     toNullInt64(req.LensTypeID),
		LensIndexID:    toNullInt64(req.LensIndexID),
		LensMaterialID: toNullInt64(req.LensMaterialID),
		LensColorID:    toNullInt64(req.LensColorID),
		LensDesignID:   toNullInt64(req.LensDesignID),
	})
	if err != nil {
		return nil, errors.NewNotFoundError("Final product not found")
	}

	// Find semi-finished products (استفاده از leftBase و leftDirection)
	rightSemiFinished, _ := s.repo.FindSemiFinishedProduct(ctx, rightBase, rightDirection)
	leftSemiFinished, _ := s.repo.FindSemiFinishedProduct(ctx, leftBase, leftDirection)

	var semiFinishedProductID sql.NullInt64
	if rightSemiFinished != nil {
		semiFinishedProductID = sql.NullInt64{Int64: rightSemiFinished.ID, Valid: true}
	} else if leftSemiFinished != nil {
		semiFinishedProductID = sql.NullInt64{Int64: leftSemiFinished.ID, Valid: true}
	}

	// Get initial state
	initialState, err := s.repo.GetStateByCode(ctx, "draft", "rx")
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var createdOrderID int64

	// استفاده صحیح از WithTx
	err = s.repo.WithTx(ctx, func(txRepo *repository.Repository) error {
		// Create order
		order, err := txRepo.CreateRxOrder(ctx, repository.CreateRxOrderParams{
			OrderNumber:           orderNumber,
			CustomerID:            req.CustomerID,
			FinalProductID:        sql.NullInt64{Int64: finalProduct.ID, Valid: true},
			SemiFinishedProductID: semiFinishedProductID,
			LensBrandID:           toNullInt64(req.LensBrandID),
			LensTypeID:            toNullInt64(req.LensTypeID),
			LensIndexID:           toNullInt64(req.LensIndexID),
			LensMaterialID:        toNullInt64(req.LensMaterialID),
			LensColorID:           toNullInt64(req.LensColorID),
			LensDesignID:          toNullInt64(req.LensDesignID),
			RightSph:              sql.NullFloat64{Float64: req.RightSPH, Valid: true},
			RightCyl:              toNullFloat64(req.RightCYL),
			RightAxis:             toNullInt64(req.RightAxis),
			RightAddition:         toNullFloat64(req.RightAddition),
			RightPd:               toNullFloat64(req.RightPD),
			RightDecentration:     toNullFloat64(req.RightDecentration),
			RightPrismValue:       toNullFloat64(req.RightPrismValue),
			RightPrismBase:        toNullInt64(req.RightPrismBase),
			LeftSph:               sql.NullFloat64{Float64: req.LeftSPH, Valid: true},
			LeftCyl:               toNullFloat64(req.LeftCYL),
			LeftAxis:              toNullInt64(req.LeftAxis),
			LeftAddition:          toNullFloat64(req.LeftAddition),
			LeftPd:                toNullFloat64(req.LeftPD),
			LeftDecentration:      toNullFloat64(req.LeftDecentration),
			LeftPrismValue:        toNullFloat64(req.LeftPrismValue),
			LeftPrismBase:         toNullInt64(req.LeftPrismBase),
			FrameType:             toNullString(req.FrameType),
			Hbox:                  toNullFloat64(req.HBOX),
			Vbox:                  toNullFloat64(req.VBOX),
			Dbl:                   toNullFloat64(req.DBL),
			Ed:                    toNullFloat64(req.ED),
			Panto:                 toNullFloat64(req.Panto),
			Ffa:                   toNullFloat64(req.FFA),
			Bvd:                   toNullFloat64(req.BVD),
			FrameShapeFile:        toNullString(req.FrameShapeFile),
			CoatingServiceID:      toNullInt64(req.CoatingServiceID),
			ColorServiceID:        toNullInt64(req.ColorServiceID),
			ColorType:             toNullString(req.ColorType),
			ColorSample:           toNullString(req.ColorSample),
			IsPriority:            req.IsPriority,
			BasePrice:             sql.NullFloat64{Float64: req.BasePrice, Valid: true},
			ServicePrice:          sql.NullFloat64{Float64: req.ServicePrice, Valid: true},
			TotalPrice:            sql.NullFloat64{Float64: req.TotalPrice, Valid: true},
			State:                 "draft",
			Priority:              sql.NullInt64{Int64: int64(req.Priority), Valid: true},
			CurrentStateID:        sql.NullInt64{Int64: initialState.ID, Valid: true},
			Notes:                 toNullString(req.Notes),
			ExpectedDate:          toNullTime(req.ExpectedDate),
			CreatedBy:             sql.NullInt64{Int64: userID, Valid: true},
		})
		if err != nil {
			return err
		}

		createdOrderID = order.ID

		// Add extra services
		if req.ExtraServices != nil {
			for _, serviceID := range req.ExtraServices {
				err := txRepo.AddRxOrderExtraService(ctx, repository.AddRxOrderExtraServiceParams{
					RxOrderID: order.ID,
					ServiceID: serviceID,
					Price:     sql.NullFloat64{Float64: 0, Valid: true},
				})
				if err != nil {
					return err
				}
			}
		}

		// Create state history
		err = txRepo.CreateRxOrderStateHistory(ctx, repository.CreateRxOrderStateHistoryParams{
			RxOrderID: order.ID,
			FromState: sql.NullString{Valid: false},
			ToState:   "draft",
			ChangedBy: userID,
			Notes:     sql.NullString{String: "Order created", Valid: true},
		})
		if err != nil {
			return err
		}

		return nil
	})

	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Get full order details
	return s.GetByID(ctx, createdOrderID)
}

// GetByID gets RX order by ID
func (s *RxOrderService) GetByID(ctx context.Context, id int64) (*dto.RxOrderResponse, error) {
	order, err := s.repo.GetRxOrder(ctx, id)
	if err != nil {
		if err.Error() == "rx order not found" {
			return nil, errors.NewNotFoundError("RX Order")
		}
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToRxOrderResponse(*order), nil
}

// List lists RX orders with pagination
func (s *RxOrderService) List(ctx context.Context, req dto.ListRxOrdersRequest) (*dto.ListResponse, error) {
	offset := (req.Page - 1) * req.PageSize

	orders, err := s.repo.ListRxOrders(ctx, repository.ListRxOrdersParams{
		Search:     sql.NullString{String: req.Search, Valid: req.Search != ""},
		CustomerID: toNullInt64(req.CustomerID),
		State:      toNullString(req.State),
		StateID:    toNullInt64(req.StateID),
		FromDate:   toNullTime(req.FromDate),
		ToDate:     toNullTime(req.ToDate),
		IsPriority: toNullBool(req.IsPriority),
		Limit:      int32(req.PageSize),
		Offset:     int32(offset),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	total, err := s.repo.CountRxOrders(ctx, repository.CountRxOrdersParams{
		Search:     sql.NullString{String: req.Search, Valid: req.Search != ""},
		CustomerID: toNullInt64(req.CustomerID),
		StateID:    toNullInt64(req.StateID),
		FromDate:   toNullTime(req.FromDate),
		ToDate:     toNullTime(req.ToDate),
		IsPriority: toNullBool(req.IsPriority),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.RxOrderResponse
	for _, order := range orders {
		responses = append(responses, *s.mapToRxOrderResponse(order))
	}

	pagination := dto.NewPaginationResponse(req.Page, req.PageSize, total)
	return dto.NewListResponse(responses, pagination), nil
}

// Update updates an RX order
func (s *RxOrderService) Update(ctx context.Context, id int64, req dto.UpdateRxOrderRequest, userID int64) (*dto.RxOrderResponse, error) {
	_, err := s.repo.GetRxOrder(ctx, id)
	if err != nil {
		if err.Error() == "rx order not found" {
			return nil, errors.NewNotFoundError("RX Order")
		}
		return nil, errors.NewDatabaseError(err)
	}

	_, err = s.repo.UpdateRxOrder(ctx, repository.UpdateRxOrderParams{
		ID:             id,
		RightSph:       toNullFloat64(req.RightSPH),
		RightCyl:       toNullFloat64(req.RightCYL),
		LeftSph:        toNullFloat64(req.LeftSPH),
		LeftCyl:        toNullFloat64(req.LeftCYL),
		HBOX:           toNullFloat64(req.HBOX),
		VBOX:           toNullFloat64(req.VBOX),
		ColorServiceID: toNullInt64(req.ColorServiceID),
		Priority:       toNullInt64(req.Priority),
		Notes:          toNullString(req.Notes),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.GetByID(ctx, id)
}

// Delete deletes an RX order
func (s *RxOrderService) Delete(ctx context.Context, id int64) error {
	_, err := s.repo.GetRxOrder(ctx, id)
	if err != nil {
		if err.Error() == "rx order not found" {
			return errors.NewNotFoundError("RX Order")
		}
		return errors.NewDatabaseError(err)
	}

	if err := s.repo.DeleteRxOrder(ctx, id); err != nil {
		return errors.NewDatabaseError(err)
	}

	return nil
}

// ChangeState changes order state
func (s *RxOrderService) ChangeState(ctx context.Context, id int64, newStateCode string, userID int64, notes *string) error {
	order, err := s.repo.GetStOrder(ctx, id)
	if err != nil {
		return errors.NewDatabaseError(err)
	}

	newState, err := s.repo.GetStateByCode(ctx, newStateCode, "st")
	if err != nil {
		return errors.NewNotFoundError("State")
	}

	var oldStateCode string
	if order.CurrentStateID.Valid {
		oldState, _ := s.repo.GetState(ctx, order.CurrentStateID.Int64)
		if oldState != nil {
			oldStateCode = oldState.StateCode
		}
	}

	err = s.repo.WithTx(ctx, func(txRepo *repository.Repository) error {
		// Update order state
		err := txRepo.UpdateRxOrderState(ctx, repository.UpdateRxOrderStateParams{
			ID:      id,
			StateID: newState.ID,
		})
		if err != nil {
			return err
		}

		// Create history
		err = txRepo.CreateRxOrderStateHistory(ctx, repository.CreateRxOrderStateHistoryParams{
			RxOrderID: id,
			FromState: sql.NullString{String: oldStateCode, Valid: oldStateCode != ""},
			ToState:   newStateCode,
			ChangedBy: userID,
			Notes:     toNullString(notes),
		})
		if err != nil {
			return err
		}

		return nil
	})

	if err != nil {
		return errors.NewDatabaseError(err)
	}

	return nil
}

func (s *RxOrderService) mapToRxOrderResponse(order repository.RxOrder) *dto.RxOrderResponse {
	return &dto.RxOrderResponse{
		ID:           order.ID,
		OrderNumber:  order.OrderNumber,
		CustomerID:   order.CustomerID,
		RightSPH:     nullFloat64ToFloat64(order.RightSph),
		RightCYL:     fromNullFloat64(order.RightCyl),
		RightAxis:    fromNullInt64(order.RightAxis),
		LeftSPH:      nullFloat64ToFloat64(order.LeftSph),
		LeftCYL:      fromNullFloat64(order.LeftCyl),
		LeftAxis:     fromNullInt64(order.LeftAxis),
		HBOX:         fromNullFloat64(order.Hbox),
		VBOX:         fromNullFloat64(order.Vbox),
		IsPriority:   order.IsPriority,
		BasePrice:    nullFloat64ToFloat64(order.BasePrice),
		ServicePrice: nullFloat64ToFloat64(order.ServicePrice),
		TotalPrice:   nullFloat64ToFloat64(order.TotalPrice),
		CurrentState: order.State,
		Notes:        fromNullString(order.Notes),
		CreatedAt:    order.CreatedAt,
		UpdatedAt:    order.UpdatedAt,
	}
}

// Helper functions
func (s *RxOrderService) calculatePricing(ctx context.Context, req dto.CreateRxOrderRequest, productID int64) (float64, float64, float64) {
	// Base price (from product or pricing service)
	basePrice := 500000.0 // Default

	// Service price
	servicePrice := 0.0

	// Coating is mandatory
	servicePrice += 100000.0

	// Color service
	if req.ColorServiceID != nil {
		servicePrice += 50000.0
	}

	// Extra services
	servicePrice += float64(len(req.ExtraServiceIDs)) * 25000.0

	// Priority
	if req.IsPriority {
		servicePrice += 150000.0
	}

	totalPrice := basePrice + servicePrice
	return basePrice, servicePrice, totalPrice
}
