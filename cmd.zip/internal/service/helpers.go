package service

import (
	"database/sql"
	"time"
)

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

// Convert pointer to sql.Null types

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

func toNullString(s *string) sql.NullString {
	if s == nil || *s == "" {
		return sql.NullString{Valid: false}
	}
	return sql.NullString{String: *s, Valid: true}
}

func fromNullString(ns sql.NullString) *string {
	if !ns.Valid {
		return nil
	}
	return &ns.String
}

// nullStringToString تبدیل sql.NullString به string (خالی اگر null)
func nullStringToString(ns sql.NullString) string {
	if !ns.Valid {
		return ""
	}
	return ns.String
}

func toNullBool(b *bool) sql.NullBool {
	if b == nil {
		return sql.NullBool{Valid: false}
	}
	return sql.NullBool{Bool: *b, Valid: true}
}

// getBoolValue دریافت مقدار bool از pointer
func getBoolValue(b *bool) bool {
	if b == nil {
		return false
	}
	return *b
}
func fromNullInt64(ni sql.NullInt64) *int64 {
	if !ni.Valid {
		return nil
	}
	return &ni.Int64
}

func toNullTime(t *time.Time) sql.NullTime {
	if t == nil {
		return sql.NullTime{Valid: false}
	}
	return sql.NullTime{Time: *t, Valid: true}
}

func nullFloat64ToFloat64(nf sql.NullFloat64) float64 {
	if !nf.Valid {
		return 0
	}
	return nf.Float64
}
func (s *RxOrderService) calculateBase(sph float64) float64 {
	// Simplified base calculation
	if sph >= 0 {
		return 4.0
	}
	return 6.0
}

func (s *RxOrderService) calculateDirection(sph float64) string {
	if sph >= 0 {
		return "plus"
	}
	return "minus"
}

// Helper functions
func toNullInt64(i *int64) sql.NullInt64 {
	if i == nil {
		return sql.NullInt64{Valid: false}
	}
	return sql.NullInt64{Int64: *i, Valid: true}
}

func toNullFloat64(f *float64) sql.NullFloat64 {
	if f == nil {
		return sql.NullFloat64{Valid: false}
	}
	return sql.NullFloat64{Float64: *f, Valid: true}
}

func fromNullFloat64(nf sql.NullFloat64) *float64 {
	if !nf.Valid {
		return nil
	}
	return &nf.Float64
}
