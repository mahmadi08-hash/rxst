package service

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"rx-st-system/internal/cache"
	"rx-st-system/internal/dto"
	"rx-st-system/internal/repository"
	"rx-st-system/pkg/errors"
	"rx-st-system/pkg/logger"

	"github.com/jackc/pgx/v5/pgxpool"
	"go.uber.org/zap"
)

// WarehouseService handles warehouse business logic
type WarehouseService struct {
	repo             repository.Querier
	db               *pgxpool.Pool
	inventoryCache   *cache.InventoryCache
	inventoryService *InventoryService
}

// NewWarehouseService creates a new WarehouseService
func NewWarehouseService(repo repository.Querier, db *pgxpool.Pool, inventoryCache *cache.InventoryCache) *WarehouseService {
	return &WarehouseService{
		repo:           repo,
		db:             db,
		inventoryCache: inventoryCache,
	}
}

// SetInventoryService sets the inventory service (to avoid circular dependency)
func (s *WarehouseService) SetInventoryService(inventoryService *InventoryService) {
	s.inventoryService = inventoryService
}

// CreateWarehouse creates a new warehouse
func (s *WarehouseService) CreateWarehouse(ctx context.Context, req dto.CreateWarehouseRequest, userID int64) (*dto.WarehouseResponse, error) {
	warehouse, err := s.repo.CreateWarehouse(ctx, repository.CreateWarehouseParams{
		Code:                req.Code,
		Name:                req.Name,
		FinancialSystemCode: toNullString(req.FinancialSystemCode),
		Address:             toNullString(req.Address),
		IsActive:            req.IsActive,
		CreatedBy:           sql.NullInt64{Int64: userID, Valid: true},
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToWarehouseResponse(warehouse), nil
}

// GetWarehouse gets warehouse by ID
func (s *WarehouseService) GetWarehouse(ctx context.Context, id int64) (*dto.WarehouseResponse, error) {
	warehouse, err := s.repo.GetWarehouse(ctx, id)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.NewNotFoundError("Warehouse")
		}
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToWarehouseResponse(warehouse), nil
}

// ListWarehouses lists all warehouses
func (s *WarehouseService) ListWarehouses(ctx context.Context) ([]dto.WarehouseResponse, error) {
	warehouses, err := s.repo.ListWarehouses(ctx)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.WarehouseResponse
	for _, warehouse := range warehouses {
		responses = append(responses, *s.mapToWarehouseResponse(warehouse))
	}

	return responses, nil
}

// UpdateWarehouse updates a warehouse
func (s *WarehouseService) UpdateWarehouse(ctx context.Context, id int64, req dto.UpdateWarehouseRequest, userID int64) (*dto.WarehouseResponse, error) {
	warehouse, err := s.repo.UpdateWarehouse(ctx, repository.UpdateWarehouseParams{
		ID:                  id,
		Name:                req.Name,
		FinancialSystemCode: toNullString(req.FinancialSystemCode),
		Address:             toNullString(req.Address),
		IsActive:            req.IsActive,
		UpdatedBy:           sql.NullInt64{Int64: userID, Valid: true},
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToWarehouseResponse(warehouse), nil
}

// CreateDocumentTemplate creates a document template
func (s *WarehouseService) CreateDocumentTemplate(ctx context.Context, req dto.CreateWarehouseDocumentTemplateRequest, userID int64) (*dto.WarehouseDocumentTemplateResponse, error) {
	template, err := s.repo.CreateWarehouseDocumentTemplate(ctx, repository.CreateWarehouseDocumentTemplateParams{
		Code:             req.Code,
		Name:             req.Name,
		Direction:        req.Direction,
		DocumentType:     req.DocumentType,
		AffectsInventory: req.AffectsInventory,
		RequiresApproval: req.RequiresApproval,
		IsActive:         req.IsActive,
		CreatedBy:        sql.NullInt64{Int64: userID, Valid: true},
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToTemplateResponse(template), nil
}

// ListDocumentTemplates lists all document templates
func (s *WarehouseService) ListDocumentTemplates(ctx context.Context) ([]dto.WarehouseDocumentTemplateResponse, error) {
	templates, err := s.repo.ListWarehouseDocumentTemplates(ctx)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.WarehouseDocumentTemplateResponse
	for _, template := range templates {
		responses = append(responses, *s.mapToTemplateResponse(template))
	}

	return responses, nil
}

// CreateDocument creates a warehouse document
func (s *WarehouseService) CreateDocument(ctx context.Context, req dto.CreateWarehouseDocumentRequest, userID int64) (*dto.WarehouseDocumentResponse, error) {
	// Validate template
	template, err := s.repo.GetWarehouseDocumentTemplate(ctx, req.TemplateID)
	if err != nil {
		return nil, errors.NewNotFoundError("Document template")
	}

	// Parse document date
	docDate, err := time.Parse("2006-01-02", req.DocumentDate)
	if err != nil {
		return nil, errors.NewValidationError("Invalid document date format", nil)
	}

	// Start transaction
	tx, err := s.db.Begin(ctx)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}
	defer tx.Rollback(ctx)

	qtx := s.repo.WithTx(tx)

	// Create document
	document, err := qtx.CreateWarehouseDocument(ctx, repository.CreateWarehouseDocumentParams{
		DocumentNumber:  req.DocumentNumber,
		FiscalYearID:    req.FiscalYearID,
		TemplateID:      req.TemplateID,
		WarehouseID:     req.WarehouseID,
		DocumentDate:    docDate,
		DocumentTime:    time.Now(),
		SupplierID:      toNullInt64(req.SupplierID),
		CustomerID:      toNullInt64(req.CustomerID),
		ReferenceNumber: toNullString(req.ReferenceNumber),
		Description:     toNullString(req.Description),
		Status:          "draft",
		CreatedBy:       sql.NullInt64{Int64: userID, Valid: true},
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Create document items
	totalAmount := 0.0
	for i, item := range req.Items {
		// Calculate amounts
		unitPrice := 0.0
		if item.UnitPrice != nil {
			unitPrice = *item.UnitPrice
		}
		totalPrice := item.Quantity * unitPrice

		discountPercent := 0.0
		if item.DiscountPercent != nil {
			discountPercent = *item.DiscountPercent
		}

		discountAmount := 0.0
		if item.DiscountAmount != nil {
			discountAmount = *item.DiscountAmount
		} else {
			discountAmount = totalPrice * discountPercent / 100
		}

		netAmount := totalPrice - discountAmount
		totalAmount += netAmount

		_, err := qtx.CreateWarehouseDocumentItem(ctx, repository.CreateWarehouseDocumentItemParams{
			DocumentID:      document.ID,
			LineNumber:      int32(i + 1),
			ProductID:       item.ProductID,
			UnitID:          item.UnitID,
			Quantity:        item.Quantity,
			UnitPrice:       unitPrice,
			TotalPrice:      totalPrice,
			DiscountPercent: discountPercent,
			DiscountAmount:  discountAmount,
			NetAmount:       netAmount,
			Description:     toNullString(item.Description),
		})
		if err != nil {
			return nil, errors.NewDatabaseError(err)
		}
	}

	// Update document total
	if err := qtx.UpdateWarehouseDocumentTotal(ctx, repository.UpdateWarehouseDocumentTotalParams{
		ID:          document.ID,
		TotalAmount: totalAmount,
	}); err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Commit transaction
	if err := tx.Commit(ctx); err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	logger.Info("Warehouse document created",
		zap.Int64("document_id", document.ID),
		zap.String("document_number", document.DocumentNumber),
	)

	return s.GetDocument(ctx, document.ID)
}

// GetDocument gets document by ID
func (s *WarehouseService) GetDocument(ctx context.Context, id int64) (*dto.WarehouseDocumentResponse, error) {
	document, err := s.repo.GetWarehouseDocument(ctx, id)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.NewNotFoundError("Warehouse document")
		}
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToDocumentResponse(ctx, document)
}

// ListDocuments lists warehouse documents
func (s *WarehouseService) ListDocuments(ctx context.Context, req dto.ListWarehouseDocumentsRequest) (*dto.ListResponse, error) {
	offset := (req.Page - 1) * req.PageSize

	var fromDate, toDate sql.NullTime
	if req.FromDate != nil {
		if parsed, err := time.Parse("2006-01-02", *req.FromDate); err == nil {
			fromDate = sql.NullTime{Time: parsed, Valid: true}
		}
	}
	if req.ToDate != nil {
		if parsed, err := time.Parse("2006-01-02", *req.ToDate); err == nil {
			toDate = sql.NullTime{Time: parsed, Valid: true}
		}
	}

	documents, err := s.repo.ListWarehouseDocuments(ctx, repository.ListWarehouseDocumentsParams{
		WarehouseID: req.WarehouseID,
		Status:      toNullString(req.Status),
		FromDate:    fromDate,
		ToDate:      toDate,
		Limit:       int32(req.PageSize),
		Offset:      int32(offset),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.WarehouseDocumentResponse
	for _, doc := range documents {
		resp, err := s.mapToDocumentResponse(ctx, doc)
		if err != nil {
			logger.Error("Failed to map document", zap.Error(err))
			continue
		}
		responses = append(responses, *resp)
	}

	pagination := dto.NewPaginationResponse(req.Page, req.PageSize, int64(len(responses)))
	return dto.NewListResponse(responses, pagination), nil
}

// PostDocument posts a document (affects inventory)
func (s *WarehouseService) PostDocument(ctx context.Context, documentID, userID int64) error {
	// Get document
	document, err := s.repo.GetWarehouseDocument(ctx, documentID)
	if err != nil {
		return errors.NewNotFoundError("Warehouse document")
	}

	if document.Status != "draft" {
		return errors.NewValidationError("Only draft documents can be posted", nil)
	}

	// Get template to check if it affects inventory
	template, err := s.repo.GetWarehouseDocumentTemplate(ctx, document.TemplateID)
	if err != nil {
		return errors.NewDatabaseError(err)
	}

	// Start transaction
	tx, err := s.db.Begin(ctx)
	if err != nil {
		return errors.NewDatabaseError(err)
	}
	defer tx.Rollback(ctx)

	qtx := s.repo.WithTx(tx)

	// If affects inventory, record transactions
	if template.AffectsInventory {
		items, err := qtx.ListWarehouseDocumentItems(ctx, documentID)
		if err != nil {
			return errors.NewDatabaseError(err)
		}

		// Calculate quantity change based on direction
		multiplier := 1.0
		if template.Direction == "out" {
			multiplier = -1.0
		}

		for _, item := range items {
			quantityChange := item.Quantity * multiplier

			// Record inventory transaction
			_, err := qtx.InsertInventoryTransaction(ctx, repository.InsertInventoryTransactionParams{
				WarehouseID:     document.WarehouseID,
				ProductID:       item.ProductID,
				UnitID:          item.UnitID,
				QuantityChange:  quantityChange,
				TransactionType: template.DocumentType,
				ReferenceType:   sql.NullString{String: "warehouse_document", Valid: true},
				ReferenceID:     sql.NullInt64{Int64: documentID, Valid: true},
				Description:     sql.NullString{String: fmt.Sprintf("Document #%s", document.DocumentNumber), Valid: true},
				CreatedBy:       sql.NullInt64{Int64: userID, Valid: true},
			})
			if err != nil {
				return errors.NewDatabaseError(err)
			}

			// Invalidate cache for this product
			s.inventoryCache.InvalidateBalance(ctx, document.WarehouseID, item.ProductID, item.UnitID)
		}
	}

	// Update document status
	now := time.Now()
	_, err = qtx.UpdateWarehouseDocumentStatus(ctx, repository.UpdateWarehouseDocumentStatusParams{
		ID:       documentID,
		Status:   "posted",
		PostedAt: sql.NullTime{Time: now, Valid: true},
		PostedBy: sql.NullInt64{Int64: userID, Valid: true},
	})
	if err != nil {
		return errors.NewDatabaseError(err)
	}

	// Commit transaction
	if err := tx.Commit(ctx); err != nil {
		return errors.NewDatabaseError(err)
	}

	logger.Info("Warehouse document posted",
		zap.Int64("document_id", documentID),
		zap.String("document_number", document.DocumentNumber),
	)

	return nil
}

// GetNextDocumentNumber gets next document number
func (s *WarehouseService) GetNextDocumentNumber(ctx context.Context, fiscalYearID int64) (*dto.GetNextDocumentNumberResponse, error) {
	nextNumber, err := s.repo.GetNextDocumentNumber(ctx, fiscalYearID)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return &dto.GetNextDocumentNumberResponse{
		NextNumber:      int(nextNumber),
		SuggestedNumber: fmt.Sprintf("DOC-%06d", nextNumber),
	}, nil
}

// Helper functions
func (s *WarehouseService) mapToWarehouseResponse(warehouse repository.Warehouse) *dto.WarehouseResponse {
	return &dto.WarehouseResponse{
		ID:                  warehouse.ID,
		Code:                warehouse.Code,
		Name:                warehouse.Name,
		FinancialSystemCode: fromNullString(warehouse.FinancialSystemCode),
		Address:             fromNullString(warehouse.Address),
		IsActive:            warehouse.IsActive,
		CreatedBy:           fromNullInt64(warehouse.CreatedBy),
		CreatedAt:           warehouse.CreatedAt,
		UpdatedBy:           fromNullInt64(warehouse.UpdatedBy),
		UpdatedAt:           warehouse.UpdatedAt,
	}
}

func (s *WarehouseService) mapToTemplateResponse(template repository.WarehouseDocumentTemplate) *dto.WarehouseDocumentTemplateResponse {
	return &dto.WarehouseDocumentTemplateResponse{
		ID:               template.ID,
		Code:             template.Code,
		Name:             template.Name,
		Direction:        template.Direction,
		DocumentType:     template.DocumentType,
		AffectsInventory: template.AffectsInventory,
		RequiresApproval: template.RequiresApproval,
		IsActive:         template.IsActive,
		CreatedAt:        template.CreatedAt,
	}
}

func (s *WarehouseService) mapToDocumentResponse(ctx context.Context, doc repository.WarehouseDocument) (*dto.WarehouseDocumentResponse, error) {
	// Get template
	template, _ := s.repo.GetWarehouseDocumentTemplate(ctx, doc.TemplateID)
	var templateResp *dto.WarehouseDocumentTemplateResponse
	if template != nil {
		templateResp = s.mapToTemplateResponse(*template)
	}

	// Get warehouse
	warehouse, _ := s.repo.GetWarehouse(ctx, doc.WarehouseID)
	var warehouseResp *dto.WarehouseResponse
	if warehouse != nil {
		warehouseResp = s.mapToWarehouseResponse(*warehouse)
	}

	// Get items
	items, _ := s.repo.ListWarehouseDocumentItems(ctx, doc.ID)
	var itemResponses []dto.WarehouseDocumentItemResponse
	for _, item := range items {
		itemResponses = append(itemResponses, dto.WarehouseDocumentItemResponse{
			ID:              item.ID,
			LineNumber:      item.LineNumber,
			Quantity:        item.Quantity,
			UnitPrice:       fromNullFloat64(sql.NullFloat64{Float64: item.UnitPrice, Valid: true}),
			TotalPrice:      fromNullFloat64(sql.NullFloat64{Float64: item.TotalPrice, Valid: true}),
			DiscountPercent: fromNullFloat64(sql.NullFloat64{Float64: item.DiscountPercent, Valid: true}),
			DiscountAmount:  fromNullFloat64(sql.NullFloat64{Float64: item.DiscountAmount, Valid: true}),
			NetAmount:       fromNullFloat64(sql.NullFloat64{Float64: item.NetAmount, Valid: true}),
			Description:     fromNullString(item.Description),
		})
	}

	return &dto.WarehouseDocumentResponse{
		ID:              doc.ID,
		DocumentNumber:  doc.DocumentNumber,
		FiscalYearID:    doc.FiscalYearID,
		Template:        templateResp,
		Warehouse:       warehouseResp,
		DocumentDate:    doc.DocumentDate,
		DocumentTime:    fromNullTime(doc.DocumentTime),
		ReferenceNumber: fromNullString(doc.ReferenceNumber),
		Description:     fromNullString(doc.Description),
		Status:          doc.Status,
		TotalAmount:     doc.TotalAmount,
		Items:           itemResponses,
		CreatedBy:       fromNullInt64(doc.CreatedBy),
		CreatedAt:       doc.CreatedAt,
		PostedAt:        fromNullTime(doc.PostedAt),
	}, nil
}

func fromNullTime(nt sql.NullTime) *time.Time {
	if !nt.Valid {
		return nil
	}
	return &nt.Time
}
