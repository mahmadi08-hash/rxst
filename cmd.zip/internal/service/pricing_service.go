package service

import (
	"context"
	"database/sql"
	"time"

	"rx-st-system/internal/dto"
	"rx-st-system/internal/repository"
	"rx-st-system/pkg/errors"
	"rx-st-system/pkg/logger"

	"github.com/jackc/pgx/v5/pgxpool"
	"go.uber.org/zap"
)

// PricingService handles all pricing-related business logic
type PricingService struct {
	repo repository.Querier
	db   *pgxpool.Pool
}

// NewPricingService creates a new pricing service
func NewPricingService(repo repository.Querier, db *pgxpool.Pool) *PricingService {
	return &PricingService{
		repo: repo,
		db:   db,
	}
}

// CalculatePrice calculates the total price for an order
func (s *PricingService) CalculatePrice(ctx context.Context, req dto.CalculatePriceRequest) (*dto.CalculatePriceResponse, error) {
	var basePrice float64 = 0
	var servicePrice float64 = 0
	var extraServices []dto.ServicePriceItem

	// Calculate based on order type
	if req.OrderType == "rx" {
		basePrice = s.calculateRxBasePrice(ctx, req)
		servicePrice, extraServices = s.calculateRxServices(ctx, req)
	} else if req.OrderType == "st" {
		basePrice = s.calculateStBasePrice(ctx, req)
		servicePrice, extraServices = s.calculateStServices(ctx, req)
	}

	// Priority fee (30% surcharge)
	priorityFee := 0.0
	if req.IsPriority {
		priorityFee = basePrice * 0.30
		servicePrice += priorityFee
	}

	subTotal := basePrice + servicePrice

	// Apply discounts (placeholder - implement rule engine)
	discountAmount := 0.0
	discounts := []dto.DiscountItem{}

	// Calculate tax (9% VAT in Iran)
	taxableAmount := subTotal - discountAmount
	taxRate := 0.09
	taxAmount := taxableAmount * taxRate

	taxes := []dto.TaxItem{
		{
			TaxType:     "vat",
			Description: "مالیات بر ارزش افزوده (9%)",
			Rate:        taxRate,
			Amount:      taxAmount,
		},
	}

	totalPrice := taxableAmount + taxAmount

	// Build price breakdown
	breakdown := dto.PriceBreakdownResponse{
		ProductPrice:  basePrice,
		CoatingPrice:  0,
		ColorPrice:    0,
		ExtraServices: extraServices,
		PriorityFee:   priorityFee,
		Discounts:     discounts,
		Taxes:         taxes,
	}

	if req.OrderType == "rx" {
		if req.CoatingServiceID != nil {
			coating, _ := s.getServicePrice(ctx, *req.CoatingServiceID)
			breakdown.CoatingPrice = coating
		}
		if req.ColorServiceID != nil {
			color, _ := s.getServicePrice(ctx, *req.ColorServiceID)
			breakdown.ColorPrice = color
		}
	}

	return &dto.CalculatePriceResponse{
		BasePrice:      basePrice,
		ServicePrice:   servicePrice,
		SubTotal:       subTotal,
		DiscountAmount: discountAmount,
		TaxAmount:      taxAmount,
		TotalPrice:     totalPrice,
		AppliedRules:   []dto.AppliedPriceRuleResponse{},
		Breakdown:      breakdown,
		CalculatedAt:   time.Now(),
	}, nil
}

// CreatePriceRule creates a new pricing rule
func (s *PricingService) CreatePriceRule(ctx context.Context, req dto.CreatePriceRuleRequest, userID int64) (*dto.PriceRuleResponse, error) {
	validFrom, err := time.Parse("2006-01-02", req.ValidFrom)
	if err != nil {
		return nil, errors.NewValidationError("Invalid valid_from date format", nil)
	}

	var validTo sql.NullTime
	if req.ValidTo != nil {
		parsed, err := time.Parse("2006-01-02", *req.ValidTo)
		if err != nil {
			return nil, errors.NewValidationError("Invalid valid_to date format", nil)
		}
		validTo = sql.NullTime{Time: parsed, Valid: true}
	}

	rule, err := s.repo.CreatePriceRule(ctx, repository.CreatePriceRuleParams{
		RuleCode:    req.RuleCode,
		RuleName:    req.RuleName,
		Description: toNullString(req.Description),
		RuleType:    req.RuleType,
		Priority:    req.Priority,
		ValidFrom:   validFrom,
		ValidTo:     validTo,
		IsActive:    req.IsActive,
		CreatedBy:   sql.NullInt64{Int64: userID, Valid: true},
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToPriceRuleResponse(rule), nil
}

// GetPriceRule retrieves a price rule by ID
func (s *PricingService) GetPriceRule(ctx context.Context, id int64) (*dto.PriceRuleResponse, error) {
	rule, err := s.repo.GetPriceRule(ctx, id)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.NewNotFoundError("Price Rule")
		}
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToPriceRuleResponse(rule), nil
}

// ListPriceRules lists all price rules with pagination
func (s *PricingService) ListPriceRules(ctx context.Context, req dto.ListPriceRulesRequest) (*dto.ListResponse, error) {
	offset := (req.Page - 1) * req.PageSize

	var validDate sql.NullTime
	if req.ValidDate != nil {
		parsed, err := time.Parse("2006-01-02", *req.ValidDate)
		if err == nil {
			validDate = sql.NullTime{Time: parsed, Valid: true}
		}
	}

	rules, err := s.repo.ListPriceRules(ctx, repository.ListPriceRulesParams{
		RuleType:  sql.NullString{String: fromStringPtr(req.RuleType), Valid: req.RuleType != nil},
		IsActive:  toNullBool(req.IsActive),
		ValidDate: validDate,
		Limit:     int32(req.PageSize),
		Offset:    int32(offset),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	total, err := s.repo.CountPriceRules(ctx, repository.CountPriceRulesParams{
		RuleType: sql.NullString{String: fromStringPtr(req.RuleType), Valid: req.RuleType != nil},
		IsActive: toNullBool(req.IsActive),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.PriceRuleResponse
	for _, rule := range rules {
		responses = append(responses, *s.mapToPriceRuleResponse(rule))
	}

	pagination := dto.NewPaginationResponse(req.Page, req.PageSize, total)
	return dto.NewListResponse(responses, pagination), nil
}

// UpdatePriceRule updates an existing price rule
func (s *PricingService) UpdatePriceRule(ctx context.Context, id int64, req dto.UpdatePriceRuleRequest, userID int64) (*dto.PriceRuleResponse, error) {
	var validFrom sql.NullTime
	if req.ValidFrom != nil {
		parsed, err := time.Parse("2006-01-02", *req.ValidFrom)
		if err != nil {
			return nil, errors.NewValidationError("Invalid valid_from date", nil)
		}
		validFrom = sql.NullTime{Time: parsed, Valid: true}
	}

	var validTo sql.NullTime
	if req.ValidTo != nil {
		parsed, err := time.Parse("2006-01-02", *req.ValidTo)
		if err != nil {
			return nil, errors.NewValidationError("Invalid valid_to date", nil)
		}
		validTo = sql.NullTime{Time: parsed, Valid: true}
	}

	rule, err := s.repo.UpdatePriceRule(ctx, repository.UpdatePriceRuleParams{
		ID:          id,
		RuleName:    toNullString(req.RuleName),
		Description: toNullString(req.Description),
		Priority:    toNullInt32FromInt32Ptr(req.Priority),
		ValidFrom:   validFrom,
		ValidTo:     validTo,
		IsActive:    toNullBool(req.IsActive),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToPriceRuleResponse(rule), nil
}

// DeletePriceRule deletes a price rule
func (s *PricingService) DeletePriceRule(ctx context.Context, id int64) error {
	if err := s.repo.DeletePriceRule(ctx, id); err != nil {
		return errors.NewDatabaseError(err)
	}
	return nil
}

// UpdateProductPrice updates the price of a product
func (s *PricingService) UpdateProductPrice(ctx context.Context, req dto.UpdateProductPriceRequest, userID int64) (*dto.ProductPriceResponse, error) {
	// Get old price for history
	oldPriceRecord, _ := s.repo.GetProductPrice(ctx, req.ProductID)
	oldPrice := 0.0
	if oldPriceRecord != nil {
		oldPrice = oldPriceRecord.Price
	}

	// Start transaction
	tx, err := s.db.Begin(ctx)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}
	defer tx.Rollback(ctx)

	qtx := s.repo.WithTx(tx)

	// Set new price
	effectiveDate := time.Now()
	_, err = qtx.SetProductPrice(ctx, repository.SetProductPriceParams{
		ProductID:     req.ProductID,
		PriceType:     "base",
		Price:         req.BasePrice,
		EffectiveDate: effectiveDate,
		CreatedBy:     sql.NullInt64{Int64: userID, Valid: true},
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Create price history record
	_, err = qtx.CreatePriceHistory(ctx, repository.CreatePriceHistoryParams{
		EntityType:   "product",
		EntityID:     req.ProductID,
		OldPrice:     oldPrice,
		NewPrice:     req.BasePrice,
		ChangeReason: toNullString(&req.ChangeReason),
		ChangedBy:    sql.NullInt64{Int64: userID, Valid: true},
	})
	if err != nil {
		logger.Error("Failed to create price history", zap.Error(err))
	}

	if err := tx.Commit(ctx); err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Get product details
	product, _ := s.repo.GetProduct(ctx, req.ProductID)
	productName := "Unknown"
	productCode := ""
	if product != nil {
		productName = product.Name
		productCode = product.Code
	}

	return &dto.ProductPriceResponse{
		ProductID:     req.ProductID,
		ProductCode:   productCode,
		ProductName:   productName,
		BasePrice:     req.BasePrice,
		SalePrice:     req.SalePrice,
		Currency:      "IRR",
		EffectiveDate: effectiveDate,
	}, nil
}

// BulkUpdatePrice updates prices for multiple products
func (s *PricingService) BulkUpdatePrice(ctx context.Context, req dto.BulkUpdatePriceRequest, userID int64) error {
	if err := s.repo.BulkUpdateProductPrices(ctx, repository.BulkUpdateProductPricesParams{
		Column1: req.ProductIDs,
		Column2: req.UpdateType,
		Column3: req.Value,
	}); err != nil {
		return errors.NewDatabaseError(err)
	}

	logger.Info("Bulk price update completed",
		zap.Int("product_count", len(req.ProductIDs)),
		zap.String("update_type", req.UpdateType),
		zap.Float64("value", req.Value),
	)

	return nil
}

// Helper methods
func (s *PricingService) calculateRxBasePrice(ctx context.Context, req dto.CalculatePriceRequest) float64 {
	// Base price calculation for RX orders
	// In production, this would query price rules and apply complex logic
	return 500000.0 // 500,000 IRR base price
}

func (s *PricingService) calculateRxServices(ctx context.Context, req dto.CalculatePriceRequest) (float64, []dto.ServicePriceItem) {
	total := 0.0
	items := []dto.ServicePriceItem{}

	// Coating service (mandatory)
	if req.CoatingServiceID != nil {
		price, name := s.getServicePriceAndName(ctx, *req.CoatingServiceID)
		total += price
		items = append(items, dto.ServicePriceItem{
			ServiceID:   *req.CoatingServiceID,
			ServiceName: name,
			Price:       price,
		})
	}

	// Color service (optional)
	if req.ColorServiceID != nil {
		price, name := s.getServicePriceAndName(ctx, *req.ColorServiceID)
		total += price
		items = append(items, dto.ServicePriceItem{
			ServiceID:   *req.ColorServiceID,
			ServiceName: name,
			Price:       price,
		})
	}

	// Extra services
	for _, serviceID := range req.ExtraServiceIDs {
		price, name := s.getServicePriceAndName(ctx, serviceID)
		total += price
		items = append(items, dto.ServicePriceItem{
			ServiceID:   serviceID,
			ServiceName: name,
			Price:       price,
		})
	}

	return total, items
}

func (s *PricingService) calculateStBasePrice(ctx context.Context, req dto.CalculatePriceRequest) float64 {
	total := 0.0
	
	for i, productID := range req.ProductIDs {
		quantity := 1.0
		if i < len(req.Quantities) {
			quantity = req.Quantities[i]
		}
		
		price, _ := s.getServicePrice(ctx, productID)
		total += price * quantity
	}
	
	return total
}

func (s *PricingService) calculateStServices(ctx context.Context, req dto.CalculatePriceRequest) (float64, []dto.ServicePriceItem) {
	// ST orders typically don't have additional services beyond cutting
	return 0.0, []dto.ServicePriceItem{}
}

func (s *PricingService) getServicePrice(ctx context.Context, serviceID int64) (float64, error) {
	priceRecord, err := s.repo.GetServicePrice(ctx, serviceID)
	if err != nil {
		if err == sql.ErrNoRows {
			return 50000.0, nil // Default service price
		}
		return 0, err
	}
	return priceRecord.Price, nil
}

func (s *PricingService) getServicePriceAndName(ctx context.Context, serviceID int64) (float64, string) {
	price, _ := s.getServicePrice(ctx, serviceID)
	
	product, _ := s.repo.GetProduct(ctx, serviceID)
	name := "سرویس"
	if product != nil {
		name = product.Name
	}
	
	return price, name
}

func (s *PricingService) mapToPriceRuleResponse(rule *repository.PriceRule) *dto.PriceRuleResponse {
	return &dto.PriceRuleResponse{
		ID:          rule.ID,
		RuleCode:    rule.RuleCode,
		RuleName:    rule.RuleName,
		Description: fromNullString(rule.Description),
		RuleType:    rule.RuleType,
		Priority:    rule.Priority,
		IsActive:    rule.IsActive,
		ValidFrom:   rule.ValidFrom,
		ValidTo:     fromNullTime(rule.ValidTo),
		CreatedAt:   rule.CreatedAt,
		UpdatedAt:   rule.UpdatedAt,
	}
}

func fromStringPtr(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}

func toNullInt32FromInt32Ptr(i *int32) sql.NullInt32 {
	if i == nil {
		return sql.NullInt32{Valid: false}
	}
	return sql.NullInt32{Int32: *i, Valid: true}
}
