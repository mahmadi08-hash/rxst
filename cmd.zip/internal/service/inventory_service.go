package service

import (
	"context"
	"database/sql"
	"time"

	"rx-st-system/internal/cache"
	"rx-st-system/internal/dto"
	"rx-st-system/internal/repository"
	"rx-st-system/pkg/errors"
	"rx-st-system/pkg/logger"

	"github.com/jackc/pgx/v5/pgxpool"
	"go.uber.org/zap"
)

// InventoryService handles inventory business logic
type InventoryService struct {
	repo           repository.Querier
	db             *pgxpool.Pool
	inventoryCache *cache.InventoryCache
}

// NewInventoryService creates a new InventoryService
func NewInventoryService(repo repository.Querier, db *pgxpool.Pool, inventoryCache *cache.InventoryCache) *InventoryService {
	return &InventoryService{
		repo:           repo,
		db:             db,
		inventoryCache: inventoryCache,
	}
}

// ListBalances lists inventory balances for a warehouse
func (s *InventoryService) ListBalances(ctx context.Context, warehouseID int64) ([]dto.InventoryBalanceResponse, error) {
	balances, err := s.repo.ListInventoryBalances(ctx, warehouseID)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.InventoryBalanceResponse
	for _, balance := range balances {
		responses = append(responses, *s.mapToInventoryBalanceResponse(balance))
	}

	return responses, nil
}

// ListBalancesByProduct lists inventory balances for a product
func (s *InventoryService) ListBalancesByProduct(ctx context.Context, productID int64) ([]dto.InventoryBalanceResponse, error) {
	balances, err := s.repo.ListInventoryBalancesByProduct(ctx, productID)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.InventoryBalanceResponse
	for _, balance := range balances {
		responses = append(responses, *s.mapToInventoryBalanceResponse(balance))
	}

	return responses, nil
}

// ReserveInventory reserves inventory for an order
func (s *InventoryService) ReserveInventory(ctx context.Context, productID int64, warehouseID int64, unitID int64, quantity float64, userID int64) error {
	err := s.repo.WithTx(ctx, func(txRepo *repository.Repository) error {
		// Update reservation
		err := txRepo.UpdateInventoryReservation(ctx, productID, warehouseID, unitID, quantity)
		if err != nil {
			return err
		}

		// Get current balance
		balance, err := txRepo.GetInventoryBalance(ctx, productID, warehouseID, unitID)
		if err != nil {
			return err
		}

		// Record transaction
		_, err = txRepo.InsertInventoryTransaction(ctx, repository.CreateInventoryTransactionParams{
			WarehouseID:     warehouseID,
			ProductID:       productID,
			UnitID:          unitID,
			Quantity:        balance.QuantityOnHand,
			QuantityChange:  -quantity,
			BalanceAfter:    balance.QuantityAvailable,
			TransactionType: "reservation",
			TransactionDate: time.Now(),
			ReferenceType:   sql.NullString{String: "order", Valid: true},
			ReferenceID:     sql.NullInt64{Valid: false},
			Notes:           sql.NullString{String: "Inventory reserved", Valid: true},
			Description:     sql.NullString{String: "Reserved for order", Valid: true},
			ProductCode:     sql.NullString{Valid: false},
			ProductName:     sql.NullString{Valid: false},
			CreatedBy:       userID,
		})
		if err != nil {
			return err
		}

		return nil
	})

	if err != nil {
		return errors.NewDatabaseError(err)
	}

	return nil
}

// ReleaseInventory releases reserved inventory
func (s *InventoryService) ReleaseInventory(ctx context.Context, productID int64, warehouseID int64, unitID int64, quantity float64, userID int64) error {
	err := s.repo.WithTx(ctx, func(txRepo *repository.Repository) error {
		// Release reservation
		err := txRepo.ReleaseInventoryReservation(ctx, productID, warehouseID, unitID, quantity)
		if err != nil {
			return err
		}

		// Get current balance
		balance, err := txRepo.GetInventoryBalance(ctx, productID, warehouseID, unitID)
		if err != nil {
			return err
		}

		// Record transaction
		_, err = txRepo.InsertInventoryTransaction(ctx, repository.CreateInventoryTransactionParams{
			WarehouseID:     warehouseID,
			ProductID:       productID,
			UnitID:          unitID,
			Quantity:        balance.QuantityOnHand,
			QuantityChange:  quantity,
			BalanceAfter:    balance.QuantityAvailable,
			TransactionType: "release",
			TransactionDate: time.Now(),
			ReferenceType:   sql.NullString{String: "order", Valid: true},
			ReferenceID:     sql.NullInt64{Valid: false},
			Notes:           sql.NullString{String: "Reservation released", Valid: true},
			Description:     sql.NullString{String: "Released from order", Valid: true},
			ProductCode:     sql.NullString{Valid: false},
			ProductName:     sql.NullString{Valid: false},
			CreatedBy:       userID,
		})
		if err != nil {
			return err
		}

		return nil
	})

	if err != nil {
		return errors.NewDatabaseError(err)
	}

	return nil
}

// GetBulkBalances gets multiple balances at once
func (s *InventoryService) GetBulkBalances(ctx context.Context, req dto.BulkInventoryBalanceRequest) (*dto.BulkInventoryBalanceResponse, error) {
	// Try to get from cache first
	cachedBalances := s.inventoryCache.GetMultipleBalances(ctx, req.WarehouseID, req.ProductIDs, 0)

	result := make(map[int64]float64)
	missingProductIDs := []int64{}

	// Check which products we found in cache
	for _, productID := range req.ProductIDs {
		if cached, found := cachedBalances[productID]; found {
			result[productID] = cached.QuantityAvailable
		} else {
			missingProductIDs = append(missingProductIDs, productID)
		}
	}

	// Fetch missing products from database
	for _, productID := range missingProductIDs {
		balance, err := s.GetBalanceByProduct(ctx, req.WarehouseID, productID)
		if err != nil {
			logger.Error("Failed to get balance for product",
				zap.Int64("product_id", productID),
				zap.Error(err),
			)
			result[productID] = 0
			continue
		}
		result[productID] = balance.QuantityAvailable
	}

	return &dto.BulkInventoryBalanceResponse{
		Balances: result,
	}, nil
}

// GetBalanceByProduct - SIGNATURE صحیح برای handler
func (s *InventoryService) GetBalanceByProduct(ctx context.Context, warehouseID int64, productID int64) (*dto.InventoryBalanceResponse, error) {
	// ۱. دریافت لیست از ریپازیتوری
	balances, err := s.repo.GetInventoryBalanceByProduct(ctx, productID)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	if len(balances) == 0 {
		return nil, errors.NewNotFoundError("موجودی برای این محصول یافت نشد")
	}

	return s.mapToInventoryBalanceResponse(balances[0]), nil
}

// GetBalancesByProduct gets all balances for a product across warehouses
func (s *InventoryService) GetBalancesByProduct(ctx context.Context, warehouseID int64, productID int64) ([]dto.InventoryBalanceResponse, error) {
	balances, err := s.repo.GetInventoryBalanceByProduct(ctx, productID)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.InventoryBalanceResponse
	for _, balance := range balances {
		responses = append(responses, *s.mapToInventoryBalanceResponse(balance))
	}

	return responses, nil
}

// AdjustInventory adjusts inventory (manual adjustment)
func (s *InventoryService) AdjustInventory(ctx context.Context, req dto.AdjustInventoryRequest, userID int64) error {
	// استفاده از پترن WithTx مشابه تابع ReleaseInventory
	// این متد خودش Begin، Commit و در صورت خطا Rollback را مدیریت می‌کند
	err := s.repo.WithTx(ctx, func(txRepo *repository.Repository) error {

		// انجام عملیات دیتابیس با استفاده از txRepo (که داخل تراکنش است)
		_, err := txRepo.InsertInventoryTransaction(ctx, repository.InsertInventoryTransactionParams{
			WarehouseID:     req.WarehouseID,
			ProductID:       req.ProductID,
			UnitID:          req.UnitID,
			QuantityChange:  req.QuantityChange,
			TransactionType: req.TransactionType,
			Description:     sql.NullString{String: req.Description, Valid: req.Description != ""},
			CreatedBy:       sql.NullInt64{Int64: userID, Valid: true},
		})

		if err != nil {
			return err // این باعث Rollback خودکار می‌شود
		}

		return nil // اگر nil برگردد، Commit انجام می‌شود
	})

	// بررسی اینکه آیا کل پروسه WithTx با خطا مواجه شده یا خیر
	if err != nil {
		return errors.NewDatabaseError(err)
	}

	// عملیات‌های غیر دیتابیسی (مثل پاک کردن کش و لاگ) باید بعد از موفقیت تراکنش انجام شوند
	// اگر آن‌ها را داخل WithTx بگذارید و تراکنش Rollback شود، کش بی‌دلیل پاک شده است
	s.inventoryCache.InvalidateBalance(ctx, req.WarehouseID, req.ProductID, req.UnitID)

	logger.Info("Inventory adjusted",
		zap.Int64("warehouse_id", req.WarehouseID),
		zap.Int64("product_id", req.ProductID),
		zap.Float64("quantity_change", req.QuantityChange),
	)

	return nil
}

// GetSummary gets inventory summary for a warehouse
func (s *InventoryService) GetSummary(ctx context.Context, warehouseID int64) (*dto.InventorySummaryResponse, error) {
	// Get warehouse
	warehouse, err := s.repo.GetWarehouse(ctx, warehouseID)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Get all balances
	balances, err := s.repo.ListInventoryBalances(ctx, warehouseID)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	totalProducts := int64(0)
	totalQuantity := 0.0
	outOfStock := int64(0)

	for _, balance := range balances {
		totalProducts++
		totalQuantity += balance.QuantityOnHand
		if balance.QuantityAvailable <= 0 {
			outOfStock++
		}
	}

	return &dto.InventorySummaryResponse{
		WarehouseID:        warehouse.ID,
		WarehouseName:      warehouse.Name,
		TotalProducts:      totalProducts,
		TotalQuantity:      totalQuantity,
		OutOfStockProducts: outOfStock,
	}, nil
}

// InvalidateCache invalidates inventory cache
func (s *InventoryService) InvalidateCache(ctx context.Context, warehouseID, productID int64) error {
	if productID > 0 {
		return s.inventoryCache.InvalidateProduct(ctx, productID)
	}
	if warehouseID > 0 {
		return s.inventoryCache.InvalidateWarehouse(ctx, warehouseID)
	}
	return s.inventoryCache.ClearAll(ctx)
}

// Helper functions
func (s *InventoryService) mapToBalanceResponse(ctx context.Context, balance repository.InventoryBalance) (*dto.InventoryBalanceResponse, error) {
	// Get product info
	product, err := s.repo.GetProduct(ctx, balance.ProductID)
	if err != nil {
		return nil, err
	}

	// Get warehouse info
	warehouse, err := s.repo.GetWarehouse(ctx, balance.WarehouseID)
	if err != nil {
		return nil, err
	}

	// Get unit info
	unit, err := s.repo.GetUnitOfMeasure(ctx, balance.UnitID)
	if err != nil {
		return nil, err
	}

	return &dto.InventoryBalanceResponse{
		ID:                balance.ID,
		WarehouseID:       balance.WarehouseID,
		WarehouseName:     warehouse.Name,
		ProductID:         balance.ProductID,
		ProductCode:       product.Code,
		ProductName:       product.Name,
		UnitID:            balance.UnitID,
		UnitName:          unit.Name,
		QuantityOnHand:    balance.QuantityOnHand,
		QuantityReserved:  balance.QuantityReserved,
		QuantityAvailable: balance.QuantityAvailable,
		LastUpdated:       balance.LastUpdated,
	}, nil
}

func (s *InventoryService) mapCacheToBalanceResponse(ctx context.Context, cached *cache.InventoryBalance) (*dto.InventoryBalanceResponse, error) {
	// Get product info
	product, err := s.repo.GetProduct(ctx, cached.ProductID)
	if err != nil {
		return nil, err
	}

	// Get warehouse info
	warehouse, err := s.repo.GetWarehouse(ctx, cached.WarehouseID)
	if err != nil {
		return nil, err
	}

	// Get unit info
	unit, err := s.repo.GetUnitOfMeasure(ctx, cached.UnitID)
	if err != nil {
		return nil, err
	}

	return &dto.InventoryBalanceResponse{
		WarehouseID:       cached.WarehouseID,
		WarehouseName:     warehouse.Name,
		ProductID:         cached.ProductID,
		ProductCode:       product.Code,
		ProductName:       product.Name,
		UnitID:            cached.UnitID,
		UnitName:          unit.Name,
		QuantityOnHand:    cached.QuantityOnHand,
		QuantityReserved:  cached.QuantityReserved,
		QuantityAvailable: cached.QuantityAvailable,
		LastUpdated:       cached.LastUpdated,
	}, nil
}

func (s *InventoryService) cacheBalance(ctx context.Context, balance repository.InventoryBalance) {
	cached := &cache.InventoryBalance{
		ProductID:         balance.ProductID,
		WarehouseID:       balance.WarehouseID,
		UnitID:            balance.UnitID,
		QuantityOnHand:    balance.QuantityOnHand,
		QuantityReserved:  balance.QuantityReserved,
		QuantityAvailable: balance.QuantityAvailable,
		LastUpdated:       balance.LastUpdated,
	}

	if err := s.inventoryCache.SetBalance(ctx, cached); err != nil {
		logger.Error("Failed to cache balance", zap.Error(err))
	}
}

// GetBalance gets inventory balance for a product
func (s *InventoryService) GetBalance(ctx context.Context, productID int64, warehouseID int64, unitID int64) (*dto.InventoryBalanceResponse, error) {
	balance, err := s.repo.GetInventoryBalance(ctx, productID, warehouseID, unitID)
	if err != nil {
		if err.Error() == "inventory balance not found" {
			return nil, errors.NewNotFoundError("Inventory balance")
		}
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToInventoryBalanceResponse(*balance), nil
}

// ListTransactions lists inventory transactions
func (s *InventoryService) ListTransactions(ctx context.Context, req dto.ListInventoryTransactionsRequest) (*dto.ListResponse, error) {
	offset := (req.Page - 1) * req.PageSize

	transactions, err := s.repo.ListInventoryTransactions(ctx, repository.ListInventoryTransactionsParams{
		WarehouseID:     toNullInt64(req.WarehouseID),
		ProductID:       toNullInt64(req.ProductID),
		TransactionType: toNullString(req.TransactionType),
		FromDate:        toNullTime(req.FromDate),
		ToDate:          toNullTime(req.ToDate),
		Limit:           int32(req.PageSize),
		Offset:          int32(offset),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.InventoryTransactionResponse
	for _, txn := range transactions {
		responses = append(responses, *s.mapToInventoryTransactionResponse(txn))
	}

	// For simplicity, not counting total
	pagination := dto.NewPaginationResponse(req.Page, req.PageSize, int64(len(responses)))
	return dto.NewListResponse(responses, pagination), nil
}

// ListWarrantyClaims lists warranty claims
func (s *InventoryService) ListWarrantyClaims(ctx context.Context, req dto.ListWarrantyClaimsRequest) (*dto.ListResponse, error) {
	offset := (req.Page - 1) * req.PageSize

	claims, err := s.repo.ListWarrantyClaims(ctx, repository.ListWarrantyClaimsParams{
		WarrantyCardNumber: toNullString(req.WarrantyCardNumber),
		RxOrderID:          toNullInt64(req.RxOrderID),
		Status:             toNullString(req.Status),
		Limit:              int32(req.PageSize),
		Offset:             int32(offset),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.WarrantyClaimResponse
	for _, claim := range claims {
		responses = append(responses, *s.mapToWarrantyClaimResponse(claim))
	}

	pagination := dto.NewPaginationResponse(req.Page, req.PageSize, int64(len(responses)))
	return dto.NewListResponse(responses, pagination), nil
}

func (s *InventoryService) mapToInventoryBalanceResponse(balance repository.InventoryBalance) *dto.InventoryBalanceResponse {
	return &dto.InventoryBalanceResponse{
		ID:                balance.ID,
		ProductID:         balance.ProductID,
		WarehouseID:       balance.WarehouseID,
		UnitID:            balance.UnitID,
		QuantityOnHand:    balance.QuantityOnHand,
		QuantityReserved:  balance.QuantityReserved,
		QuantityAvailable: balance.QuantityAvailable,
		LastUpdated:       balance.LastUpdated,
	}
}

func (s *InventoryService) mapToInventoryTransactionResponse(txn repository.InventoryTransaction) *dto.InventoryTransactionResponse {
	return &dto.InventoryTransactionResponse{
		ID:              txn.ID,
		WarehouseID:     txn.WarehouseID,
		ProductID:       txn.ProductID,
		UnitID:          txn.UnitID,
		Quantity:        txn.Quantity,
		QuantityChange:  txn.QuantityChange,
		BalanceAfter:    txn.BalanceAfter,
		TransactionType: txn.TransactionType,
		TransactionDate: txn.TransactionDate,
		ReferenceType:   fromNullString(txn.ReferenceType),
		ReferenceID:     fromNullInt64(txn.ReferenceID),
		Notes:           fromNullString(txn.Notes),
		Description:     fromNullString(txn.Description),
		CreatedAt:       txn.CreatedAt,
		CreatedBy:       txn.CreatedBy,
	}
}

func (s *InventoryService) mapToWarrantyClaimResponse(claim repository.WarrantyClaim) *dto.WarrantyClaimResponse {
	return &dto.WarrantyClaimResponse{
		ID:                 claim.ID,
		WarrantyCardNumber: claim.WarrantyCardNumber,
		RxOrderID:          nullInt64ToInt64(claim.RxOrderID),
		ClaimDate:          claim.ClaimDate,
		ClaimType:          claim.ClaimType,
		IssueDescription:   claim.IssueDescription,
		Resolution:         fromNullString(claim.Resolution),
		ResolvedAt:         fromNullTime(claim.ResolvedAt),
		Status:             claim.Status,
		CreatedAt:          claim.CreatedAt,
	}
}
