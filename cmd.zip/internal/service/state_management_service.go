package service

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"rx-st-system/internal/dto"
	"rx-st-system/internal/repository"
	"rx-st-system/pkg/errors"
	"rx-st-system/pkg/logger"

	"github.com/jackc/pgx/v5/pgxpool"
	"go.uber.org/zap"
)

// StateManagementService handles all state machine operations
type StateManagementService struct {
	repo repository.Querier
	db   *pgxpool.Pool
}

// NewStateManagementService creates a new state management service
func NewStateManagementService(repo repository.Querier, db *pgxpool.Pool) *StateManagementService {
	return &StateManagementService{
		repo: repo,
		db:   db,
	}
}

// CreateState creates a new state
func (s *StateManagementService) CreateState(ctx context.Context, req dto.CreateStateRequest) (*dto.StateManagementStateResponse, error) {
	state, err := s.repo.CreateState(ctx, repository.CreateStateParams{
		StateCode:    req.StateCode,
		StateName:    req.StateName,
		StateType:    req.StateType,
		Description:  toNullString(req.Description),
		Color:        toNullString(req.Color),
		Icon:         toNullString(req.Icon),
		DisplayOrder: req.DisplayOrder,
		IsActive:     req.IsActive,
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToStateResponse(&state), nil
}

// GetState retrieves a state by ID
func (s *StateManagementService) GetState(ctx context.Context, id int64) (*dto.StateManagementStateResponse, error) {
	state, err := s.repo.GetState(ctx, id)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.NewNotFoundError("State")
		}
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToStateResponse(&state), nil
}

// ListStates lists all states of a specific type
func (s *StateManagementService) ListStates(ctx context.Context, stateType string) ([]dto.StateManagementStateResponse, error) {
	states, err := s.repo.ListStatesByType(ctx, sql.NullString{String: stateType, Valid: stateType != ""})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.StateManagementStateResponse
	for _, state := range states {
		responses = append(responses, *s.mapToStateResponse(&state))
	}

	return responses, nil
}

// UpdateState updates an existing state
func (s *StateManagementService) UpdateState(ctx context.Context, id int64, req dto.UpdateStateRequest) (*dto.StateManagementStateResponse, error) {
	state, err := s.repo.UpdateState(ctx, repository.UpdateStateParams{
		ID:           id,
		StateName:    toNullString(req.StateName),
		Description:  toNullString(req.Description),
		Color:        toNullString(req.Color),
		Icon:         toNullString(req.Icon),
		DisplayOrder: toNullInt32FromInt32Ptr(req.DisplayOrder),
		IsActive:     toNullBool(req.IsActive),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToStateResponse(&state), nil
}

// DeleteState deletes a state
func (s *StateManagementService) DeleteState(ctx context.Context, id int64) error {
	if err := s.repo.DeleteState(ctx, id); err != nil {
		return errors.NewDatabaseError(err)
	}
	return nil
}

// CreateStateTransition creates a new state transition
func (s *StateManagementService) CreateStateTransition(ctx context.Context, req dto.CreateStateTransitionRequest) (*dto.StateTransitionDetailResponse, error) {
	transition, err := s.repo.CreateStateTransition(ctx, repository.CreateStateTransitionParams{
		FromStateID:         req.FromStateID,
		ToStateID:           req.ToStateID,
		TransitionName:      req.TransitionName,
		Description:         toNullString(req.Description),
		RequiresApproval:    req.RequiresApproval,
		RequiresComment:     req.RequiresComment,
		AutoTransition:      req.AutoTransition,
		TransitionCondition: toNullString(req.TransitionCondition),
		DisplayOrder:        req.DisplayOrder,
		IsActive:            req.IsActive,
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToTransitionResponse(ctx, &transition)
}

// GetStateTransition retrieves a state transition by ID
func (s *StateManagementService) GetStateTransition(ctx context.Context, id int64) (*dto.StateTransitionDetailResponse, error) {
	transition, err := s.repo.GetStateTransition(ctx, id)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.NewNotFoundError("State Transition")
		}
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToTransitionResponse(ctx, &transition)
}

// ListStateTransitions lists all transitions from a specific state
func (s *StateManagementService) ListStateTransitions(ctx context.Context, fromStateID int64) ([]dto.StateTransitionDetailResponse, error) {
	transitions, err := s.repo.ListStateTransitionsWithDetails(ctx, repository.ListStateTransitionsWithDetailsParams{
		FromStateID: fromStateID,
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.StateTransitionDetailResponse
	for _, transition := range transitions {
		resp, err := s.mapToTransitionResponseFromList(ctx, transition)
		if err != nil {
			logger.Error("Failed to map transition", zap.Error(err))
			continue
		}
		responses = append(responses, *resp)
	}

	return responses, nil
}

// UpdateStateTransition updates an existing state transition
func (s *StateManagementService) UpdateStateTransition(ctx context.Context, id int64, req dto.UpdateStateTransitionRequest) (*dto.StateTransitionDetailResponse, error) {
	transition, err := s.repo.UpdateStateTransition(ctx, repository.UpdateStateTransitionParams{
		ID:                  id,
		TransitionName:      toNullString(req.TransitionName),
		Description:         toNullString(req.Description),
		RequiresApproval:    toNullBool(req.RequiresApproval),
		RequiresComment:     toNullBool(req.RequiresComment),
		AutoTransition:      toNullBool(req.AutoTransition),
		TransitionCondition: toNullString(req.TransitionCondition),
		DisplayOrder:        toNullInt32FromInt32Ptr(req.DisplayOrder),
		IsActive:            toNullBool(req.IsActive),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToTransitionResponse(ctx, &transition)
}

// DeleteStateTransition deletes a state transition
func (s *StateManagementService) DeleteStateTransition(ctx context.Context, id int64) error {
	if err := s.repo.DeleteStateTransition(ctx, id); err != nil {
		return errors.NewDatabaseError(err)
	}
	return nil
}

// CreateStateTransitionPermission creates permission for a state transition
func (s *StateManagementService) CreateStateTransitionPermission(ctx context.Context, req dto.CreateStateTransitionPermissionRequest) (*dto.StateTransitionPermissionResponse, error) {
	permission, err := s.repo.CreateStateTransitionPermission(ctx, repository.CreateStateTransitionPermissionParams{
		TransitionID:   req.TransitionID,
		PermissionType: req.PermissionType,
		UserID:         toNullInt64(req.UserID),
		GroupID:        toNullInt64(req.GroupID),
		RoleID:         toNullInt64(req.RoleID),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return &dto.StateTransitionPermissionResponse{
		ID:             permission.ID,
		TransitionID:   permission.TransitionID,
		PermissionType: permission.PermissionType,
		UserID:         fromNullInt64(permission.UserID),
		GroupID:        fromNullInt64(permission.GroupID),
		RoleID:         fromNullInt64(permission.RoleID),
		CreatedAt:      permission.CreatedAt,
	}, nil
}

// GetAvailableTransitions gets available transitions for an entity
func (s *StateManagementService) GetAvailableTransitions(ctx context.Context, req dto.GetAvailableTransitionsRequest) (*dto.GetAvailableTransitionsResponse, error) {
	// Get current state of the entity
	var currentStateID int64
	if req.EntityType == "rx_order" {
		order, err := s.repo.GetRxOrder(ctx, req.EntityID)
		if err != nil {
			return nil, errors.NewNotFoundError("RX Order")
		}
		currentStateID = order.CurrentStateID
	} else {
		order, err := s.repo.GetStOrder(ctx, req.EntityID)
		if err != nil {
			return nil, errors.NewNotFoundError("ST Order")
		}
		currentStateID = order.CurrentStateID
	}

	currentState, err := s.repo.GetState(ctx, currentStateID)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Get available transitions from current state
	transitions, err := s.repo.ListAvailableTransitions(ctx, currentStateID)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Filter by user permissions
	var availableTransitions []dto.StateTransitionDetailResponse
	for _, transition := range transitions {
		hasPermission, err := s.repo.CheckUserTransitionPermission(ctx, repository.CheckUserTransitionPermissionParams{
			TransitionID: transition.ID,
			Column2:      req.UserID,
		})
		if err != nil || !hasPermission {
			continue
		}

		fromState, _ := s.repo.GetState(ctx, transition.FromStateID)
		toState, _ := s.repo.GetState(ctx, transition.ToStateID)

		availableTransitions = append(availableTransitions, dto.StateTransitionDetailResponse{
			ID:                  transition.ID,
			FromState:           s.mapToStateResponse(&fromState),
			ToState:             s.mapToStateResponse(&toState),
			TransitionName:      transition.TransitionName,
			Description:         fromNullString(transition.Description),
			RequiresApproval:    transition.RequiresApproval,
			RequiresComment:     transition.RequiresComment,
			AutoTransition:      transition.AutoTransition,
			TransitionCondition: fromNullString(transition.TransitionCondition),
			DisplayOrder:        transition.DisplayOrder,
			IsActive:            transition.IsActive,
			CreatedAt:           transition.CreatedAt,
		})
	}

	return &dto.GetAvailableTransitionsResponse{
		EntityType:           req.EntityType,
		EntityID:             req.EntityID,
		CurrentState:         s.mapToStateResponse(&currentState),
		AvailableTransitions: availableTransitions,
	}, nil
}

// ExecuteTransition executes a state transition for an entity
func (s *StateManagementService) ExecuteTransition(ctx context.Context, req dto.ExecuteTransitionRequest, userID int64) (*dto.ExecuteTransitionResponse, error) {
	// Get current state
	var currentStateID int64
	if req.EntityType == "rx_order" {
		order, err := s.repo.GetRxOrder(ctx, req.EntityID)
		if err != nil {
			return nil, errors.NewNotFoundError("RX Order")
		}
		currentStateID = order.CurrentStateID
	} else {
		order, err := s.repo.GetStOrder(ctx, req.EntityID)
		if err != nil {
			return nil, errors.NewNotFoundError("ST Order")
		}
		currentStateID = order.CurrentStateID
	}

	// Get target state
	toState, err := s.repo.GetStateByCode(ctx, req.ToStateCode)
	if err != nil {
		return nil, errors.NewNotFoundError("State")
	}

	// Validate transition exists
	transition, err := s.repo.GetTransitionByStates(ctx, repository.GetTransitionByStatesParams{
		FromStateID: currentStateID,
		ToStateID:   toState.ID,
	})
	if err != nil {
		return nil, errors.NewValidationError("Invalid state transition", nil)
	}

	// Check permission
	hasPermission, err := s.repo.CheckUserTransitionPermission(ctx, repository.CheckUserTransitionPermissionParams{
		TransitionID: transition.ID,
		Column2:      userID,
	})
	if err != nil || !hasPermission {
		return nil, errors.NewForbiddenError("You don't have permission for this transition")
	}

	// Check if comment is required
	if transition.RequiresComment && (req.Comment == nil || *req.Comment == "") {
		return nil, errors.NewValidationError("Comment is required for this transition", nil)
	}

	// Start transaction
	tx, err := s.db.Begin(ctx)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}
	defer tx.Rollback(ctx)

	qtx := s.repo.WithTx(tx)

	// Update entity state
	if req.EntityType == "rx_order" {
		_, err = qtx.UpdateRxOrderState(ctx, repository.UpdateRxOrderStateParams{
			ID:             req.EntityID,
			CurrentStateID: toState.ID,
		})
	} else {
		_, err = qtx.UpdateStOrderState(ctx, repository.UpdateStOrderStateParams{
			ID:             req.EntityID,
			CurrentStateID: toState.ID,
		})
	}
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Create state history
	_, err = qtx.CreateStateHistory(ctx, repository.CreateStateHistoryParams{
		EntityType:  req.EntityType,
		EntityID:    req.EntityID,
		FromStateID: sql.NullInt64{Int64: currentStateID, Valid: true},
		ToStateID:   toState.ID,
		ChangedBy:   sql.NullInt64{Int64: userID, Valid: true},
		Comment:     toNullString(req.Comment),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Commit transaction
	if err := tx.Commit(ctx); err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	oldState, _ := s.repo.GetState(ctx, currentStateID)

	logger.Info("State transition executed",
		zap.String("entity_type", req.EntityType),
		zap.Int64("entity_id", req.EntityID),
		zap.String("from_state", oldState.StateCode),
		zap.String("to_state", toState.StateCode),
		zap.Int64("user_id", userID),
	)

	return &dto.ExecuteTransitionResponse{
		Success:    true,
		Message:    fmt.Sprintf("Successfully transitioned from %s to %s", oldState.StateName, toState.StateName),
		OldState:   s.mapToStateResponse(&oldState),
		NewState:   s.mapToStateResponse(&toState),
		ExecutedAt: time.Now(),
	}, nil
}

// ValidateTransition validates if a transition is possible
func (s *StateManagementService) ValidateTransition(ctx context.Context, req dto.ValidateTransitionRequest) (*dto.ValidateTransitionResponse, error) {
	// Get current state
	var currentStateID int64
	if req.EntityType == "rx_order" {
		order, err := s.repo.GetRxOrder(ctx, req.EntityID)
		if err != nil {
			return &dto.ValidateTransitionResponse{
				IsValid:       false,
				CanTransition: false,
				Message:       "Order not found",
			}, nil
		}
		currentStateID = order.CurrentStateID
	} else {
		order, err := s.repo.GetStOrder(ctx, req.EntityID)
		if err != nil {
			return &dto.ValidateTransitionResponse{
				IsValid:       false,
				CanTransition: false,
				Message:       "Order not found",
			}, nil
		}
		currentStateID = order.CurrentStateID
	}

	// Get target state
	toState, err := s.repo.GetStateByCode(ctx, req.ToStateCode)
	if err != nil {
		return &dto.ValidateTransitionResponse{
			IsValid:       false,
			CanTransition: false,
			Message:       "Target state not found",
		}, nil
	}

	// Check if transition exists
	transition, err := s.repo.GetTransitionByStates(ctx, repository.GetTransitionByStatesParams{
		FromStateID: currentStateID,
		ToStateID:   toState.ID,
	})
	if err != nil {
		return &dto.ValidateTransitionResponse{
			IsValid:       false,
			CanTransition: false,
			Message:       "Invalid state transition",
		}, nil
	}

	// Check permission
	hasPermission, _ := s.repo.CheckUserTransitionPermission(ctx, repository.CheckUserTransitionPermissionParams{
		TransitionID: transition.ID,
		Column2:      req.UserID,
	})

	return &dto.ValidateTransitionResponse{
		IsValid:          true,
		CanTransition:    hasPermission,
		HasPermission:    hasPermission,
		RequiresApproval: transition.RequiresApproval,
		RequiresComment:  transition.RequiresComment,
		Message:          "Transition is valid",
	}, nil
}

// GetStateHistory retrieves the state change history for an entity
func (s *StateManagementService) GetStateHistory(ctx context.Context, req dto.GetStateHistoryRequest) ([]dto.StateHistoryDetailResponse, error) {
	history, err := s.repo.GetStateHistoryByEntity(ctx, repository.GetStateHistoryByEntityParams{
		EntityType: req.EntityType,
		EntityID:   req.EntityID,
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.StateHistoryDetailResponse
	for _, item := range history {
		var fromState *dto.StateManagementStateResponse
		if item.FromStateID.Valid {
			fs, _ := s.repo.GetState(ctx, item.FromStateID.Int64)
			if &fs != nil {
				fromState = s.mapToStateResponse(&fs)
			}
		}

		toState, _ := s.repo.GetState(ctx, item.ToStateID)

		// Calculate duration
		var duration *int64
		if fromState != nil {
			durationSec, _ := s.repo.CalculateStateDuration(ctx, repository.CalculateStateDurationParams{
				EntityType: item.EntityType,
				EntityID:   item.EntityID,
				Column3:    item.ID,
			})
			if durationSec > 0 {
				duration = &durationSec
			}
		}

		responses = append(responses, dto.StateHistoryDetailResponse{
			ID:            item.ID,
			EntityType:    item.EntityType,
			EntityID:      item.EntityID,
			FromState:     fromState,
			ToState:       s.mapToStateResponse(&toState),
			ChangedBy:     fromNullInt64(item.ChangedBy),
			ChangedByName: fromNullString(item.ChangedByName),
			Comment:       fromNullString(item.Comment),
			Duration:      duration,
			ChangeDate:    item.ChangeDate,
		})
	}

	return responses, nil
}

// GetStateStatistics retrieves state statistics
func (s *StateManagementService) GetStateStatistics(ctx context.Context, req dto.StateStatisticsRequest) (*dto.StateStatisticsResponse, error) {
	var fromDate, toDate sql.NullTime
	if req.FromDate != nil {
		parsed, _ := time.Parse("2006-01-02", *req.FromDate)
		fromDate = sql.NullTime{Time: parsed, Valid: true}
	}
	if req.ToDate != nil {
		parsed, _ := time.Parse("2006-01-02", *req.ToDate)
		toDate = sql.NullTime{Time: parsed, Valid: true}
	}

	// Get state distribution
	var distribution []dto.StateDistribution
	var totalCount int64

	if req.EntityType == "rx_order" {
		dist, err := s.repo.GetStateDistributionRx(ctx, repository.GetStateDistributionRxParams{
			FromDate: fromDate,
			ToDate:   toDate,
		})
		if err == nil {
			for _, item := range dist {
				totalCount += item.Count
				state, _ := s.repo.GetState(ctx, item.ID)
				distribution = append(distribution, dto.StateDistribution{
					State:      s.mapToStateResponse(&state),
					Count:      item.Count,
					Percentage: 0,
				})
			}
		}
	} else {
		dist, err := s.repo.GetStateDistributionSt(ctx, repository.GetStateDistributionStParams{
			FromDate: fromDate,
			ToDate:   toDate,
		})
		if err == nil {
			for _, item := range dist {
				totalCount += item.Count
				state, _ := s.repo.GetState(ctx, item.ID)
				distribution = append(distribution, dto.StateDistribution{
					State:      s.mapToStateResponse(&state),
					Count:      item.Count,
					Percentage: 0,
				})
			}
		}
	}

	// Calculate percentages
	for i := range distribution {
		if totalCount > 0 {
			distribution[i].Percentage = float64(distribution[i].Count) / float64(totalCount) * 100
		}
	}

	// Get transition statistics
	transStats, err := s.repo.GetTransitionStatistics(ctx, repository.GetTransitionStatisticsParams{
		EntityType: req.EntityType,
		FromDate:   fromDate,
		ToDate:     toDate,
	})
	var transitionStats []dto.TransitionStatistics
	if err == nil {
		for _, stat := range transStats {
			avgDuration := 0.0
			if stat.AvgDurationSeconds.Valid {
				avgDuration = stat.AvgDurationSeconds.Float64
			}
			transitionStats = append(transitionStats, dto.TransitionStatistics{
				TransitionID:    stat.TransitionID,
				TransitionName:  stat.TransitionName,
				UsageCount:      stat.UsageCount,
				AverageDuration: avgDuration,
			})
		}
	}

	// Get average durations
	avgDurations, err := s.repo.GetAverageStateDuration(ctx, repository.GetAverageStateDurationParams{
		EntityType: req.EntityType,
		FromDate:   fromDate,
		ToDate:     toDate,
	})
	avgDurationMap := make(map[string]float64)
	if err == nil {
		for _, item := range avgDurations {
			avgDurationMap[item.StateCode] = item.AvgDurationSeconds
		}
	}

	return &dto.StateStatisticsResponse{
		EntityType:        req.EntityType,
		TotalEntities:     totalCount,
		StateDistribution: distribution,
		TransitionStats:   transitionStats,
		AverageDuration:   avgDurationMap,
	}, nil
}

// BulkTransition performs bulk state transition
func (s *StateManagementService) BulkTransition(ctx context.Context, req dto.BulkTransitionRequest, userID int64) (*dto.BulkTransitionResponse, error) {
	toState, err := s.repo.GetStateByCode(ctx, req.ToStateCode)
	if err != nil {
		return nil, errors.NewNotFoundError("State")
	}

	results := []dto.BulkTransitionResult{}
	successCount := 0
	failedCount := 0

	for _, entityID := range req.EntityIDs {
		executeReq := dto.ExecuteTransitionRequest{
			EntityType:  req.EntityType,
			EntityID:    entityID,
			ToStateCode: req.ToStateCode,
			Comment:     req.Comment,
		}

		_, err := s.ExecuteTransition(ctx, executeReq, userID)
		if err != nil {
			failedCount++
			errMsg := err.Error()
			results = append(results, dto.BulkTransitionResult{
				EntityID: entityID,
				Success:  false,
				Error:    &errMsg,
			})
		} else {
			successCount++
			results = append(results, dto.BulkTransitionResult{
				EntityID: entityID,
				Success:  true,
				Message:  "Transitioned successfully",
			})
		}
	}

	return &dto.BulkTransitionResponse{
		SuccessCount: successCount,
		FailedCount:  failedCount,
		TotalCount:   len(req.EntityIDs),
		Results:      results,
	}, nil
}

// GetStateMachineConfig retrieves complete state machine configuration
func (s *StateManagementService) GetStateMachineConfig(ctx context.Context, entityType string) (*dto.StateMachineConfigResponse, error) {
	// Get all states
	states, err := s.repo.ListStates(ctx)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var stateResponses []dto.StateManagementStateResponse
	var initialState *dto.StateManagementStateResponse
	var finalStates []dto.StateManagementStateResponse

	for _, state := range states {
		stateResp := s.mapToStateResponse(&state)
		stateResponses = append(stateResponses, *stateResp)

		if state.StateType == "initial" && initialState == nil {
			initialState = stateResp
		}
		if state.StateType == "final" {
			finalStates = append(finalStates, *stateResp)
		}
	}

	// Get all transitions
	transitions, err := s.repo.ListStateTransitionsWithDetails(ctx, repository.ListStateTransitionsWithDetailsParams{
		FromStateID: 0,
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var transitionResponses []dto.StateTransitionDetailResponse
	for _, transition := range transitions {
		resp, err := s.mapToTransitionResponseFromList(ctx, transition)
		if err == nil {
			transitionResponses = append(transitionResponses, *resp)
		}
	}

	return &dto.StateMachineConfigResponse{
		EntityType:   entityType,
		States:       stateResponses,
		Transitions:  transitionResponses,
		InitialState: initialState,
		FinalStates:  finalStates,
	}, nil
}

// Helper methods
func (s *StateManagementService) mapToStateResponse(state *repository.State) *dto.StateManagementStateResponse {
	if state == nil {
		return nil
	}
	return &dto.StateManagementStateResponse{
		ID:           state.ID,
		StateCode:    state.StateCode,
		StateName:    state.StateName,
		StateType:    state.StateType,
		Description:  fromNullString(state.Description),
		Color:        fromNullString(state.Color),
		Icon:         fromNullString(state.Icon),
		DisplayOrder: state.DisplayOrder,
		IsActive:     state.IsActive,
		CreatedAt:    state.CreatedAt,
	}
}

func (s *StateManagementService) mapToTransitionResponse(ctx context.Context, transition *repository.StateTransition) (*dto.StateTransitionDetailResponse, error) {
	fromState, _ := s.repo.GetState(ctx, transition.FromStateID)
	toState, _ := s.repo.GetState(ctx, transition.ToStateID)

	return &dto.StateTransitionDetailResponse{
		ID:                  transition.ID,
		FromState:           s.mapToStateResponse(&fromState),
		ToState:             s.mapToStateResponse(&toState),
		TransitionName:      transition.TransitionName,
		Description:         fromNullString(transition.Description),
		RequiresApproval:    transition.RequiresApproval,
		RequiresComment:     transition.RequiresComment,
		AutoTransition:      transition.AutoTransition,
		TransitionCondition: fromNullString(transition.TransitionCondition),
		DisplayOrder:        transition.DisplayOrder,
		IsActive:            transition.IsActive,
		CreatedAt:           transition.CreatedAt,
	}, nil
}

func (s *StateManagementService) mapToTransitionResponseFromList(ctx context.Context, transition repository.ListStateTransitionsWithDetailsRow) (*dto.StateTransitionDetailResponse, error) {
	fromState, _ := s.repo.GetState(ctx, transition.FromStateID)
	toState, _ := s.repo.GetState(ctx, transition.ToStateID)

	return &dto.StateTransitionDetailResponse{
		ID:                  transition.ID,
		FromState:           s.mapToStateResponse(&fromState),
		ToState:             s.mapToStateResponse(&toState),
		TransitionName:      transition.TransitionName,
		Description:         fromNullString(transition.Description),
		RequiresApproval:    transition.RequiresApproval,
		RequiresComment:     transition.RequiresComment,
		AutoTransition:      transition.AutoTransition,
		TransitionCondition: fromNullString(transition.TransitionCondition),
		DisplayOrder:        transition.DisplayOrder,
		IsActive:            transition.IsActive,
		CreatedAt:           transition.CreatedAt,
	}, nil
}
