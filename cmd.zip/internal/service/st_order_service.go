package service

import (
	"context"
	"database/sql"
	"time"

	"rx-st-system/internal/dto"
	"rx-st-system/internal/repository"
	"rx-st-system/pkg/errors"

	"github.com/jackc/pgx/v5/pgxpool"
)

// StOrderService handles ST order business logic
type StOrderService struct {
	repo             repository.Querier
	db               *pgxpool.Pool
	productService   *ProductService
	inventoryService *InventoryService
}

// NewStOrderService creates a new StOrderService
func NewStOrderService(repo repository.Querier, db *pgxpool.Pool, productService *ProductService, inventoryService *InventoryService) *StOrderService {
	return &StOrderService{
		repo:             repo,
		db:               db,
		productService:   productService,
		inventoryService: inventoryService,
	}
}

func (s *StOrderService) Create(ctx context.Context, req dto.CreateStOrderRequest, userID int64) (*dto.StOrderResponse, error) {
	// Generate order number
	orderNumber, err := s.repo.GetNextStOrderNumber(ctx)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Get initial state
	initialState, err := s.repo.GetStateByCode(ctx, "draft", "st")
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var createdOrderID int64
	var totalItemsPrice float64

	// استفاده صحیح از WithTx
	err = s.repo.WithTx(ctx, func(txRepo *repository.Repository) error {
		// Create order
		order, err := txRepo.CreateStOrder(ctx, repository.CreateStOrderParams{
			OrderNumber:       orderNumber,
			CustomerID:        req.CustomerID,
			State:             "draft",
			UseCuttingService: req.UseCuttingService,
			CuttingServiceID:  toNullInt64(req.CuttingServiceID),
			ItemsPrice:        sql.NullFloat64{Float64: 0, Valid: true},
			ServicePrice:      sql.NullFloat64{Float64: req.ServicePrice, Valid: true},
			TotalPrice:        sql.NullFloat64{Float64: 0, Valid: true},
			CurrentStateID:    sql.NullInt64{Int64: initialState.ID, Valid: true},
			Notes:             toNullString(req.Notes),
			ExpectedDate:      toNullTime(req.ExpectedDate),
			CreatedBy:         sql.NullInt64{Int64: userID, Valid: true},
		})
		if err != nil {
			return err
		}

		createdOrderID = order.ID

		// Add pair items
		if req.PairItems != nil {
			for _, item := range req.PairItems {
				itemTotal := float64(item.Quantity) * item.UnitPrice
				totalItemsPrice += itemTotal

				err := txRepo.CreateStOrderPairItem(ctx, repository.CreateStOrderPairItemParams{
					StOrderID:  order.ID,
					ProductID:  item.ProductID,
					RightSPH:   item.RightSPH,
					RightCYL:   toNullFloat64(item.RightCYL),
					LeftSPH:    item.LeftSPH,
					LeftCYL:    toNullFloat64(item.LeftCYL),
					Quantity:   item.Quantity,
					UnitPrice:  sql.NullFloat64{Float64: item.UnitPrice, Valid: true},
					TotalPrice: sql.NullFloat64{Float64: itemTotal, Valid: true},
				})
				if err != nil {
					return err
				}
			}
		}

		// Add single items
		if req.SingleItems != nil {
			for _, item := range req.SingleItems {
				itemTotal := float64(item.Quantity) * item.UnitPrice
				totalItemsPrice += itemTotal

				err := txRepo.CreateStOrderSingleItem(ctx, repository.CreateStOrderSingleItemParams{
					StOrderID:  order.ID,
					ProductID:  item.ProductID,
					SPH:        item.SPH,
					CYL:        toNullFloat64(item.CYL),
					Quantity:   item.Quantity,
					UnitPrice:  sql.NullFloat64{Float64: item.UnitPrice, Valid: true},
					TotalPrice: sql.NullFloat64{Float64: itemTotal, Valid: true},
				})
				if err != nil {
					return err
				}
			}
		}

		// Update pricing
		totalPrice := totalItemsPrice + req.ServicePrice
		err = txRepo.UpdateStOrderPricing(ctx, repository.UpdateStOrderPricingParams{
			ID:           order.ID,
			ItemsPrice:   sql.NullFloat64{Float64: totalItemsPrice, Valid: true},
			ServicePrice: sql.NullFloat64{Float64: req.ServicePrice, Valid: true},
			TotalPrice:   sql.NullFloat64{Float64: totalPrice, Valid: true},
		})
		if err != nil {
			return err
		}

		// Create state history
		err = txRepo.CreateStOrderStateHistory(ctx, repository.CreateStOrderStateHistoryParams{
			StOrderID: order.ID,
			FromState: sql.NullString{Valid: false},
			ToState:   "draft",
			ChangedBy: userID,
			Notes:     sql.NullString{String: "Order created", Valid: true},
		})
		if err != nil {
			return err
		}

		return nil
	})

	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Get full order details
	return s.GetByID(ctx, createdOrderID)
}

// GetByID gets ST order by ID
func (s *StOrderService) GetByID(ctx context.Context, id int64) (*dto.StOrderResponse, error) {
	order, err := s.repo.GetStOrder(ctx, id)
	if err != nil {
		if err.Error() == "st order not found" {
			return nil, errors.NewNotFoundError("ST Order")
		}
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToStOrderResponse(*order), nil
}

// List lists ST orders with pagination
func (s *StOrderService) List(ctx context.Context, req dto.ListStOrdersRequest) (*dto.ListResponse, error) {
	offset := (req.Page - 1) * req.PageSize

	orders, err := s.repo.ListStOrders(ctx, repository.ListStOrdersParams{
		Search:     sql.NullString{String: req.Search, Valid: req.Search != ""},
		CustomerID: toNullInt64(req.CustomerID),
		State:      toNullString(req.State),
		StateID:    toNullInt64(req.StateID),
		FromDate:   toNullTime(req.FromDate),
		ToDate:     toNullTime(req.ToDate),
		Limit:      int32(req.PageSize),
		Offset:     int32(offset),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	total, err := s.repo.CountStOrders(ctx, repository.CountStOrdersParams{
		Search:     sql.NullString{String: req.Search, Valid: req.Search != ""},
		CustomerID: toNullInt64(req.CustomerID),
		StateID:    toNullInt64(req.StateID),
		FromDate:   toNullTime(req.FromDate),
		ToDate:     toNullTime(req.ToDate),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.StOrderResponse
	for _, order := range orders {
		responses = append(responses, *s.mapToStOrderResponse(order))
	}

	pagination := dto.NewPaginationResponse(req.Page, req.PageSize, total)
	return dto.NewListResponse(responses, pagination), nil
}

// Update updates an ST order
func (s *StOrderService) Update(ctx context.Context, id int64, req dto.UpdateStOrderRequest) (*dto.StOrderResponse, error) {
	_, err := s.repo.GetStOrder(ctx, id)
	if err != nil {
		if err.Error() == "st order not found" {
			return nil, errors.NewNotFoundError("ST Order")
		}
		return nil, errors.NewDatabaseError(err)
	}

	_, err = s.repo.UpdateStOrder(ctx, repository.UpdateStOrderParams{
		ID:                id,
		UseCuttingService: toNullBool(&req.UseCuttingService),
		CuttingServiceID:  toNullInt64(req.CuttingServiceID),
		Notes:             toNullString(req.Notes),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.GetByID(ctx, id)
}

// Delete deletes an ST order
func (s *StOrderService) Delete(ctx context.Context, id int64) error {
	_, err := s.repo.GetStOrder(ctx, id)
	if err != nil {
		if err.Error() == "st order not found" {
			return errors.NewNotFoundError("ST Order")
		}
		return errors.NewDatabaseError(err)
	}

	if err := s.repo.DeleteStOrder(ctx, id); err != nil {
		return errors.NewDatabaseError(err)
	}

	return nil
}

// ChangeState changes order state
func (s *StOrderService) ChangeState(ctx context.Context, id int64, newStateCode string, userID int64, notes *string) error {
	order, err := s.repo.GetStOrder(ctx, id)
	if err != nil {
		return errors.NewDatabaseError(err)
	}

	newState, err := s.repo.GetStateByCode(ctx, newStateCode, "st")
	if err != nil {
		return errors.NewNotFoundError("State")
	}

	var oldStateCode string
	if order.CurrentStateID.Valid {
		oldState, _ := s.repo.GetState(ctx, order.CurrentStateID.Int64)
		if oldState != nil {
			oldStateCode = oldState.StateCode
		}
	}

	err = s.repo.WithTx(ctx, func(txRepo *repository.Repository) error {
		// Update order state
		err := txRepo.UpdateStOrderState(ctx, repository.UpdateStOrderStateParams{
			ID:      id,
			StateID: newState.ID,
		})
		if err != nil {
			return err
		}

		// Create history
		err = txRepo.CreateStOrderStateHistory(ctx, repository.CreateStOrderStateHistoryParams{
			StOrderID: id,
			FromState: sql.NullString{String: oldStateCode, Valid: oldStateCode != ""},
			ToState:   newStateCode,
			ChangedBy: userID,
			Notes:     toNullString(notes),
		})
		if err != nil {
			return err
		}

		return nil
	})

	if err != nil {
		return errors.NewDatabaseError(err)
	}

	return nil
}

func (s *StOrderService) mapToStOrderResponse(order repository.StOrder) *dto.StOrderResponse {
	return &dto.StOrderResponse{
		ID:                order.ID,
		OrderNumber:       order.OrderNumber,
		CustomerID:        order.CustomerID,
		CurrentState:      order.State,
		UseCuttingService: order.UseCuttingService,
		ItemsPrice:        nullFloat64ToFloat64(order.ItemsPrice),
		ServicePrice:      nullFloat64ToFloat64(order.ServicePrice),
		TotalPrice:        nullFloat64ToFloat64(order.TotalPrice),
		Notes:             fromNullString(order.Notes),
		CreatedAt:         order.CreatedAt,
		UpdatedAt:         order.UpdatedAt,
	}
}

// CreateWarrantyClaim creates a warranty claim
func (s *StOrderService) CreateWarrantyClaim(ctx context.Context, req dto.CreateWarrantyClaimRequest, userID int64) (*dto.WarrantyClaimResponse, error) {
	// Parse claim date
	claimDate, err := time.Parse("2006-01-02", req.ClaimDate)
	if err != nil {
		return nil, errors.NewValidationError("Invalid claim date format", nil)
	}

	// Create claim
	claim, err := s.repo.CreateWarrantyClaim(ctx, repository.CreateWarrantyClaimParams{
		WarrantyCardID: req.WarrantyCardID,
		ClaimType:      req.ClaimType,
		Description:    req.Description,
		ClaimDate:      claimDate,
		Status:         "pending",
		CreatedBy:      sql.NullInt64{Int64: userID, Valid: true},
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return &dto.WarrantyClaimResponse{
		ID:          claim.ID,
		ClaimType:   claim.ClaimType,
		Description: claim.Description,
		ClaimDate:   claim.ClaimDate,
		Status:      claim.Status,
		CreatedBy:   fromNullInt64(claim.CreatedBy),
		CreatedAt:   claim.CreatedAt,
	}, nil
}

// GetWarrantyCardByNumber gets warranty card by number
func (s *StOrderService) GetWarrantyCardByNumber(ctx context.Context, cardNumber string) (*dto.WarrantyCardResponse, error) {
	card, err := s.repo.GetWarrantyCardByNumber(ctx, cardNumber)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.NewNotFoundError("Warranty Card")
		}
		return nil, errors.NewDatabaseError(err)
	}

	return &dto.WarrantyCardResponse{
		ID:            card.ID,
		CardNumber:    card.CardNumber,
		PatientName:   card.PatientName,
		PatientMobile: card.PatientMobile,
		ReceiptNumber: fromNullString(card.ReceiptNumber),
		IssueDate:     card.IssueDate,
		ExpiryDate:    card.ExpiryDate,
		IsActive:      card.IsActive,
	}, nil
}

// ListWarrantyClaims lists warranty claims
func (s *StOrderService) ListWarrantyClaims(ctx context.Context, warrantyCardID int64, status string, page, pageSize int) (*dto.ListResponse, error) {
	offset := (page - 1) * pageSize

	claims, err := s.repo.ListWarrantyClaims(ctx, repository.ListWarrantyClaimsParams{
		WarrantyCardID: warrantyCardID,
		Status:         sql.NullString{String: status, Valid: status != ""},
		Limit:          int32(pageSize),
		Offset:         int32(offset),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.WarrantyClaimResponse
	for _, claim := range claims {
		responses = append(responses, dto.WarrantyClaimResponse{
			ID:          claim.ID,
			ClaimType:   claim.ClaimType,
			Description: claim.Description,
			ClaimDate:   claim.ClaimDate,
			Status:      claim.Status,
			Resolution:  fromNullString(claim.Resolution),
			ResolvedAt:  fromNullTime(claim.ResolvedAt),
			ResolvedBy:  fromNullInt64(claim.ResolvedBy),
			CreatedBy:   fromNullInt64(claim.CreatedBy),
			CreatedAt:   claim.CreatedAt,
		})
	}

	pagination := dto.NewPaginationResponse(page, pageSize, int64(len(responses)))
	return dto.NewListResponse(responses, pagination), nil
}

// GetSummary gets ST orders summary
func (s *StOrderService) GetSummary(ctx context.Context) (*dto.StOrderSummaryResponse, error) {
	// This should aggregate data from database
	// For now, return placeholder
	return &dto.StOrderSummaryResponse{
		TotalOrders:         0,
		DraftOrders:         0,
		PendingSupplyOrders: 0,
		ReadyToShipOrders:   0,
		TotalValue:          0,
		TotalQuantity:       0,
	}, nil
}
