package service

import (
	"context"
	"database/sql"
	"time"

	"rx-st-system/internal/dto"
	"rx-st-system/internal/repository"
	"rx-st-system/pkg/errors"

	"github.com/golang-jwt/jwt/v5"
	"golang.org/x/crypto/bcrypt"
)

// AuthService handles authentication logic
type AuthService struct {
	repo               repository.Querier
	jwtSecret          string
	accessTokenExpiry  time.Duration
	refreshTokenExpiry time.Duration
	maxFailedAttempts  int
	lockDuration       time.Duration
}

// NewAuthService creates a new AuthService
func NewAuthService(
	repo repository.Querier,
	jwtSecret string,
	accessTokenExpiry time.Duration,
	refreshTokenExpiry time.Duration,
) *AuthService {
	return &AuthService{
		repo:               repo,
		jwtSecret:          jwtSecret,
		accessTokenExpiry:  accessTokenExpiry,
		refreshTokenExpiry: refreshTokenExpiry,
		maxFailedAttempts:  5,
		lockDuration:       30 * time.Minute,
	}
}

// Login authenticates a user
func (s *AuthService) Login(ctx context.Context, req dto.LoginRequest, ipAddress, userAgent string) (*dto.LoginResponse, error) {
	// Get user by username
	user, err := s.repo.GetUserByUsername(ctx, req.Username)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.NewUnauthorizedError("Invalid credentials")
		}
		return nil, errors.NewDatabaseError(err)
	}

	// Check if user is locked
	if user.LockedUntil.Valid && user.LockedUntil.Valid && user.LockedUntil.Time.After(time.Now()) {
		return nil, errors.NewAppError(
			errors.ErrCodeUserLocked,
			"Account is temporarily locked. Please try again later.",
			nil,
		)
	}

	// Verify password
	if err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.Password)); err != nil {
		// Increment failed login attempts
		failedAttempts := user.FailedLoginAttempts + 1
		var lockedUntil sql.NullTime

		if failedAttempts >= int32(s.maxFailedAttempts) {
			lockedUntil = sql.NullTime{
				Time:  time.Now().Add(s.lockDuration),
				Valid: true,
			}
		}

		_ = s.repo.UpdateUserFailedLoginAttempts(ctx, repository.UpdateUserFailedLoginAttemptsParams{
			ID:                  user.ID,
			FailedLoginAttempts: failedAttempts,
			LockedUntil:         lockedUntil,
		})

		return nil, errors.NewUnauthorizedError("Invalid credentials")
	}

	// Check if user is active
	if !user.IsActive {
		return nil, errors.NewUnauthorizedError("Account is not active")
	}

	// Check if user is approved
	if !user.IsApproved {
		return nil, errors.NewAppError(
			errors.ErrCodeUserNotApproved,
			"Account is pending approval",
			nil,
		)
	}

	// Generate tokens
	accessToken, err := s.generateAccessToken(user.ID, user.Username, user.IsSystemAdmin)
	if err != nil {
		return nil, errors.NewInternalError(err)
	}

	refreshToken, err := s.generateRefreshToken(user.ID)
	if err != nil {
		return nil, errors.NewInternalError(err)
	}

	// Create session
	_, err = s.repo.CreateUserSession(ctx, repository.CreateUserSessionParams{
		UserID:       user.ID,
		SessionToken: refreshToken,
		IpAddress:    sql.NullString{String: ipAddress, Valid: ipAddress != ""},
		UserAgent:    sql.NullString{String: userAgent, Valid: userAgent != ""},
		ExpiresAt:    time.Now().Add(s.refreshTokenExpiry),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Update last login
	_ = s.repo.UpdateUserLastLogin(ctx, repository.UpdateUserLastLoginParams{
		ID:        user.ID,
		LastLogin: sql.NullTime{Time: time.Now(), Valid: true},
	})

	return &dto.LoginResponse{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		TokenType:    "Bearer",
		ExpiresIn:    int64(s.accessTokenExpiry.Seconds()),
		User: &dto.UserInfo{
			ID:            user.ID,
			Username:      user.Username,
			EntityID:      user.EntityID.Int64,
			MobileNumber:  user.MobileNumber.String,
			Email:         &user.Email.String,
			IsSystemAdmin: user.IsSystemAdmin,
			IsActive:      user.IsActive,
			IsApproved:    user.IsApproved,
			LastLogin:     &user.LastLogin.Time,
		},
	}, nil
}

// Register creates a new user account
func (s *AuthService) Register(ctx context.Context, req dto.RegisterRequest) (*dto.RegisterResponse, error) {
	// Check if username already exists
	existingUser, err := s.repo.GetUserByUsername(ctx, req.Username)
	if err == nil && existingUser != nil {
		return nil, errors.NewConflictError("Username already exists")
	}

	// Check if mobile number already exists
	existingUser, err = s.repo.GetUserByMobileNumber(ctx, req.MobileNumber)
	if err == nil && existingUser != nil {
		return nil, errors.NewConflictError("Mobile number already exists")
	}

	// Hash password
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.Password), 12)
	if err != nil {
		return nil, errors.NewInternalError(err)
	}

	// Create user
	user, err := s.repo.CreateUser(ctx, repository.CreateUserParams{
		EntityID:      sql.NullInt64{Int64: req.EntityID, Valid: req.EntityID != 0},
		Username:      req.Username,
		PasswordHash:  string(hashedPassword),
		MobileNumber:  sql.NullString{String: req.MobileNumber, Valid: req.MobileNumber != ""},
		Email:         sql.NullString{String: req.Email, Valid: req.Email != ""},
		IsSystemAdmin: false,
		IsActive:      false,
		IsApproved:    false,
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return &dto.RegisterResponse{
		Message: "Registration successful. Your account is pending approval.",
		UserID:  user.ID,
	}, nil
}

// Logout invalidates a user session
func (s *AuthService) Logout(ctx context.Context, sessionToken string) error {
	if err := s.repo.DeleteUserSession(ctx, sessionToken); err != nil {
		return errors.NewDatabaseError(err)
	}
	return nil
}

// RefreshToken refreshes an access token
func (s *AuthService) RefreshToken(ctx context.Context, refreshToken string) (*dto.LoginResponse, error) {
	// Get session
	session, err := s.repo.GetUserSession(ctx, refreshToken)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.NewUnauthorizedError("Invalid refresh token")
		}
		return nil, errors.NewDatabaseError(err)
	}

	// Get user
	user, err := s.repo.GetUserByID(ctx, session.UserID)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Check if user is still active and approved
	if !user.IsActive || !user.IsApproved {
		return nil, errors.NewUnauthorizedError("Account is not active")
	}

	// Generate new access token
	accessToken, err := s.generateAccessToken(user.ID, user.Username, user.IsSystemAdmin)
	if err != nil {
		return nil, errors.NewInternalError(err)
	}

	// Update session activity
	_ = s.repo.UpdateUserSessionActivity(ctx, session.SessionToken)

	return &dto.LoginResponse{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		TokenType:    "Bearer",
		ExpiresIn:    int64(s.accessTokenExpiry.Seconds()),
		User: &dto.UserInfo{
			ID:            user.ID,
			Username:      user.Username,
			EntityID:      user.EntityID.Int64,
			MobileNumber:  user.MobileNumber.String,
			Email:         &user.Email.String,
			IsSystemAdmin: user.IsSystemAdmin,
			IsActive:      user.IsActive,
			IsApproved:    user.IsApproved,
		},
	}, nil
}

// ChangePassword changes user password
func (s *AuthService) ChangePassword(ctx context.Context, userID int64, req dto.ChangePasswordRequest) error {
	// Get user
	user, err := s.repo.GetUserByID(ctx, userID)
	if err != nil {
		return errors.NewDatabaseError(err)
	}

	// Verify old password
	if err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.OldPassword)); err != nil {
		return errors.NewUnauthorizedError("Invalid old password")
	}

	// Hash new password
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.NewPassword), 12)
	if err != nil {
		return errors.NewInternalError(err)
	}

	// Update password
	if err := s.repo.UpdateUserPassword(ctx, repository.UpdateUserPasswordParams{
		ID:              userID,
		NewPasswordHash: string(hashedPassword),
	}); err != nil {
		return errors.NewDatabaseError(err)
	}

	// Invalidate all user sessions
	_ = s.repo.DeleteUserSessions(ctx, userID)

	return nil
}

// ApproveUser approves a user account
func (s *AuthService) ApproveUser(ctx context.Context, adminID, userID int64, approved bool) error {

	_, err := s.repo.UpdateUser(ctx, repository.UpdateUserParams{
		ID:         userID,
		IsApproved: true,
		IsActive:   true, //sql.NullBool{Bool: approved, Valid: true},
		ApprovedBy: sql.NullInt64{Int64: adminID, Valid: true},
		ApprovedAt: sql.NullTime{Time: time.Now(), Valid: true},
	})
	if err != nil {
		return errors.NewDatabaseError(err)
	}

	return nil
}

// ValidateToken validates a JWT token
func (s *AuthService) ValidateToken(tokenString string) (*jwt.MapClaims, error) {
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, errors.NewUnauthorizedError("Invalid signing method")
		}
		return []byte(s.jwtSecret), nil
	})

	if err != nil {
		return nil, errors.NewAppError(errors.ErrCodeInvalidToken, "Invalid token", err)
	}

	if !token.Valid {
		return nil, errors.NewAppError(errors.ErrCodeInvalidToken, "Invalid token", nil)
	}

	claims, ok := token.Claims.(jwt.MapClaims)
	if !ok {
		return nil, errors.NewAppError(errors.ErrCodeInvalidToken, "Invalid token claims", nil)
	}

	return &claims, nil
}

// CheckPermission checks if user has a specific permission
func (s *AuthService) CheckPermission(ctx context.Context, userID int64, permissionCode string) (bool, error) {
	result, err := s.repo.CheckUserPermission(ctx, repository.CheckUserPermissionParams{
		UserID:         userID,
		PermissionCode: permissionCode,
	})
	if err != nil {
		return false, errors.NewDatabaseError(err)
	}

	return result, nil
}

// generateAccessToken generates a JWT access token
func (s *AuthService) generateAccessToken(userID int64, username string, isAdmin bool) (string, error) {
	claims := jwt.MapClaims{
		"user_id":  userID,
		"username": username,
		"is_admin": isAdmin,
		"exp":      time.Now().Add(s.accessTokenExpiry).Unix(),
		"iat":      time.Now().Unix(),
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(s.jwtSecret))
}

// generateRefreshToken generates a refresh token
func (s *AuthService) generateRefreshToken(userID int64) (string, error) {
	claims := jwt.MapClaims{
		"user_id": userID,
		"exp":     time.Now().Add(s.refreshTokenExpiry).Unix(),
		"iat":     time.Now().Unix(),
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(s.jwtSecret))
}
