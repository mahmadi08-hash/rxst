package service

import (
	"context"
	"database/sql"

	"rx-st-system/internal/dto"
	"rx-st-system/internal/repository"
	"rx-st-system/pkg/errors"

	"github.com/jackc/pgx/v5/pgxpool"
)

// EntityService handles entity business logic
type EntityService struct {
	repo repository.Querier
	db   *pgxpool.Pool
}

// NewEntityService creates a new EntityService
func NewEntityService(repo repository.Querier, db *pgxpool.Pool) *EntityService {
	return &EntityService{
		repo: repo,
		db:   db,
	}
}

// Create creates a new entity
func (s *EntityService) Create(ctx context.Context, req dto.CreateEntityRequest, userID int64) (*dto.EntityResponse, error) {
	// Validate entity type specific fields
	if err := s.validateEntityFields(req); err != nil {
		return nil, err
	}

	// Check if code already exists
	existingEntity, err := s.repo.GetEntityByCode(ctx, req.Code)
	if err == nil && existingEntity != nil {
		return nil, errors.NewConflictError("Entity code already exists")
	}

	// متغیرهای خارج از transaction برای نگه‌داری نتیجه
	var createdEntityID int64

	// استفاده صحیح از WithTx
	err = s.repo.WithTx(ctx, func(txRepo *repository.Repository) error {
		// Create entity
		entity, err := txRepo.CreateEntity(ctx, repository.CreateEntityParams{
			EntityType:         req.EntityType,
			Code:               req.Code,
			SecondaryCode:      toNullString(req.SecondaryCode),
			FirstName:          toNullString(req.FirstName),
			LastName:           toNullString(req.LastName),
			CompanyName:        toNullString(req.CompanyName),
			NationalID:         toNullString(req.NationalID),
			RegistrationNumber: toNullString(req.RegistrationNumber),
			Email:              toNullString(req.Email),
			IsActive:           req.IsActive,
			CreatedBy:          sql.NullInt64{Int64: userID, Valid: true},
		})
		if err != nil {
			return err // فقط error برمی‌گردانیم، نه nil و error
		}

		// ذخیره ID برای استفاده بعدی
		createdEntityID = entity.ID

		// Assign roles
		for _, roleID := range req.Roles {
			if err := txRepo.AssignEntityRole(ctx, repository.AssignEntityRoleParams{
				EntityID: entity.ID,
				RoleType: "", // اگر از جای دیگری می‌آید
				RoleID:   roleID,
			}); err != nil {
				return err
			}
		}

		// Create phones
		for _, phone := range req.Phones {
			if _, err := txRepo.CreateEntityPhone(ctx, repository.CreateEntityPhoneParams{
				EntityID:    entity.ID,
				PhoneNumber: phone.PhoneNumber,
				PhoneType:   *phone.PhoneType, // مستقیم string است
				IsPrimary:   phone.IsPrimary,
			}); err != nil {
				return err
			}
		}

		// Create addresses
		for _, address := range req.Addresses {
			if _, err := txRepo.CreateEntityAddress(ctx, repository.CreateEntityAddressParams{
				EntityID:    entity.ID,
				AddressType: toNullString(address.AddressType),
				Address:     address.AddressLine, // AddressLine به Address map می‌شود
				City:        toNullString(address.City),
				Province:    toNullString(address.Province),
				PostalCode:  toNullString(address.PostalCode),
				IsPrimary:   address.IsPrimary,
			}); err != nil {
				return err
			}
		}

		return nil // موفقیت - commit
	})

	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Get full entity details
	return s.GetByID(ctx, createdEntityID)
}

// GetByID gets entity by ID with all details
func (s *EntityService) GetByID(ctx context.Context, id int64) (*dto.EntityResponse, error) {
	entity, err := s.repo.GetEntity(ctx, id)
	if err != nil {
		if err.Error() == "entity not found" {
			return nil, errors.NewNotFoundError("Entity")
		}
		return nil, errors.NewDatabaseError(err)
	}

	// Get roles
	roles, err := s.repo.GetEntityRoles(ctx, id)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Get phones
	phones, err := s.repo.ListEntityPhones(ctx, id)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Get addresses
	addresses, err := s.repo.ListEntityAddresses(ctx, id)
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// entity یک pointer است، با * آن را dereference می‌کنیم
	return s.mapToEntityResponse(*entity, roles, phones, addresses), nil
}

// Update updates an entity
func (s *EntityService) Update(ctx context.Context, id int64, req dto.UpdateEntityRequest, userID int64) (*dto.EntityResponse, error) {
	// Check if entity exists
	_, err := s.repo.GetEntity(ctx, id)
	if err != nil {
		if err.Error() == "entity not found" {
			return nil, errors.NewNotFoundError("Entity")
		}
		return nil, errors.NewDatabaseError(err)
	}

	// Update entity
	_, err = s.repo.UpdateEntity(ctx, repository.UpdateEntityParams{
		ID:                 id,
		SecondaryCode:      toNullString(req.SecondaryCode),
		FirstName:          toNullString(req.FirstName),
		LastName:           toNullString(req.LastName),
		CompanyName:        toNullString(req.CompanyName),
		NationalID:         toNullString(req.NationalID),
		RegistrationNumber: toNullString(req.RegistrationNumber),
		Email:              toNullString(req.Email),
		IsActive:           getBoolValue(req.IsActive), // مستقیم bool
		UpdatedBy:          sql.NullInt64{Int64: userID, Valid: true},
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.GetByID(ctx, id)
}

// Delete deletes an entity
func (s *EntityService) Delete(ctx context.Context, id int64) error {
	// Check if entity exists
	_, err := s.repo.GetEntity(ctx, id)
	if err != nil {
		if err.Error() == "entity not found" {
			return errors.NewNotFoundError("Entity")
		}
		return errors.NewDatabaseError(err)
	}

	// Delete entity (cascade will delete related records)
	if err := s.repo.DeleteEntity(ctx, id); err != nil {
		return errors.NewDatabaseError(err)
	}

	return nil
}

// List lists entities with pagination
func (s *EntityService) List(ctx context.Context, req dto.ListEntitiesRequest) (*dto.ListResponse, error) {
	offset := (req.Page - 1) * req.PageSize

	// Get entities
	entities, err := s.repo.ListEntities(ctx, repository.ListEntitiesParams{
		Search:     sql.NullString{String: req.Search, Valid: req.Search != ""},
		EntityType: sql.NullString{String: req.EntityType, Valid: req.EntityType != ""},
		IsActive:   toNullBool(req.IsActive),
		Limit:      int32(req.PageSize),
		Offset:     int32(offset),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Get total count
	total, err := s.repo.CountEntities(ctx, repository.CountEntitiesParams{
		Search:     sql.NullString{String: req.Search, Valid: req.Search != ""},
		EntityType: sql.NullString{String: req.EntityType, Valid: req.EntityType != ""},
		IsActive:   toNullBool(req.IsActive),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	// Map to response
	var responses []dto.EntityResponse
	for _, entity := range entities {
		responses = append(responses, dto.EntityResponse{
			ID:                 entity.ID,
			EntityType:         entity.EntityType,
			Code:               entity.Code,
			SecondaryCode:      fromNullString(entity.SecondaryCode),
			FirstName:          fromNullString(entity.FirstName),
			LastName:           fromNullString(entity.LastName),
			CompanyName:        fromNullString(entity.CompanyName),
			NationalID:         fromNullString(entity.NationalID),
			RegistrationNumber: fromNullString(entity.RegistrationNumber),
			Email:              fromNullString(entity.Email),
			IsActive:           entity.IsActive,
			CreatedAt:          entity.CreatedAt,
			UpdatedAt:          entity.UpdatedAt,
		})
	}

	pagination := dto.NewPaginationResponse(req.Page, req.PageSize, total)
	return dto.NewListResponse(responses, pagination), nil
}

// AssignRole assigns a role to entity
func (s *EntityService) AssignRole(ctx context.Context, entityID, roleID int64) error {
	if err := s.repo.AssignEntityRole(ctx, repository.AssignEntityRoleParams{
		EntityID: entityID,
		RoleType: "", // TODO: دریافت از جدول roles
		RoleID:   roleID,
	}); err != nil {
		return errors.NewDatabaseError(err)
	}
	return nil
}

// RemoveRole removes a role from entity
func (s *EntityService) RemoveRole(ctx context.Context, entityID, roleID int64) error {
	if err := s.repo.RemoveEntityRole(ctx, repository.RemoveEntityRoleParams{
		EntityID: entityID,
		RoleType: "", // TODO: دریافت از جدول roles
		RoleID:   roleID,
	}); err != nil {
		return errors.NewDatabaseError(err)
	}
	return nil
}

// AddPhone adds a phone to entity
func (s *EntityService) AddPhone(ctx context.Context, entityID int64, req dto.CreateEntityPhoneRequest) (*dto.EntityPhoneResponse, error) {
	phone, err := s.repo.CreateEntityPhone(ctx, repository.CreateEntityPhoneParams{
		EntityID:    entityID,
		PhoneNumber: req.PhoneNumber,
		PhoneType:   *req.PhoneType, // مستقیم string
		IsPrimary:   req.IsPrimary,
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return &dto.EntityPhoneResponse{
		ID:          phone.ID,
		PhoneNumber: phone.PhoneNumber,
		PhoneType:   &phone.PhoneType, // مستقیم string
		IsPrimary:   phone.IsPrimary,
		CreatedAt:   phone.CreatedAt,
	}, nil
}

// DeletePhone deletes a phone from entity
func (s *EntityService) DeletePhone(ctx context.Context, phoneID int64) error {
	if err := s.repo.DeleteEntityPhone(ctx, phoneID); err != nil {
		return errors.NewDatabaseError(err)
	}
	return nil
}

// AddAddress adds an address to entity
func (s *EntityService) AddAddress(ctx context.Context, entityID int64, req dto.CreateEntityAddressRequest) (*dto.EntityAddressResponse, error) {
	address, err := s.repo.CreateEntityAddress(ctx, repository.CreateEntityAddressParams{
		EntityID:    entityID,
		AddressType: toNullString(req.AddressType),
		Address:     req.AddressLine, // AddressLine به Address
		City:        toNullString(req.City),
		Province:    toNullString(req.Province),
		PostalCode:  toNullString(req.PostalCode),
		IsPrimary:   req.IsPrimary,
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return &dto.EntityAddressResponse{
		ID:          address.ID,
		AddressType: &address.AddressType.String, // sql.NullString به string
		Country:     fromNullString(address.Country),
		Province:    fromNullString(address.Province),
		City:        fromNullString(address.City),
		PostalCode:  fromNullString(address.PostalCode),
		AddressLine: nullStringToString(address.AddressLine), // sql.NullString به string
		IsPrimary:   address.IsPrimary,
		CreatedAt:   address.CreatedAt,
	}, nil
}

// DeleteAddress deletes an address from entity
func (s *EntityService) DeleteAddress(ctx context.Context, addressID int64) error {
	if err := s.repo.DeleteEntityAddress(ctx, addressID); err != nil {
		return errors.NewDatabaseError(err)
	}
	return nil
}

// GetEntitiesWithRole gets entities by role
func (s *EntityService) GetEntitiesWithRole(ctx context.Context, roleCode string, page, pageSize int) (*dto.ListResponse, error) {
	offset := (page - 1) * pageSize

	entities, err := s.repo.GetEntitiesWithRole(ctx, repository.GetEntitiesWithRoleParams{
		RoleType: "",
		RoleCode: roleCode,
		Limit:    int32(pageSize),
		Offset:   int32(offset),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.EntityResponse
	for _, entity := range entities {
		responses = append(responses, dto.EntityResponse{
			ID:            entity.ID,
			EntityType:    entity.EntityType,
			Code:          entity.Code,
			SecondaryCode: fromNullString(entity.SecondaryCode),
			FirstName:     fromNullString(entity.FirstName),
			LastName:      fromNullString(entity.LastName),
			CompanyName:   fromNullString(entity.CompanyName),
			IsActive:      entity.IsActive,
			CreatedAt:     entity.CreatedAt,
			UpdatedAt:     entity.UpdatedAt,
		})
	}

	// For simplicity, not counting total here
	pagination := dto.NewPaginationResponse(page, pageSize, int64(len(responses)))
	return dto.NewListResponse(responses, pagination), nil
}

// validateEntityFields validates entity type specific fields
func (s *EntityService) validateEntityFields(req dto.CreateEntityRequest) error {
	if req.EntityType == "person" {
		if req.FirstName == nil || *req.FirstName == "" {
			return errors.NewValidationError("First name is required for person", nil)
		}
		if req.LastName == nil || *req.LastName == "" {
			return errors.NewValidationError("Last name is required for person", nil)
		}
	} else if req.EntityType == "company" {
		if req.CompanyName == nil || *req.CompanyName == "" {
			return errors.NewValidationError("Company name is required for company", nil)
		}
	}
	return nil
}

// mapToEntityResponse maps repository entity to DTO
func (s *EntityService) mapToEntityResponse(
	entity repository.Entity, // نه pointer، value
	roles []repository.EntityRole,
	phones []repository.EntityPhone,
	addresses []repository.EntityAddress,
) *dto.EntityResponse {
	response := &dto.EntityResponse{
		ID:                 entity.ID,
		EntityType:         entity.EntityType,
		Code:               entity.Code,
		SecondaryCode:      fromNullString(entity.SecondaryCode),
		FirstName:          fromNullString(entity.FirstName),
		LastName:           fromNullString(entity.LastName),
		CompanyName:        fromNullString(entity.CompanyName),
		NationalID:         fromNullString(entity.NationalID),
		RegistrationNumber: fromNullString(entity.RegistrationNumber),
		Email:              fromNullString(entity.Email),
		IsActive:           entity.IsActive,
		CreatedAt:          entity.CreatedAt,
		UpdatedAt:          entity.UpdatedAt,
	}

	// Map roles
	for _, role := range roles {
		response.Roles = append(response.Roles, dto.EntityRoleResponse{
			ID:          role.ID,
			RoleName:    nullStringToString(role.RoleName), // sql.NullString به string
			RoleCode:    nullStringToString(role.RoleCode), // sql.NullString به string
			Description: fromNullString(role.Description),  // sql.NullString به *string
		})
	}

	// Map phones
	for _, phone := range phones {
		response.Phones = append(response.Phones, dto.EntityPhoneResponse{
			ID:          phone.ID,
			PhoneNumber: phone.PhoneNumber,
			PhoneType:   &phone.PhoneType, // مستقیم string
			IsPrimary:   phone.IsPrimary,
			CreatedAt:   phone.CreatedAt,
		})
	}

	// Map addresses
	for _, address := range addresses {
		response.Addresses = append(response.Addresses, dto.EntityAddressResponse{
			ID:          address.ID,
			AddressType: &address.AddressType.String, // sql.NullString به string
			Country:     fromNullString(address.Country),
			Province:    fromNullString(address.Province),
			City:        fromNullString(address.City),
			PostalCode:  fromNullString(address.PostalCode),
			AddressLine: nullStringToString(address.AddressLine), // sql.NullString به string
			IsPrimary:   address.IsPrimary,
			CreatedAt:   address.CreatedAt,
		})
	}

	return response
}
