package service

import (
	"context"
	"database/sql"

	"rx-st-system/internal/dto"
	"rx-st-system/internal/repository"
	"rx-st-system/pkg/errors"

	"github.com/jackc/pgx/v5/pgxpool"
)

// ProductService handles product business logic
type ProductService struct {
	repo repository.Querier
	db   *pgxpool.Pool
}

// NewProductService creates a new ProductService
func NewProductService(repo repository.Querier, db *pgxpool.Pool) *ProductService {
	return &ProductService{
		repo: repo,
		db:   db,
	}
}

// Create creates a new product
func (s *ProductService) Create(ctx context.Context, req dto.CreateProductRequest, userID int64) (*dto.ProductResponse, error) {
	// Validate product type specific fields
	if err := s.validateProductFields(req); err != nil {
		return nil, err
	}

	// Check if code already exists
	existing, err := s.repo.GetProductByCode(ctx, req.Code)
	if err == nil && existing != nil {
		return nil, errors.NewConflictError("Product code already exists")
	}

	// Create product
	product, err := s.repo.CreateProduct(ctx, repository.CreateProductParams{
		Code:                req.Code,
		SecondaryCode:       toNullString(req.SecondaryCode),
		FinancialSystemCode: toNullString(req.FinancialSystemCode),
		Name:                req.Name,
		ProductType:         req.ProductType,
		LensBrandID:         toNullInt64(req.LensBrandID),
		LensTypeID:          toNullInt64(req.LensTypeID),
		LensIndexID:         toNullInt64(req.LensIndexID),
		LensMaterialID:      toNullInt64(req.LensMaterialID),
		LensColorID:         toNullInt64(req.LensColorID),
		LensDesignID:        toNullInt64(req.LensDesignID),
		LensCoatingID:       toNullInt64(req.LensCoatingID),
		LensSph:             toNullFloat64(req.LensSPH),
		LensCyl:             toNullFloat64(req.LensCYL),
		LensBase:            toNullFloat64(req.LensBase),
		Direction:           toNullString(req.Direction),
		ServiceType:         toNullString(req.ServiceType),
		BaseUnitID:          toNullInt64(req.BaseUnitID),
		IsActive:            req.IsActive,
		CreatedBy:           sql.NullInt64{Int64: userID, Valid: true},
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.GetByID(ctx, product.ID)
}

// GetByID gets product by ID
func (s *ProductService) GetByID(ctx context.Context, id int64) (*dto.ProductResponse, error) {
	product, err := s.repo.GetProduct(ctx, id)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.NewNotFoundError("Product")
		}
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToProductResponse(ctx, *product)
}

// Update updates a product
func (s *ProductService) Update(ctx context.Context, id int64, req dto.UpdateProductRequest, userID int64) (*dto.ProductResponse, error) {
	// Check if product exists
	_, err := s.repo.GetProduct(ctx, id)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.NewNotFoundError("Product")
		}
		return nil, errors.NewDatabaseError(err)
	}

	// Update product
	_, err = s.repo.UpdateProduct(ctx, repository.UpdateProductParams{
		ID:                  id,
		SecondaryCode:       toNullString(req.SecondaryCode),
		FinancialSystemCode: toNullString(req.FinancialSystemCode),
		Name:                toNullString(req.Name),
		IsActive:            toNullBool(req.IsActive),
		UpdatedBy:           userID,
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	return s.GetByID(ctx, id)
}

// Delete deletes a product
func (s *ProductService) Delete(ctx context.Context, id int64) error {
	if err := s.repo.DeleteProduct(ctx, id); err != nil {
		return errors.NewDatabaseError(err)
	}
	return nil
}

// List lists products with pagination
func (s *ProductService) List(ctx context.Context, req dto.ListProductsRequest) (*dto.ListResponse, error) {
	offset := (req.Page - 1) * req.PageSize

	products, err := s.repo.ListProducts(ctx, repository.ListProductsParams{
		ProductType: sql.NullString{String: req.ProductType, Valid: req.ProductType != ""},
		LensBrandID: req.LensBrandID,
		Search:      sql.NullString{String: req.Search, Valid: req.Search != ""},
		Limit:       int32(req.PageSize),
		Offset:      int32(offset),
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	total, err := s.repo.CountProducts(ctx, repository.CountProductsParams{
		ProductType: sql.NullString{String: req.ProductType, Valid: req.ProductType != ""},
		LensBrandID: req.LensBrandID,
		Search:      sql.NullString{String: req.Search, Valid: req.Search != ""},
	})
	if err != nil {
		return nil, errors.NewDatabaseError(err)
	}

	var responses []dto.ProductResponse
	for _, product := range products {
		resp, err := s.mapToProductResponse(ctx, product)
		if err != nil {
			continue
		}
		responses = append(responses, *resp)
	}

	pagination := dto.NewPaginationResponse(req.Page, req.PageSize, total)
	return dto.NewListResponse(responses, pagination), nil
}

// FindRxProduct finds an RX product by its specifications
func (s *ProductService) FindRxProduct(ctx context.Context, req dto.FindRxProductRequest) (*dto.ProductResponse, error) {
	product, err := s.repo.FindRxProduct(ctx, repository.FindRxProductParams{
		LensBrandID:    req.LensBrandID,
		LensTypeID:     req.LensTypeID,
		LensIndexID:    req.LensIndexID,
		LensMaterialID: req.LensMaterialID,
		LensColorID:    toNullInt64(req.LensColorID),
		LensDesignID:   req.LensDesignID,
	})
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.NewNotFoundError("RX Product")
		}
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToProductResponse(ctx, *product)
}

// FindStProduct finds an ST product by its specifications
func (s *ProductService) FindStProduct(ctx context.Context, req dto.FindStProductRequest) (*dto.ProductResponse, error) {
	product, err := s.repo.FindStProduct(ctx, repository.FindStProductParams{
		LensBrandID:   req.LensBrandID,
		LensIndexID:   req.LensIndexID,
		LensCoatingID: toNullInt64(req.LensCoatingID),
		LensSph:       req.LensSPH,
		LensCyl:       req.LensCYL,
	})
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.NewNotFoundError("ST Product")
		}
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToProductResponse(ctx, *product)
}

// FindSemiFinishedProduct finds a semi-finished product
func (s *ProductService) FindSemiFinishedProduct(ctx context.Context, req dto.FindSemiFinishedProductRequest) (*dto.ProductResponse, error) {
	product, err := s.repo.FindSemiFinishedProduct(ctx, repository.FindSemiFinishedProductParams{
		LensBrandID:    req.LensBrandID,
		LensIndexID:    req.LensIndexID,
		LensMaterialID: req.LensMaterialID,
		LensColorID:    toNullInt64(req.LensColorID),
		LensBase:       req.LensBase,
		Direction:      req.Direction,
	})
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.NewNotFoundError("Semi-finished Product")
		}
		return nil, errors.NewDatabaseError(err)
	}

	return s.mapToProductResponse(ctx, *product)
}

// validateProductFields validates product type specific fields
func (s *ProductService) validateProductFields(req dto.CreateProductRequest) error {
	switch req.ProductType {
	case "rx_lens":
		if req.LensBrandID == nil || req.LensTypeID == nil || req.LensIndexID == nil ||
			req.LensMaterialID == nil || req.LensDesignID == nil {
			return errors.NewValidationError("RX lens requires brand, type, index, material, and design", nil)
		}
	case "st_lens":
		if req.LensBrandID == nil || req.LensIndexID == nil {
			return errors.NewValidationError("ST lens requires brand and index", nil)
		}
	case "semi_finished":
		if req.LensBrandID == nil || req.LensIndexID == nil || req.LensMaterialID == nil ||
			req.LensBase == nil || req.Direction == nil {
			return errors.NewValidationError("Semi-finished requires brand, index, material, base, and direction", nil)
		}
	case "service":
		if req.ServiceType == nil {
			return errors.NewValidationError("Service type is required for service products", nil)
		}
	}
	return nil
}

// mapToProductResponse maps repository product to DTO
func (s *ProductService) mapToProductResponse(ctx context.Context, product repository.Product) (*dto.ProductResponse, error) {
	response := &dto.ProductResponse{
		ID:                  product.ID,
		Code:                product.Code,
		SecondaryCode:       fromNullString(product.SecondaryCode),
		FinancialSystemCode: fromNullString(product.FinancialSystemCode),
		Name:                product.Name,
		ProductType:         product.ProductType,
		LensSPH:             fromNullFloat64(product.LensSPH),
		LensCYL:             fromNullFloat64(product.LensCYL),
		LensBase:            fromNullFloat64(product.LensBase),
		Direction:           fromNullString(product.Direction),
		ServiceType:         fromNullString(product.ServiceType),
		IsActive:            product.IsActive,
		CreatedAt:           product.CreatedAt,
		UpdatedAt:           product.UpdatedAt,
	}

	// Fetch related entities if needed
	if product.LensBrandID.Valid {
		brand, _ := s.repo.GetLensBrand(ctx, product.LensBrandID.Int64)
		response.LensBrand = &dto.LookupResponse{
			ID:   brand.ID,
			Code: brand.Code,
			Name: brand.Name,
		}
	}

	// Similar for other lookup fields...
	// (LensType, LensIndex, LensMaterial, etc.)

	return response, nil
}
