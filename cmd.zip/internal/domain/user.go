package domain

import "time"

// User represents a system user
type User struct {
	ID                   int64     `json:"id"`
	EntityID             int64     `json:"entity_id"`
	Username             string    `json:"username"`
	PasswordHash         string    `json:"-"` // Never expose password hash
	MobileNumber         string    `json:"mobile_number"`
	Email                *string   `json:"email,omitempty"`
	IsSystemAdmin        bool      `json:"is_system_admin"`
	IsActive             bool      `json:"is_active"`
	IsApproved           bool      `json:"is_approved"`
	ApprovedBy           *int64    `json:"approved_by,omitempty"`
	ApprovedAt           *time.Time `json:"approved_at,omitempty"`
	LastLogin            *time.Time `json:"last_login,omitempty"`
	FailedLoginAttempts  int       `json:"failed_login_attempts"`
	LockedUntil          *time.Time `json:"locked_until,omitempty"`
	PasswordChangedAt    *time.Time `json:"password_changed_at,omitempty"`
	CreatedAt            time.Time `json:"created_at"`
	UpdatedAt            time.Time `json:"updated_at"`
}

// UserSession represents a user session
type UserSession struct {
	ID           int64     `json:"id"`
	UserID       int64     `json:"user_id"`
	SessionToken string    `json:"session_token"`
	IPAddress    *string   `json:"ip_address,omitempty"`
	UserAgent    *string   `json:"user_agent,omitempty"`
	CreatedAt    time.Time `json:"created_at"`
	ExpiresAt    time.Time `json:"expires_at"`
	LastActivity time.Time `json:"last_activity"`
}

// Entity represents a person or company
type Entity struct {
	ID                 int64     `json:"id"`
	EntityType         string    `json:"entity_type"` // person, company
	Code               string    `json:"code"`
	SecondaryCode      *string   `json:"secondary_code,omitempty"`
	FirstName          *string   `json:"first_name,omitempty"`
	LastName           *string   `json:"last_name,omitempty"`
	CompanyName        *string   `json:"company_name,omitempty"`
	NationalID         *string   `json:"national_id,omitempty"`
	RegistrationNumber *string   `json:"registration_number,omitempty"`
	Email              *string   `json:"email,omitempty"`
	IsActive           bool      `json:"is_active"`
	CreatedBy          *int64    `json:"created_by,omitempty"`
	CreatedAt          time.Time `json:"created_at"`
	UpdatedBy          *int64    `json:"updated_by,omitempty"`
	UpdatedAt          time.Time `json:"updated_at"`
}

// EntityPhone represents a phone number for an entity
type EntityPhone struct {
	ID          int64     `json:"id"`
	EntityID    int64     `json:"entity_id"`
	PhoneNumber string    `json:"phone_number"`
	PhoneType   *string   `json:"phone_type,omitempty"` // mobile, landline, fax, other
	IsPrimary   bool      `json:"is_primary"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// EntityAddress represents an address for an entity
type EntityAddress struct {
	ID          int64     `json:"id"`
	EntityID    int64     `json:"entity_id"`
	AddressType *string   `json:"address_type,omitempty"` // home, work, billing, shipping, other
	Country     *string   `json:"country,omitempty"`
	Province    *string   `json:"province,omitempty"`
	City        *string   `json:"city,omitempty"`
	PostalCode  *string   `json:"postal_code,omitempty"`
	AddressLine string    `json:"address_line"`
	IsPrimary   bool      `json:"is_primary"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// Permission represents a system permission
type Permission struct {
	ID                 int64   `json:"id"`
	PermissionCode     string  `json:"permission_code"`
	PermissionName     string  `json:"permission_name"`
	PermissionCategory *string `json:"permission_category,omitempty"`
	Description        *string `json:"description,omitempty"`
	IsActive           bool    `json:"is_active"`
}

// Group represents a hierarchical group
type Group struct {
	ID             int64     `json:"id"`
	CategoryID     int64     `json:"category_id"`
	ParentID       *int64    `json:"parent_id,omitempty"`
	GroupName      string    `json:"group_name"`
	GroupCode      string    `json:"group_code"`
	Description    *string   `json:"description,omitempty"`
	HierarchyPath  *string   `json:"hierarchy_path,omitempty"`
	HierarchyLevel int       `json:"hierarchy_level"`
	IsActive       bool      `json:"is_active"`
	CreatedAt      time.Time `json:"created_at"`
	UpdatedAt      time.Time `json:"updated_at"`
}
