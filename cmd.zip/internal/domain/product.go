package domain

import "time"

// Product represents a product or service
type Product struct {
	ID                    int64     `json:"id"`
	Code                  string    `json:"code"`
	SecondaryCode         *string   `json:"secondary_code,omitempty"`
	FinancialSystemCode   *string   `json:"financial_system_code,omitempty"`
	Name                  string    `json:"name"`
	ProductType           string    `json:"product_type"` // rx_lens, st_lens, semi_finished, accessory, service, other
	
	// Lens specific fields
	LensBrandID           *int64    `json:"lens_brand_id,omitempty"`
	LensTypeID            *int64    `json:"lens_type_id,omitempty"`
	LensIndexID           *int64    `json:"lens_index_id,omitempty"`
	LensMaterialID        *int64    `json:"lens_material_id,omitempty"`
	LensColorID           *int64    `json:"lens_color_id,omitempty"`
	LensDesignID          *int64    `json:"lens_design_id,omitempty"`
	LensCoatingID         *int64    `json:"lens_coating_id,omitempty"`
	LensSPH               *float64  `json:"lens_sph,omitempty"`
	LensCYL               *float64  `json:"lens_cyl,omitempty"`
	
	// Semi-finished fields
	LensBase              *float64  `json:"lens_base,omitempty"`
	Direction             *string   `json:"direction,omitempty"` // left, right
	
	// Service specific
	ServiceType           *string   `json:"service_type,omitempty"` // cutting, color, production, extra, logistics, coating, priority, other
	
	BaseUnitID            *int64    `json:"base_unit_id,omitempty"`
	IsActive              bool      `json:"is_active"`
	CreatedBy             *int64    `json:"created_by,omitempty"`
	CreatedAt             time.Time `json:"created_at"`
	UpdatedBy             *int64    `json:"updated_by,omitempty"`
	UpdatedAt             time.Time `json:"updated_at"`
}

// LensBrand represents a lens brand
type LensBrand struct {
	ID          int64     `json:"id"`
	Code        string    `json:"code"`
	Name        string    `json:"name"`
	Description *string   `json:"description,omitempty"`
	IsActive    bool      `json:"is_active"`
	CreatedBy   *int64    `json:"created_by,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedBy   *int64    `json:"updated_by,omitempty"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// LensType represents a lens type
type LensType struct {
	ID          int64     `json:"id"`
	Code        string    `json:"code"`
	Name        string    `json:"name"`
	Description *string   `json:"description,omitempty"`
	IsActive    bool      `json:"is_active"`
	CreatedBy   *int64    `json:"created_by,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedBy   *int64    `json:"updated_by,omitempty"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// LensIndex represents a lens index
type LensIndex struct {
	ID          int64     `json:"id"`
	Code        string    `json:"code"`
	Name        string    `json:"name"`
	IndexValue  *float64  `json:"index_value,omitempty"`
	Description *string   `json:"description,omitempty"`
	IsActive    bool      `json:"is_active"`
	CreatedBy   *int64    `json:"created_by,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedBy   *int64    `json:"updated_by,omitempty"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// LensMaterial represents a lens material
type LensMaterial struct {
	ID          int64     `json:"id"`
	Code        string    `json:"code"`
	Name        string    `json:"name"`
	Description *string   `json:"description,omitempty"`
	IsActive    bool      `json:"is_active"`
	CreatedBy   *int64    `json:"created_by,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedBy   *int64    `json:"updated_by,omitempty"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// LensColor represents a lens color
type LensColor struct {
	ID          int64     `json:"id"`
	Code        string    `json:"code"`
	Name        string    `json:"name"`
	ColorHex    *string   `json:"color_hex,omitempty"`
	Description *string   `json:"description,omitempty"`
	IsActive    bool      `json:"is_active"`
	CreatedBy   *int64    `json:"created_by,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedBy   *int64    `json:"updated_by,omitempty"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// LensDesign represents a lens design
type LensDesign struct {
	ID          int64     `json:"id"`
	Code        string    `json:"code"`
	Name        string    `json:"name"`
	Description *string   `json:"description,omitempty"`
	IsActive    bool      `json:"is_active"`
	CreatedBy   *int64    `json:"created_by,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedBy   *int64    `json:"updated_by,omitempty"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// LensCoating represents a lens coating
type LensCoating struct {
	ID          int64     `json:"id"`
	Code        string    `json:"code"`
	Name        string    `json:"name"`
	Description *string   `json:"description,omitempty"`
	IsActive    bool      `json:"is_active"`
	CreatedBy   *int64    `json:"created_by,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedBy   *int64    `json:"updated_by,omitempty"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// UnitOfMeasure represents a unit of measure
type UnitOfMeasure struct {
	ID                  int64     `json:"id"`
	Code                string    `json:"code"`
	Name                string    `json:"name"`
	FinancialSystemCode *string   `json:"financial_system_code,omitempty"`
	IsActive            bool      `json:"is_active"`
	CreatedBy           *int64    `json:"created_by,omitempty"`
	CreatedAt           time.Time `json:"created_at"`
	UpdatedBy           *int64    `json:"updated_by,omitempty"`
	UpdatedAt           time.Time `json:"updated_at"`
}

// ProductUnitConversion represents unit conversion for a product
type ProductUnitConversion struct {
	ID               int64     `json:"id"`
	ProductID        int64     `json:"product_id"`
	FromUnitID       int64     `json:"from_unit_id"`
	ToUnitID         int64     `json:"to_unit_id"`
	ConversionFactor float64   `json:"conversion_factor"`
	IsDynamic        bool      `json:"is_dynamic"`
	IsActive         bool      `json:"is_active"`
	CreatedAt        time.Time `json:"created_at"`
}
