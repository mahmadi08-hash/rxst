package cache

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"rx-st-system/pkg/logger"

	gocache "github.com/patrickmn/go-cache"
	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"
)

// InventoryCache handles inventory caching with multi-layer strategy
type InventoryCache struct {
	localCache  *gocache.Cache
	redisClient *redis.Client
	localTTL    time.Duration
	redisTTL    time.Duration
}

// InventoryBalance represents cached inventory balance
type InventoryBalance struct {
	ProductID         int64     `json:"product_id"`
	WarehouseID       int64     `json:"warehouse_id"`
	UnitID            int64     `json:"unit_id"`
	QuantityOnHand    float64   `json:"quantity_on_hand"`
	QuantityReserved  float64   `json:"quantity_reserved"`
	QuantityAvailable float64   `json:"quantity_available"`
	LastUpdated       time.Time `json:"last_updated"`
}

// NewInventoryCache creates a new InventoryCache
func NewInventoryCache(redisClient *redis.Client, localTTL, redisTTL time.Duration) *InventoryCache {
	return &InventoryCache{
		localCache:  gocache.New(localTTL, 2*localTTL),
		redisClient: redisClient,
		localTTL:    localTTL,
		redisTTL:    redisTTL,
	}
}

// GetBalance gets inventory balance from cache (local -> redis -> db)
func (c *InventoryCache) GetBalance(ctx context.Context, warehouseID, productID, unitID int64) (*InventoryBalance, bool) {
	key := c.makeKey(warehouseID, productID, unitID)

	// Try local cache first (fastest)
	if balance, found := c.getFromLocal(key); found {
		logger.Debug("Inventory balance found in local cache",
			zap.String("key", key),
		)
		return balance, true
	}

	// Try Redis cache
	if balance, found := c.getFromRedis(ctx, key); found {
		// Store in local cache for next time
		c.setLocal(key, balance)
		logger.Debug("Inventory balance found in Redis cache",
			zap.String("key", key),
		)
		return balance, true
	}

	return nil, false
}

// SetBalance sets inventory balance in cache (local + redis)
func (c *InventoryCache) SetBalance(ctx context.Context, balance *InventoryBalance) error {
	key := c.makeKey(balance.WarehouseID, balance.ProductID, balance.UnitID)

	// Set in local cache
	c.setLocal(key, balance)

	// Set in Redis
	if err := c.setRedis(ctx, key, balance); err != nil {
		logger.Error("Failed to set balance in Redis",
			zap.Error(err),
			zap.String("key", key),
		)
		return err
	}

	logger.Debug("Inventory balance cached",
		zap.String("key", key),
		zap.Float64("available", balance.QuantityAvailable),
	)

	return nil
}

// InvalidateBalance invalidates cache for specific balance
func (c *InventoryCache) InvalidateBalance(ctx context.Context, warehouseID, productID, unitID int64) error {
	key := c.makeKey(warehouseID, productID, unitID)

	// Delete from local cache
	c.localCache.Delete(key)

	// Delete from Redis
	if err := c.redisClient.Del(ctx, key).Err(); err != nil {
		logger.Error("Failed to delete from Redis",
			zap.Error(err),
			zap.String("key", key),
		)
		return err
	}

	logger.Debug("Inventory balance invalidated",
		zap.String("key", key),
	)

	return nil
}

// InvalidateWarehouse invalidates all cache for a warehouse
func (c *InventoryCache) InvalidateWarehouse(ctx context.Context, warehouseID int64) error {
	pattern := fmt.Sprintf("inventory:warehouse:%d:*", warehouseID)

	// Clear local cache (iterate all keys)
	for key := range c.localCache.Items() {
		c.localCache.Delete(key)
	}

	// Clear Redis using scan
	iter := c.redisClient.Scan(ctx, 0, pattern, 100).Iterator()
	for iter.Next(ctx) {
		if err := c.redisClient.Del(ctx, iter.Val()).Err(); err != nil {
			logger.Error("Failed to delete key from Redis",
				zap.Error(err),
				zap.String("key", iter.Val()),
			)
		}
	}

	if err := iter.Err(); err != nil {
		return err
	}

	logger.Info("Warehouse inventory cache invalidated",
		zap.Int64("warehouse_id", warehouseID),
	)

	return nil
}

// InvalidateProduct invalidates all cache for a product
func (c *InventoryCache) InvalidateProduct(ctx context.Context, productID int64) error {
	pattern := fmt.Sprintf("inventory:warehouse:*:product:%d:*", productID)

	// Clear Redis using scan
	iter := c.redisClient.Scan(ctx, 0, pattern, 100).Iterator()
	deletedCount := 0
	for iter.Next(ctx) {
		if err := c.redisClient.Del(ctx, iter.Val()).Err(); err != nil {
			logger.Error("Failed to delete key from Redis",
				zap.Error(err),
				zap.String("key", iter.Val()),
			)
		} else {
			deletedCount++
		}
	}

	if err := iter.Err(); err != nil {
		return err
	}

	logger.Info("Product inventory cache invalidated",
		zap.Int64("product_id", productID),
		zap.Int("keys_deleted", deletedCount),
	)

	return nil
}

// GetMultipleBalances gets multiple balances at once
func (c *InventoryCache) GetMultipleBalances(ctx context.Context, warehouseID int64, productIDs []int64, unitID int64) map[int64]*InventoryBalance {
	result := make(map[int64]*InventoryBalance)

	for _, productID := range productIDs {
		if balance, found := c.GetBalance(ctx, warehouseID, productID, unitID); found {
			result[productID] = balance
		}
	}

	return result
}

// SetMultipleBalances sets multiple balances at once
func (c *InventoryCache) SetMultipleBalances(ctx context.Context, balances []*InventoryBalance) error {
	for _, balance := range balances {
		if err := c.SetBalance(ctx, balance); err != nil {
			return err
		}
	}
	return nil
}

// ClearAll clears all inventory cache
func (c *InventoryCache) ClearAll(ctx context.Context) error {
	// Clear local cache
	c.localCache.Flush()

	// Clear Redis
	pattern := "inventory:*"
	iter := c.redisClient.Scan(ctx, 0, pattern, 1000).Iterator()
	for iter.Next(ctx) {
		c.redisClient.Del(ctx, iter.Val())
	}

	if err := iter.Err(); err != nil {
		return err
	}

	logger.Info("All inventory cache cleared")
	return nil
}

// makeKey creates cache key
func (c *InventoryCache) makeKey(warehouseID, productID, unitID int64) string {
	return fmt.Sprintf("inventory:warehouse:%d:product:%d:unit:%d", warehouseID, productID, unitID)
}

// getFromLocal gets from local cache
func (c *InventoryCache) getFromLocal(key string) (*InventoryBalance, bool) {
	if val, found := c.localCache.Get(key); found {
		if balance, ok := val.(*InventoryBalance); ok {
			return balance, true
		}
	}
	return nil, false
}

// setLocal sets in local cache
func (c *InventoryCache) setLocal(key string, balance *InventoryBalance) {
	c.localCache.Set(key, balance, c.localTTL)
}

// getFromRedis gets from Redis cache
func (c *InventoryCache) getFromRedis(ctx context.Context, key string) (*InventoryBalance, bool) {
	val, err := c.redisClient.Get(ctx, key).Result()
	if err != nil {
		return nil, false
	}

	var balance InventoryBalance
	if err := json.Unmarshal([]byte(val), &balance); err != nil {
		logger.Error("Failed to unmarshal balance from Redis",
			zap.Error(err),
			zap.String("key", key),
		)
		return nil, false
	}

	return &balance, true
}

// setRedis sets in Redis cache
func (c *InventoryCache) setRedis(ctx context.Context, key string, balance *InventoryBalance) error {
	data, err := json.Marshal(balance)
	if err != nil {
		return err
	}

	return c.redisClient.Set(ctx, key, data, c.redisTTL).Err()
}

// GetStats returns cache statistics
func (c *InventoryCache) GetStats() map[string]interface{} {
	return map[string]interface{}{
		"local_items": c.localCache.ItemCount(),
		"local_ttl":   c.localTTL.String(),
		"redis_ttl":   c.redisTTL.String(),
	}
}
