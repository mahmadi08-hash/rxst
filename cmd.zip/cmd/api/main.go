package main

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"syscall"

	"rx-st-system/internal/api"
	"rx-st-system/internal/cache"
	"rx-st-system/internal/config"
	"rx-st-system/internal/database"
	"rx-st-system/pkg/logger"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/compress"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/gofiber/fiber/v2/middleware/requestid"
	"go.uber.org/zap"
)

func main() {
	// Load configuration
	cfg, err := config.Load("./configs/config.yaml")
	if err != nil {
		panic(fmt.Sprintf("Failed to load configuration: %v", err))
	}

	// Initialize logger
	if err := logger.InitLogger(
		cfg.Logging.Level,
		cfg.Logging.Encoding,
		cfg.Logging.OutputPaths,
		cfg.Logging.ErrorOutputPaths,
	); err != nil {
		panic(fmt.Sprintf("Failed to initialize logger: %v", err))
	}
	defer logger.Sync()

	logger.Info("Starting RX-ST System",
		zap.String("version", cfg.App.Version),
		zap.String("env", cfg.App.Env),
	)

	// Initialize database
	db, err := database.NewPostgresPool(&cfg.Database)
	if err != nil {
		logger.Fatal("Failed to connect to database", zap.Error(err))
	}
	defer database.Close(db)

	// Initialize Redis
	redisClient, err := cache.NewRedisClient(&cfg.Redis)
	if err != nil {
		logger.Fatal("Failed to connect to Redis", zap.Error(err))
	}
	defer cache.Close(redisClient)

	// Create Fiber app
	app := fiber.New(fiber.Config{
		AppName:               cfg.App.Name,
		DisableStartupMessage: false,
		ErrorHandler:          api.ErrorHandler,
	})

	// Global middlewares
	app.Use(recover.New())
	app.Use(requestid.New())
	app.Use(compress.New())
	
	// CORS middleware
	app.Use(cors.New(cors.Config{
		AllowOrigins:     joinStrings(cfg.CORS.AllowedOrigins),
		AllowMethods:     joinStrings(cfg.CORS.AllowedMethods),
		AllowHeaders:     joinStrings(cfg.CORS.AllowedHeaders),
		ExposeHeaders:    joinStrings(cfg.CORS.ExposeHeaders),
		AllowCredentials: cfg.CORS.AllowCredentials,
		MaxAge:           cfg.CORS.MaxAge,
	}))

	// Health check endpoint
	app.Get("/health", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{
			"status":  "healthy",
			"version": cfg.App.Version,
		})
	})

	// Setup API routes
	api.SetupRoutes(app, db, redisClient, cfg)

	// Graceful shutdown
	go func() {
		sigCh := make(chan os.Signal, 1)
		signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)
		<-sigCh

		logger.Info("Shutting down server...")
		if err := app.ShutdownWithContext(context.Background()); err != nil {
			logger.Error("Server shutdown error", zap.Error(err))
		}
	}()

	// Start server
	addr := fmt.Sprintf(":%d", cfg.App.Port)
	logger.Info("Server starting", zap.String("address", addr))
	
	if err := app.Listen(addr); err != nil {
		logger.Fatal("Failed to start server", zap.Error(err))
	}
}

func joinStrings(strings []string) string {
	if len(strings) == 0 {
		return ""
	}
	result := strings[0]
	for i := 1; i < len(strings); i++ {
		result += "," + strings[i]
	}
	return result
}
