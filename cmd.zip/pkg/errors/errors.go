package errors

import (
	"fmt"
	"time"
)

// AppError represents a custom application error
type AppError struct {
	Code      string                 `json:"code"`
	Message   string                 `json:"message"`
	Details   map[string]interface{} `json:"details,omitempty"`
	TraceID   string                 `json:"trace_id,omitempty"`
	Timestamp time.Time              `json:"timestamp"`
	Err       error                  `json:"-"`
}

// Error implements the error interface
func (e *AppError) Error() string {
	if e.Err != nil {
		return fmt.Sprintf("%s: %s - %v", e.Code, e.Message, e.Err)
	}
	return fmt.Sprintf("%s: %s", e.Code, e.Message)
}

// Unwrap returns the wrapped error
func (e *AppError) Unwrap() error {
	return e.Err
}

// Common error codes
const (
	ErrCodeValidation        = "VALIDATION_ERROR"
	ErrCodeNotFound          = "NOT_FOUND"
	ErrCodeUnauthorized      = "UNAUTHORIZED"
	ErrCodeForbidden         = "FORBIDDEN"
	ErrCodeConflict          = "CONFLICT"
	ErrCodeInternal          = "INTERNAL_ERROR"
	ErrCodeBadRequest        = "BAD_REQUEST"
	ErrCodeDatabaseError     = "DATABASE_ERROR"
	ErrCodeInsufficientStock = "INSUFFICIENT_STOCK"
	ErrCodeInvalidCredentials = "INVALID_CREDENTIALS"
	ErrCodeUserNotApproved   = "USER_NOT_APPROVED"
	ErrCodeUserLocked        = "USER_LOCKED"
	ErrCodeInvalidToken      = "INVALID_TOKEN"
	ErrCodeExpiredToken      = "EXPIRED_TOKEN"
)

// NewAppError creates a new AppError
func NewAppError(code, message string, err error) *AppError {
	return &AppError{
		Code:      code,
		Message:   message,
		Timestamp: time.Now(),
		Err:       err,
	}
}

// NewValidationError creates a validation error
func NewValidationError(message string, details map[string]interface{}) *AppError {
	return &AppError{
		Code:      ErrCodeValidation,
		Message:   message,
		Details:   details,
		Timestamp: time.Now(),
	}
}

// NewNotFoundError creates a not found error
func NewNotFoundError(resource string) *AppError {
	return &AppError{
		Code:      ErrCodeNotFound,
		Message:   fmt.Sprintf("%s not found", resource),
		Timestamp: time.Now(),
	}
}

// NewUnauthorizedError creates an unauthorized error
func NewUnauthorizedError(message string) *AppError {
	return &AppError{
		Code:      ErrCodeUnauthorized,
		Message:   message,
		Timestamp: time.Now(),
	}
}

// NewForbiddenError creates a forbidden error
func NewForbiddenError(message string) *AppError {
	return &AppError{
		Code:      ErrCodeForbidden,
		Message:   message,
		Timestamp: time.Now(),
	}
}

// NewConflictError creates a conflict error
func NewConflictError(message string) *AppError {
	return &AppError{
		Code:      ErrCodeConflict,
		Message:   message,
		Timestamp: time.Now(),
	}
}

// NewInternalError creates an internal error
func NewInternalError(err error) *AppError {
	return &AppError{
		Code:      ErrCodeInternal,
		Message:   "Internal server error",
		Timestamp: time.Now(),
		Err:       err,
	}
}

// NewDatabaseError creates a database error
func NewDatabaseError(err error) *AppError {
	return &AppError{
		Code:      ErrCodeDatabaseError,
		Message:   "Database error occurred",
		Timestamp: time.Now(),
		Err:       err,
	}
}

// NewInsufficientStockError creates an insufficient stock error
func NewInsufficientStockError(productCode string, available, required float64) *AppError {
	return &AppError{
		Code:    ErrCodeInsufficientStock,
		Message: fmt.Sprintf("Insufficient stock for product %s", productCode),
		Details: map[string]interface{}{
			"product_code": productCode,
			"available":    available,
			"required":     required,
		},
		Timestamp: time.Now(),
	}
}

// WithTraceID adds a trace ID to the error
func (e *AppError) WithTraceID(traceID string) *AppError {
	e.TraceID = traceID
	return e
}

// WithDetails adds details to the error
func (e *AppError) WithDetails(details map[string]interface{}) *AppError {
	if e.Details == nil {
		e.Details = make(map[string]interface{})
	}
	for k, v := range details {
		e.Details[k] = v
	}
	return e
}
